"""Public protocol implementation for the challenge."""

import hashlib

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


P = 112693480841240579684880016842662081173570772522470050854859284408885200781311
D = 3
AAD = b"HTUCTF-PellDH-v1"
COORD_SIZE = (P.bit_length() + 7) // 8


def add(P1, P2):
    x1, y1 = P1
    x2, y2 = P2
    return ((x1 * x2 + D * y1 * y2) % P,
            (x1 * y2 + x2 * y1) % P)


def mul(P1, scalar):
    """Nonnegative integer scalar multiplication."""
    result = (1, 0)
    addend = P1
    while scalar:
        if scalar & 1:
            result = add(result, addend)
        addend = add(addend, addend)
        scalar >>= 1
    return result


def derive_key(shared_point):
    x, _ = shared_point
    encoded_x = x.to_bytes(COORD_SIZE, "big")
    return hashlib.sha256(encoded_x).digest()


def decrypt(shared_point, nonce, ciphertext, tag):
    key = derive_key(shared_point)
    return AESGCM(key).decrypt(nonce, ciphertext + tag, AAD)
