<?php
require_once __DIR__ . "/storage.php";
require_once __DIR__ . "/lib.php";

$GLOBALS["ERR_TABLE"] = [
    "ops_body_invalid"       => [400, "body must be a JSON object"],
    "ops_too_many"           => [400, "too many ops in one call"],
    "op_malformed"           => [400, "op must be an object"],
    "param_missing"          => [400, "a required param is missing"],
    "verb_not_allowed"       => [400, "op verb must be one of POST, PUT, PATCH and DELETE"],
    "route_unparseable"      => [400, "could not parse the route"],
    "route_unknown"          => [404, "no internal route matched"],
    "verb_not_supported"     => [405, "verb not allowed on this route"],
    "route_bulk_rejected"    => [400, "route does not support bulk ops"],
    "route_no_handler"       => [500, "the handler for the route is invalid"],
    "staff_session_required" => [401, "staff session required"],
    "article_missing"        => [404, "no such article"],
    "login_invalid"          => [400, "login must be 3-31 chars of [a-z0-9_-]"],
    "pass_too_short"         => [400, "password must be at least 8 characters"],
    "login_taken"            => [409, "login already exists"],
    "login_failed"           => [401, "invalid credentials"],
    "comment_rejected"       => [400, "comment rejected by input checks"],
    "draft_failed"           => [500, "could not save draft"],
    "action_unknown"         => [404, "unknown endpoint"],
];

$GLOBALS["ROUTE_TABLE"] = [
    "/api/articles/{id}/comments" => [
        "verbs" => ["GET", "POST"],
        "perm"  => "perm_public",
        "exec"  => "exec_comments_list",
        "exec_post" => "exec_comment_add",
        "args"  => [
            "id"     => ["type" => "int", "required" => true],
            "author" => ["type" => "text"],
            "text"   => ["type" => "text"],
            "count"  => ["type" => "int"],
        ],
        "bulk"  => true,
    ],
    "/api/articles/{id}" => [
        "verbs" => ["GET"],
        "perm"  => "perm_public",
        "exec"  => "exec_article_one",
        "args"  => [
            "id" => ["type" => "int", "required" => true],
        ],
        "bulk"  => true,
    ],
    "/api/articles" => [
        "verbs" => ["GET"],
        "perm"  => "perm_public",
        "exec"  => "exec_articles_list",
        "args"  => [
            "owner" => ["type" => "text"],
            "tag"   => ["type" => "text"],
            "omit"  => ["type" => "id_list"],
            "ids"   => ["type" => "id_list"],
            "count" => ["type" => "int"],
            "start" => ["type" => "int"],
        ],
        "bulk"  => true,
    ],
    "/api/tags" => [
        "verbs" => ["GET"],
        "perm"  => "perm_public",
        "exec"  => "exec_tags_index",
        "args"  => [
            "tag"   => ["type" => "text"],
            "count" => ["type" => "int"],
        ],
        "bulk"  => true,
    ],
    "/api/stats/summary" => [
        "verbs" => ["GET"],
        "perm"  => "perm_public",
        "exec"  => "exec_stats_summary",
        "args"  => [],
        "bulk"  => true,
    ],
    "/api/drafts" => [
        "verbs" => ["POST"],
        "perm"  => "perm_staff",
        "exec"  => "exec_draft_create",
        "args"  => [
            "title" => ["type" => "text"],
            "text"  => ["type" => "text"],
            "tags"  => ["type" => "text"],
        ],
        "bulk"  => true,
    ],
    "/api/manage/accounts" => [
        "verbs" => ["GET"],
        "perm"  => "perm_staff",
        "exec"  => "exec_manage_accounts",
        "args"  => [],
        "bulk"  => true,
    ],
    "/api/manage/settings" => [
        "verbs" => ["GET"],
        "perm"  => "perm_staff",
        "exec"  => "exec_manage_settings",
        "args"  => [],
        "bulk"  => true,
    ],
    "/api/manage/lookup" => [
        "verbs" => ["GET"],
        "perm"  => "perm_staff",
        "exec"  => "exec_manage_lookup",
        "args"  => [
            "omit" => ["type" => "id_list"],
            "tag"  => ["type" => "text"],
        ],
        "bulk"  => true,
    ],
    "/api/users" => [
        "verbs" => ["POST"],
        "perm"  => "perm_staff",
        "exec"  => "exec_user_create",
        "args"  => [
            "login" => ["type" => "text", "required" => true],
            "pass"  => ["type" => "text", "required" => true],
        ],
        "bulk"  => true,
    ],
    "/api/login" => [
        "verbs" => ["POST"],
        "perm"  => "perm_public",
        "exec"  => "exec_login",
        "args"  => [
            "login" => ["type" => "text", "required" => true],
            "pass"  => ["type" => "text", "required" => true],
        ],
        "bulk"  => true,
    ],
    "/api/bulk" => [
        "verbs" => ["POST"],
        "perm"  => "perm_public",
        "exec"  => "exec_bulk",
        "args"  => [],
        "bulk"  => false,
    ],
];

function op_err($code) {
    list($status, $message) = $GLOBALS["ERR_TABLE"][$code] ?? [500, "internal error"];
    return ["error" => ["code" => $code, "message" => $message, "status" => $status]];
}

function perm_public($op) { return true; }

function perm_staff($op) {
    if (!staff_session_valid()) {
        return op_err("staff_session_required");
    }
    return true;
}

function exec_articles_list($op) {
    $spec = ["status" => "published"];
    foreach (["owner", "tag"] as $k) {
        if (isset($op["params"][$k]) && $op["params"][$k] !== "") {
            $spec[$k] = $op["params"][$k];
        }
    }
    foreach (["omit" => "owner_not_in", "ids" => "ids"] as $api => $internal) {
        if (isset($op["params"][$api]) && $op["params"][$api] !== "") {
            $spec[$internal] = $op["params"][$api];
        }
    }
    if (isset($op["params"]["count"])) $spec["limit"]  = (int)$op["params"]["count"];
    if (isset($op["params"]["start"])) $spec["offset"] = (int)$op["params"]["start"];
    $rows = posts_lookup($spec);

    foreach ($rows as $r) {
        $full = entry_fetch((int)$r["id"]);
        if ($full && (int)$full["snap_stale"] === 1) {
            snapshot_write($full);
        }
    }
    if (($GLOBALS["HOOK_RUNNING"] ?? 0) === 0) {
        unset($GLOBALS["PUBLISH_AS"]);
    }

    $out = ["articles" => $rows];
    if (!empty($GLOBALS["FOLLOWUP_OUT"])) {
        $out["followup"] = $GLOBALS["FOLLOWUP_OUT"];
        unset($GLOBALS["FOLLOWUP_OUT"]);
    }
    return $out;
}

function exec_article_one($op) {
    $id = (int)($op["params"]["id"] ?? 0);
    $row = row_one("SELECT id, title, slug, owner, excerpt, content, created_at FROM entries WHERE id = ? AND status = 'published'", [$id]);
    if (!$row) {
        return op_err("article_missing");
    }
    return ["article" => $row];
}

function exec_comments_list($op) {
    $id = (int)($op["params"]["id"] ?? 0);
    $limit = isset($op["params"]["count"]) ? (int)$op["params"]["count"] : 50;
    return ["comments" => comments_for_entry($id, $limit)];
}

function exec_comment_add($op) {
    $ok = comment_add(
        (int)($op["params"]["id"] ?? 0),
        (string)($op["params"]["author"] ?? ""),
        (string)($op["params"]["text"] ?? "")
    );
    if (!$ok) {
        return op_err("comment_rejected");
    }
    return ["status" => 1];
}

function exec_tags_index($op) {
    $like  = isset($op["params"]["tag"]) ? (string)$op["params"]["tag"] : "";
    $limit = isset($op["params"]["count"]) ? (int)$op["params"]["count"] : 30;
    return ["tags" => tags_index($like, $limit)];
}

function exec_stats_summary($op) {
    return ["summary" => stats_summary()];
}

function exec_draft_create($op) {
    return draft_create(
        (string)($op["params"]["title"] ?? ""),
        (string)($op["params"]["text"] ?? ""),
        (string)($op["params"]["tags"] ?? "")
    );
}

function exec_user_create($op) {
    return user_create($op["params"]["login"] ?? null, $op["params"]["pass"] ?? null);
}

function exec_login($op) {
    return staff_login($op["params"]["login"] ?? "", $op["params"]["pass"] ?? "");
}

function exec_manage_accounts($op) { return manage_dispatch("accounts", $op["params"]); }
function exec_manage_settings($op) { return manage_dispatch("settings", $op["params"]); }
function exec_manage_lookup($op)   { return manage_dispatch("lookup",   $op["params"]); }

function exec_bulk($op) {
    $inner = $op["params"]["ops"] ?? null;
    if (!is_array($inner)) {
        return op_err("ops_body_invalid");
    }
    if (count($inner) > 25) {
        return op_err("ops_too_many");
    }
    foreach ($inner as $it) {
        if (!is_array($it) || !isset($it["route"]) || !is_string($it["route"])) {
            return op_err("op_malformed");
        }
    }
    $GLOBALS["NEST_LEVEL"] = ($GLOBALS["NEST_LEVEL"] ?? 0) + 1;
    if ($GLOBALS["NEST_LEVEL"] > 2) {
        $GLOBALS["NEST_LEVEL"]--;
        return op_err("ops_too_many");
    }
    $out = bulk_engine($inner, "best-effort");
    $GLOBALS["NEST_LEVEL"]--;
    return $out;
}


function build_op($item) {
    if (!is_array($item)) {
        return ["err" => op_err("op_malformed")];
    }
    $route = isset($item["route"]) ? (string)$item["route"] : "";
    $u = parse_url($route);
    if ($u === false) {
        return ["err" => op_err("route_unparseable")];
    }
    $op = [
        "verb"   => strtoupper(isset($item["verb"]) && $item["verb"] !== "" ? $item["verb"] : "POST"),
        "path"   => isset($u["path"]) ? $u["path"] : "/",
        "params" => [],
    ];
    if (!empty($u["query"])) {
        $qs = [];
        parse_str($u["query"], $qs);
        $op["params"] = array_merge($op["params"], $qs);
    }
    if (!empty($item["data"]) && is_array($item["data"])) {
        $op["params"] = array_merge($op["params"], $item["data"]);
    }
    return $op;
}

function route_bind($op) {
    foreach ($GLOBALS["ROUTE_TABLE"] as $pat => $h) {
        $regex = "#^" . preg_replace("/\{[a-z_]+\}/", "(?P<url_par>[^/]+)", $pat) . "$#D";
        if (preg_match($regex, $op["path"], $m)) {
            if (!in_array($op["verb"], $h["verbs"], true)) {
                return ["err" => op_err("verb_not_supported")];
            }
            if (isset($m["url_par"])) {
                $op["params"]["id"] = $op["params"]["id"] ?? $m["url_par"];
            }
            return ["route" => $pat, "handler" => $h, "op" => $op];
        }
    }
    return ["err" => op_err("route_unknown")];
}

function sanitize_arg($type, $v) {
    switch ($type) {
        case "int":
            return (int)$v;
        case "text":
            return is_string($v) ? $v : implode(",", (array)$v);
        case "id_list":
            $arr = is_array($v) ? $v : [$v];
            $out = [];
            foreach ($arr as $n) { if (absint($n) > 0) $out[] = absint($n); }
            return $out;
    }
    return $v;
}

function op_check($bind) {
    $h  = $bind["handler"];
    $op = $bind["op"];
    if (empty($h["bulk"])) {
        return ["err" => op_err("route_bulk_rejected")];
    }
    foreach (($h["args"] ?? []) as $name => $spec) {
        if (!array_key_exists($name, $op["params"])) {
            if (!empty($spec["required"])) {
                return ["err" => op_err("param_missing")];
            }
            continue;
        }
        $op["params"][$name] = sanitize_arg($spec["type"], $op["params"][$name]);
    }
    return ["op" => $op];
}

function op_respond($op, $handler) {
    $verdict = $handler["perm"]($op);
    if ($verdict !== true) return $verdict;
    $exec = ($op["verb"] === "POST" && isset($handler["exec_post"])) ? $handler["exec_post"] : $handler["exec"];
    return $exec($op);
}

function bulk_engine($items, $policy) {
    $GLOBALS["CUR_OPS"] = $items;
    $GLOBALS["CUR_POLICY"] = $policy;
    $ops = [];
    foreach ($items as $it) {
        $ops[] = build_op($it);
    }

    $matched = [];
    $checked = [];
    $has_err = false;
    foreach ($ops as $op) {
        if (isset($op["err"])) {
            $has_err   = true;
            $checked[] = $op;
            continue;
        }
        $bind = route_bind($op);
        $matched[] = $bind;
        if (isset($bind["err"])) {
            $has_err   = true;
            $checked[] = ["err" => $bind["err"]];
            continue;
        }
        $res = op_check($bind);
        $checked[] = isset($res["err"]) ? ["err" => $res["err"]] : ["op" => $res["op"]];
        if (isset($res["err"])) $has_err = true;
    }

    if ($has_err && $policy === "all-or-nothing") {
        $fails = [];
        foreach ($checked as $c) {
            $fails[] = $c["err"] ?? null;
        }
        return ["policy_failed" => true, "results" => $fails];
    }

    $results = [];
    foreach ($ops as $i => $op) {
        if (isset($op["err"])) {
            $results[] = $op["err"];
            continue;
        }
        $bind = isset($matched[$i]) ? $matched[$i] : null;
        if ($bind !== null && isset($bind["err"])) {
            $results[] = $bind["err"];
            continue;
        }
        $verdict = $checked[$i];
        if (isset($verdict["err"])) {
            $results[] = $verdict["err"];
            continue;
        }
        if ($bind === null) {
            $results[] = op_err("route_no_handler");
            continue;
        }
        $results[] = op_respond($verdict["op"], $bind["handler"]);
    }
    return $results;
}

function ops_run_all($items) {
    $out = [];
    foreach ($items as $it) {
        $op = build_op($it);
        if (isset($op["err"])) {
            $out[] = $op["err"];
            continue;
        }
        $bind = route_bind($op);
        if (isset($bind["err"])) {
            $out[] = $bind["err"];
            continue;
        }
        $res = op_check($bind);
        if (isset($res["err"])) {
            $out[] = $res["err"];
            continue;
        }
        $out[] = op_respond($res["op"], $bind["handler"]);
    }
    return $out;
}
