<?php
function db_handle() {
    static $pdo = null;
    if ($pdo === null) {
        $host = getenv("DB_HOST") ?: "127.0.0.1";
        $port = getenv("DB_PORT") ?: "3306";
        $user = getenv("DB_USER") ?? "";
        $pass = getenv("DB_PASS") ?? "";
        $name = getenv("DB_NAME") ?: "sitedb";
        try {
            $pdo = new PDO(
                "mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4",
                $user, $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(["error" => "storage unavailable"]));
        }
    }
    return $pdo;
}

function rows_all($sql, $params = []) {
    $stmt = db_handle()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function row_one($sql, $params = []) {
    $stmt = db_handle()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch() ?: null;
}

function run_sql($sql, $params = []) {
    $stmt = db_handle()->prepare($sql);
    $stmt->execute($params);
    return $stmt->rowCount();
}
