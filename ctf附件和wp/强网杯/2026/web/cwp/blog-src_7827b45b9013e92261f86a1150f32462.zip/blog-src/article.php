<?php
require_once __DIR__ . "/storage.php";
require_once __DIR__ . "/lib.php";

$entry_id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
if ($entry_id <= 0) {
    http_response_code(400);
    die("invalid id");
}

if (($_SERVER["REQUEST_METHOD"] ?? "GET") === "POST") {
    $author = isset($_POST["author"]) ? mb_substr((string)$_POST["author"], 0, 50) : "";
    $text   = isset($_POST["text"])   ? (string)$_POST["text"] : "";
    comment_add($entry_id, $author, $text);
    header("Location: /article.php?id=" . $entry_id . "#comments");
    exit;
}

$entry = row_one("SELECT id, title, slug, owner, content, created_at FROM entries WHERE id = ? AND status = 'published'", [$entry_id]);
if (!$entry) {
    http_response_code(404);
    die("not found");
}

$tags = rows_all("SELECT tag FROM entry_tags WHERE entry_id = ?", [$entry_id]);
$comments = comments_for_entry($entry_id, 100);

?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title><?= esc_html($entry["title"]) ?> - SimpleBlog</title>
<style>body{font-family:Georgia,serif;max-width:720px;margin:2em auto;padding:0 1em;line-height:1.6}header{border-bottom:1px solid #ccc;padding-bottom:1em;margin-bottom:1em}a{color:#06c;text-decoration:none}a:hover{text-decoration:underline}.meta{color:#888;font-size:0.9em}.tag{display:inline-block;background:#eee;padding:0.1em 0.5em;margin-right:0.3em;border-radius:3px;font-size:0.85em}.comment{border-left:3px solid #eee;padding:0.4em 0.8em;margin:0.8em 0}.comment .meta{margin-bottom:0.2em}form.cf input,form.cf textarea{width:100%;box-sizing:border-box;margin:0.3em 0;padding:0.4em}form.cf button{padding:0.4em 1.2em}</style>
</head>
<body>
<header>
<h1><a href="/">SimpleBlog</a></h1>
<p class="tagline">一个用 PHP 写的极简博客</p>
</header>
<article>
<h2><?= esc_html($entry["title"]) ?></h2>
<p class="meta">作者: <?= esc_html($entry["owner"]) ?> · <?= fmt_date($entry["created_at"]) ?></p>
<div class="content">
<?= nl2br(esc_html($entry["content"])) ?>
</div>
<p>
<?php foreach ($tags as $t): ?>
<a class="tag" href="/?tag=<?= urlencode($t["tag"]) ?>">#<?= esc_html($t["tag"]) ?></a>
<?php endforeach; ?>
</p>
</article>

<section id="comments">
<h3>评论 (<?= count($comments) ?>)</h3>
<?php foreach ($comments as $c): ?>
<div class="comment">
<p class="meta"><?= esc_html($c["author"]) ?> · <?= fmt_date($c["created_at"]) ?></p>
<p><?= nl2br(esc_html($c["text"])) ?></p>
</div>
<?php endforeach; ?>
<form class="cf" method="post" action="/article.php?id=<?= (int)$entry_id ?>#comments">
<input name="author" maxlength="50" placeholder="昵称（可留空）">
<textarea name="text" rows="3" maxlength="2000" placeholder="写下你的评论" required></textarea>
<button>发表评论</button>
</form>
</section>

<footer><a href="/">&larr; 返回首页</a></footer>
</body>
</html>
