<?php
require_once __DIR__ . "/storage.php";
require_once __DIR__ . "/lib.php";
require_once __DIR__ . "/engine.php";

header("Content-Type: application/json; charset=utf-8");

$verb  = strtoupper($_SERVER["REQUEST_METHOD"] ?? "GET");
$route = (string)($_GET["route"] ?? "/api/articles");

$op = [
    "verb"   => $verb,
    "path"   => $route,
    "params" => $_GET,
];
unset($op["params"]["route"]);

if ($verb === "POST") {
    $body_params = [];
    $raw = file_get_contents("php://input");
    $json = json_decode($raw, true);
    if (is_array($json)) {
        $body_params = $json;
    } else {
        parse_str($raw, $body_params);
    }
    $op["params"] = array_merge($op["params"], $body_params);
}

$bind = route_bind($op);
if (isset($bind["err"])) {
    http_response_code($bind["err"]["error"]["status"]);
    die(json_encode($bind["err"]));
}

$res = op_check($bind);
if (isset($res["err"])) {
    http_response_code($res["err"]["error"]["status"]);
    die(json_encode($res["err"]));
}

$out = op_respond($res["op"], $bind["handler"]);
if (isset($out["error"])) {
    http_response_code($out["error"]["status"]);
}
echo json_encode($out);
