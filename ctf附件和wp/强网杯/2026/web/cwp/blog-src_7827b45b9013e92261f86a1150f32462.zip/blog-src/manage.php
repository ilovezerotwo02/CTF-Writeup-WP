<?php
require_once __DIR__ . "/storage.php";
require_once __DIR__ . "/lib.php";

header("Content-Type: application/json; charset=utf-8");

if (!staff_session_valid()) {
    http_response_code(401);
    echo json_encode(["error" => ["code" => "staff_session_required", "message" => "staff session required"]]);
    exit;
}

$endpoint = $_GET["action"] ?? "";
if (in_array($endpoint, ["skin-editor"], true) && ($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    http_response_code(405);
    echo json_encode(["error" => ["code" => "method_not_allowed", "message" => "this action requires POST"]]);
    exit;
}

try {
    echo json_encode(manage_dispatch($endpoint, array_merge($_GET, $_POST)));
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["error" => $e->getMessage()]);
}
