<?php
require_once __DIR__ . "/engine.php";

header("Content-Type: application/json; charset=utf-8");

$raw  = file_get_contents("php://input");
$body = json_decode($raw, true);
if (!is_array($body)) {
    http_response_code(400);
    die(json_encode(op_err("ops_body_invalid")));
}

$policy = ($body["policy"] ?? "best-effort") === "all-or-nothing" ? "all-or-nothing" : "best-effort";
$items  = $body["ops"] ?? null;
if (!is_array($items)) {
    http_response_code(400);
    die(json_encode(op_err("param_missing")));
}
if (count($items) > 25) {
    http_response_code(400);
    die(json_encode(op_err("ops_too_many")));
}

foreach ($items as $it) {
    if (!is_array($it) || !isset($it["route"]) || !is_string($it["route"])) {
        http_response_code(400);
        die(json_encode(op_err("op_malformed")));
    }
    $v = strtoupper($it["verb"] ?? "POST");
    if (!in_array($v, ["POST", "PUT", "PATCH", "DELETE"], true)) {
        http_response_code(400);
        die(json_encode(op_err("verb_not_allowed")));
    }
}

try {
    echo json_encode(["results" => bulk_engine($items, $policy)]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["error" => $e->getMessage()]);
}
