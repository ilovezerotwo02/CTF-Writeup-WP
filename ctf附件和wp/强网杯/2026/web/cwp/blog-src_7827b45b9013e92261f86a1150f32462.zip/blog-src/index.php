<?php
require_once __DIR__ . "/storage.php";
require_once __DIR__ . "/lib.php";

$current_tag = $_GET["tag"] ?? "";

if ($current_tag !== "") {
    $rows = rows_all(
        "SELECT p.id, p.title, p.slug, p.owner, p.excerpt, p.created_at"
        . " FROM entries p"
        . " JOIN entry_tags t ON t.entry_id = p.id"
        . " WHERE t.tag = ? AND p.status = 'published'"
        . " ORDER BY p.created_at DESC LIMIT 20",
        [$current_tag]
    );
} else {
    $rows = rows_all(
        "SELECT id, title, slug, owner, excerpt, created_at FROM entries"
        . " WHERE status = 'published' ORDER BY created_at DESC LIMIT 20"
    );
}

$owners = rows_all("SELECT DISTINCT owner FROM entries WHERE status = 'published' ORDER BY owner");

$owner_options = "";
foreach ($owners as $a) {
    $sel = (($_GET["owner"] ?? "") === $a["owner"]) ? " selected" : "";
    $owner_options .= "<option value=\"" . esc_html($a["owner"]) . "\"" . $sel . ">"
                     . esc_html($a["owner"]) . "</option>\n";
}

$posts_html = "";
foreach ($rows as $p) {
    $posts_html .= "<article class=\"post\">\n";
    $posts_html .= "<h3><a href=\"/article.php?id=" . (int)$p["id"] . "\">"
                 . esc_html($p["title"]) . "</a></h3>\n";
    $posts_html .= "<p class=\"meta\">" . esc_html($p["owner"]) . " · "
                 . fmt_date($p["created_at"]) . "</p>\n";
    $posts_html .= "<p>" . esc_html(clip_text($p["excerpt"], 200)) . "</p>\n";
    $posts_html .= "</article>\n";
}

if ($posts_html === "") {
    $posts_html = "<p>暂无文章</p>";
}

?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>SimpleBlog - 一个用 PHP 写的极简博客</title>
<style>body{font-family:Georgia,serif;max-width:720px;margin:2em auto;padding:0 1em;line-height:1.6}header{border-bottom:1px solid #ccc;padding-bottom:1em;margin-bottom:1em}a{color:#06c;text-decoration:none}a:hover{text-decoration:underline}.meta{color:#888;font-size:0.9em}.post{margin-bottom:1.5em;padding-bottom:1em;border-bottom:1px dashed #eee}.tag{display:inline-block;background:#eee;padding:0.1em 0.5em;margin-right:0.3em;border-radius:3px;font-size:0.85em}form{margin:1em 0}</style>
</head>
<body>
<header>
<h1>SimpleBlog</h1>
<p class="tagline">一个用 PHP 写的极简博客</p>
</header>
<form method="get" action="/">
<label>按作者筛选:
<select name="owner" onchange="this.form.submit()">
<option value="">所有作者</option>
<?= $owner_options ?>
</select>
</label>
<?php if ($current_tag !== ""): ?>
<input type="hidden" name="tag" value="<?= esc_html($current_tag) ?>">
<?php endif; ?>
</form>
<main>
<?= $posts_html ?>
</main>
<footer>
<p><a href="/feed.php">API</a></p>
</footer>
</body>
</html>
