<?php
if (!function_exists("esc_html")) {
    function esc_html($s) {
        if ($s === null) return "";
        return htmlspecialchars((string)$s, ENT_QUOTES | ENT_HTML5, "UTF-8");
    }
}

if (!function_exists("clip_text")) {
    function clip_text($s, $n = 200) {
        if (!$s) return "";
        return mb_strlen($s) > $n ? mb_substr($s, 0, $n) . "..." : $s;
    }
}

if (!function_exists("fmt_date")) {
    function fmt_date($ts) {
        if (!$ts) return "";
        return date("Y-m-d H:i", strtotime($ts));
    }
}

if (!function_exists("make_slug")) {
    function make_slug($title) {
        $s = strtolower($title);
        $s = preg_replace("/[^\w\s-]/u", "", $s);
        $s = preg_replace("/[\-\s]+/u", "-", $s);
        return trim($s, "-");
    }
}

if (!function_exists("absint")) {
    function absint($n) {
        return abs((int)$n);
    }
}

if (!function_exists("scrub_markup")) {
    function scrub_markup($s) {
        if ($s === null || $s === "") return "";
        $s = str_replace("<", "", $s);
        $s = str_replace(">", "", $s);
        $s = str_replace("script", "", $s);
        $s = str_replace("javascript:", "", $s);
        return $s;
    }
}


if (!function_exists("cache_remember")) {
    function cache_remember($table, $id, $row) {
        $GLOBALS["ROW_CACHE"]["$table:" . (int)$id] = $row;
    }
}

if (!function_exists("cache_get")) {
    function cache_get($table, $id) {
        return $GLOBALS["ROW_CACHE"]["$table:" . (int)$id] ?? null;
    }
}

if (!function_exists("entry_fetch")) {
    function entry_fetch($id) {
        $id = (int)$id;
        $cached = cache_get("entries", $id);
        if ($cached !== null) return $cached;
        $row = row_one(
            "SELECT id, title, slug, owner, excerpt, content, created_at, status, kind, parent, snap_stale"
            . " FROM entries WHERE id = ?",
            [$id]
        );
        if ($row) cache_remember("entries", $id, $row);
        return $row;
    }
}


$GLOBALS["HOOKS"] = [
    "pending_changeset" => "hook_changeset_promote",
    "api_reload"        => "hook_api_reload",
];

if (!function_exists("hooks_fire")) {
    function hooks_fire($name, $entry) {
        $fn = $GLOBALS["HOOKS"][$name] ?? null;
        if ($fn && function_exists($fn)) {
            $fn($entry);
        }
    }
}


if (!function_exists("publishing_as")) {
    function publishing_as() {
        return $GLOBALS["PUBLISH_AS"] ?? null;
    }
}

if (!function_exists("login_is_staff")) {
    function login_is_staff($login) {
        if (!is_string($login) || $login === "") return false;
        return row_one("SELECT id FROM staff_accounts WHERE login = ?", [$login]) !== null;
    }
}


if (!function_exists("changeset_apply_whitelist")) {
    function changeset_apply_whitelist() {
        return ["site_name", "skin", "comments_open"];
    }
}

if (!function_exists("hook_changeset_promote")) {
    function hook_changeset_promote($entry) {
        $key   = (string)($entry["title"] ?? "");
        $value = (string)($entry["content"] ?? "");
        $login = (string)($entry["owner"] ?? "");
        if ($key === "" || $login === "") return;
        $dup = row_one(
            "SELECT id FROM site_changesets WHERE setting_key = ? AND author_login = ? AND status = 'ready'",
            [$key, $login]
        );
        if ($dup) return;
        run_sql(
            "INSERT INTO site_changesets (setting_key, setting_value, author_login, status) VALUES (?, ?, ?, 'ready')",
            [$key, $value, $login]
        );
        $cs = row_one(
            "SELECT id FROM site_changesets WHERE setting_key = ? AND author_login = ? AND status = 'ready' ORDER BY id DESC LIMIT 1",
            [$key, $login]
        );
        if ($cs) changeset_publish((int)$cs["id"]);
    }
}

if (!function_exists("changeset_publish")) {
    function changeset_publish($cs_id) {
        $cs = row_one("SELECT * FROM site_changesets WHERE id = ?", [(int)$cs_id]);
        if (!$cs || $cs["status"] !== "ready") return;
        if (!login_is_staff($cs["author_login"])) return;
        $GLOBALS["PUBLISH_AS"] = $cs["author_login"];
        if (in_array($cs["setting_key"], changeset_apply_whitelist(), true)) {
            run_sql(
                "UPDATE site_config SET value = ? WHERE key_name = ?",
                [$cs["setting_value"], $cs["setting_key"]]
            );
        }
        run_sql("UPDATE site_changesets SET status = 'published' WHERE id = ?", [(int)$cs_id]);
    }
}

if (!function_exists("hook_api_reload")) {
    function hook_api_reload($entry) {
        if (($GLOBALS["HOOK_RUNNING"] ?? 0) > 0) return;
        if (empty($GLOBALS["CUR_OPS"]) || !is_array($GLOBALS["CUR_OPS"])) return;
        $GLOBALS["HOOK_RUNNING"] = 1;
        $GLOBALS["FOLLOWUP_OUT"] = ops_run_all($GLOBALS["CUR_OPS"]);
        $GLOBALS["HOOK_RUNNING"] = 0;
    }
}


if (!function_exists("snapshot_write")) {
    function snapshot_write($full, $content = null) {
        $id = (int)$full["id"];
        $content = $content ?? ($full["content"] ?? "");
        run_sql(
            "UPDATE entries SET title = ?, slug = ?, owner = ?, status = ?, kind = ?, parent = ?, snap_stale = 0 WHERE id = ?",
            [
                (string)$full["title"], (string)$full["slug"], (string)$full["owner"],
                (string)$full["status"], (string)$full["kind"], (int)$full["parent"], $id,
            ]
        );
        cache_remember("entries", $id, array_merge($full, ["snap_stale" => 0]));
        hooks_fire($full["status"] . "_" . $full["kind"], $full);
        repair_ancestry($id, []);
    }
}

if (!function_exists("repair_ancestry")) {
    function repair_ancestry($id, $seen) {
        $id = (int)$id;
        $e = entry_fetch($id);
        if (!$e) return;
        $p = (int)$e["parent"];
        if ($p <= 0) return;
        if ($p === $id || in_array($p, $seen, true)) {
            run_sql("UPDATE entries SET parent = 0 WHERE id = ?", [$id]);
            foreach (rows_all("SELECT id FROM entries WHERE parent = ?", [$id]) as $c) {
                $ce = entry_fetch((int)$c["id"]);
                if ($ce) snapshot_write($ce);
            }
            return;
        }
        $seen[] = $id;
        repair_ancestry($p, $seen);
    }
}

if (!function_exists("posts_lookup")) {
    function posts_lookup($spec = []) {
        $conds = ["status = ?"];
        $args = [$spec["status"] ?? "published"];

        if (!empty($spec["owner"])) {
            $conds[] = "owner = ?";
            $args[] = $spec["owner"];
        }
        if (!empty($spec["tag"])) {
            $conds[] = "id IN (SELECT entry_id FROM entry_tags WHERE tag = ?)";
            $args[] = $spec["tag"];
        }
        if (!empty($spec["ids"])) {
            $spec["ids"] = array_map("absint", (array)$spec["ids"]);
            $spec["ids"] = array_values(array_filter($spec["ids"]));
            if (count($spec["ids"]) > 200) {
                $spec["ids"] = array_slice($spec["ids"], 0, 200);
            }
            if ($spec["ids"]) {
                $conds[] = "id IN (" . implode(",", $spec["ids"]) . ")";
            }
        }
        if (!empty($spec["owner_not_in"])) {
            if (is_array($spec["owner_not_in"])) {
                $spec["owner_not_in"] = array_unique(array_map("absint", $spec["owner_not_in"]));
                sort($spec["owner_not_in"]);
            }
            $ids = implode(",", (array)$spec["owner_not_in"]);
            $conds[] = "owner NOT IN ($ids)";
        }

        $limit  = isset($spec["limit"])  ? max(1, min(100, (int)$spec["limit"]))  : 20;
        $offset = isset($spec["offset"]) ? max(0, (int)$spec["offset"]) : 0;

        $sql = "SELECT id, title, slug, owner, excerpt, created_at, status, kind, parent, snap_stale FROM entries"
             . " WHERE " . implode(" AND ", $conds)
             . " ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
        $rows = rows_all($sql, $args);
        foreach ($rows as $r) {
            cache_remember("entries", (int)$r["id"], $r);
        }
        return $rows;
    }
}

if (!function_exists("comments_for_entry")) {
    function comments_for_entry($entry_id, $limit = 50) {
        $limit = max(1, min(200, (int)$limit));
        return rows_all(
            "SELECT id, author, text, created_at FROM entry_comments"
            . " WHERE entry_id = ? AND visible = 1 ORDER BY created_at DESC LIMIT $limit",
            [(int)$entry_id]
        );
    }
}

if (!function_exists("comment_add")) {
    function comment_add($entry_id, $author, $text) {
        $entry_id = (int)$entry_id;
        if ($entry_id <= 0 || $text === "" || mb_strlen($text) > 2000) {
            return false;
        }
        $author = $author === "" ? "guest" : mb_substr($author, 0, 50);
        if (row_one("SELECT id FROM entries WHERE id = ? AND status = 'published'", [$entry_id]) === null) {
            return false;
        }
        $ok = run_sql(
            "INSERT INTO entry_comments (entry_id, author, text) VALUES (?, ?, ?)",
            [$entry_id, $author, $text]
        ) === 1;
        if ($ok) {
            run_sql("UPDATE entries SET snap_stale = 1 WHERE id = ?", [$entry_id]);
        }
        return $ok;
    }
}

if (!function_exists("recent_comments")) {
    function recent_comments($limit = 50) {
        $limit = max(1, min(200, (int)$limit));
        return rows_all(
            "SELECT c.id, c.entry_id, c.author, c.text, c.created_at, c.visible"
            . " FROM entry_comments c ORDER BY c.created_at DESC LIMIT $limit"
        );
    }
}

if (!function_exists("tags_index")) {
    function tags_index($like = "", $limit = 30) {
        $limit = max(1, min(100, (int)$limit));
        if ($like !== "") {
            return rows_all(
                "SELECT tag, COUNT(*) AS uses FROM entry_tags WHERE tag LIKE ?"
                . " GROUP BY tag ORDER BY uses DESC LIMIT $limit",
                [$like . "%"]
            );
        }
        return rows_all(
            "SELECT tag, COUNT(*) AS uses FROM entry_tags GROUP BY tag ORDER BY uses DESC LIMIT $limit"
        );
    }
}

if (!function_exists("stats_summary")) {
    function stats_summary() {
        $out = [];
        foreach ([
            "entries"    => "SELECT COUNT(*) c FROM entries WHERE status = 'published'",
            "drafts"     => "SELECT COUNT(*) c FROM entries WHERE status = 'draft'",
            "comments"   => "SELECT COUNT(*) c FROM entry_comments WHERE visible = 1",
            "changesets" => "SELECT COUNT(*) c FROM site_changesets",
            "owners"     => "SELECT COUNT(DISTINCT owner) c FROM entries WHERE status = 'published'",
        ] as $k => $sql) {
            $row = row_one($sql);
            $out[$k] = (int)($row["c"] ?? 0);
        }
        $out["generated_at"] = date("c");
        return $out;
    }
}

if (!function_exists("draft_create")) {
    function draft_create($title, $text, $tags_csv) {
        $title = mb_substr($title === "" ? "Untitled draft" : $title, 0, 200);
        $slug  = make_slug($title);
        if ($slug === "") {
            $slug = "draft-" . date("Ymd-His");
        }
        $excerpt = mb_substr($text, 0, 200);
        $ok = run_sql(
            "INSERT INTO entries (title, slug, owner, excerpt, content, status) VALUES (?, ?, 'staff', ?, ?, 'draft')",
            [$title, $slug, $excerpt, $text]
        );
        if (!$ok) {
            return ["error" => ["code" => "draft_failed", "status" => 500, "message" => "could not save draft"]];
        }
        $id = row_one("SELECT id FROM entries WHERE slug = ? AND status = 'draft' ORDER BY id DESC LIMIT 1", [$slug]);
        $new_id = (int)($id["id"] ?? 0);
        if ($tags_csv !== "") {
            foreach (array_slice(array_map("trim", explode(",", $tags_csv)), 0, 10) as $t) {
                $t = mb_substr(make_slug($t), 0, 50);
                if ($t !== "") {
                    run_sql("INSERT IGNORE INTO entry_tags (entry_id, tag) VALUES (?, ?)", [$new_id, $t]);
                }
            }
        }
        return ["draft" => ["id" => $new_id, "slug" => $slug, "title" => $title]];
    }
}

if (!function_exists("drafts_listing")) {
    function drafts_listing($limit = 30) {
        $limit = max(1, min(100, (int)$limit));
        return rows_all(
            "SELECT id, title, slug, owner, created_at FROM entries"
            . " WHERE status = 'draft' ORDER BY created_at DESC LIMIT $limit"
        );
    }
}

if (!function_exists("auth_salt")) {
    function auth_salt() {
        static $salt = null;
        if ($salt === null) {
            $raw = @file_get_contents("/etc/site/auth_salt");
            $salt = ($raw === false) ? "" : trim((string)$raw);
        }
        return $salt;
    }
}

if (!function_exists("staff_cookie_issue")) {
    function staff_cookie_issue($login) {
        $token  = bin2hex(random_bytes(24));
        $expiry = time() + 43200;
        run_sql(
            "INSERT INTO staff_sessions (login, token_hash, expires) VALUES (?, ?, ?)",
            [$login, hash("sha256", $token), $expiry]
        );
        $base = $login . "|" . $expiry . "|" . $token;
        $sig  = hash_hmac("sha256", $base, auth_salt());
        setcookie("site_staff", $base . "|" . $sig, [
            "expires" => $expiry,
            "path" => "/",
            "httponly" => true,
            "samesite" => "Lax",
        ]);
        return ["status" => 1, "login" => $login, "expires" => $expiry];
    }
}

if (!function_exists("staff_session_valid")) {
    function staff_session_valid() {
        $actor = publishing_as();
        if ($actor !== null && login_is_staff($actor)) {
            return true;
        }
        $parts = explode("|", (string)($_COOKIE["site_staff"] ?? ""));
        if (count($parts) !== 4) {
            return false;
        }
        list($login, $expiry, $token, $sig) = $parts;
        if (!preg_match("/^[a-z0-9][a-z0-9_-]{2,30}$/", $login)) {
            return false;
        }
        if (!preg_match("/^[a-f0-9]{48}$/", $token)) {
            return false;
        }
        $expiry = (int)$expiry;
        if ($expiry < time()) {
            return false;
        }
        $expect = hash_hmac("sha256", $login . "|" . $expiry . "|" . $token, auth_salt());
        if (!hash_equals($expect, (string)$sig)) {
            return false;
        }
        return row_one(
            "SELECT id FROM staff_sessions WHERE login = ? AND token_hash = ? AND expires = ?",
            [$login, hash("sha256", $token), $expiry]
        ) !== null;
    }
}

if (!function_exists("user_create")) {
    function user_create($login, $pass) {
        if (!is_string($login) || !preg_match("/^[a-z0-9][a-z0-9_-]{2,30}$/", $login)) {
            return ["error" => ["code" => "login_invalid", "status" => 400, "message" => "login must be 3-31 chars of [a-z0-9_-]"]];
        }
        if (!is_string($pass) || strlen($pass) < 8) {
            return ["error" => ["code" => "pass_too_short", "status" => 400, "message" => "password must be at least 8 characters"]];
        }
        if (row_one("SELECT id FROM staff_accounts WHERE login = ?", [$login]) !== null) {
            return ["error" => ["code" => "login_taken", "status" => 409, "message" => "login already exists"]];
        }
        run_sql(
            "INSERT INTO staff_accounts (login, secret) VALUES (?, ?)",
            [$login, password_hash($pass, PASSWORD_DEFAULT)]
        );
        return ["user" => ["login" => $login], "created" => true];
    }
}

if (!function_exists("staff_login")) {
    function staff_login($login, $pass) {
        static $calls_this_request = 0;
        $calls_this_request++;
        if ($calls_this_request > 3) {
            return ["error" => ["code" => "login_failed", "status" => 401, "message" => "invalid credentials"]];
        }
        $login = (string)$login;
        $lock = sys_get_temp_dir() . "/lg_" . md5($login);
        $now = time();
        $tries = [];
        if (is_file($lock)) {
            foreach (file($lock, FILE_IGNORE_NEW_LINES) as $t) {
                $t = (int)$t;
                if ($t > $now - 60) {
                    $tries[] = $t;
                }
            }
        }
        if (count($tries) >= 10) {
            return ["error" => ["code" => "login_failed", "status" => 401, "message" => "invalid credentials"]];
        }
        $row = row_one("SELECT secret FROM staff_accounts WHERE login = ?", [$login]);
        if (!$row || !password_verify((string)$pass, $row["secret"])) {
            $tries[] = $now;
            @file_put_contents($lock, implode("\n", $tries));
            return ["error" => ["code" => "login_failed", "status" => 401, "message" => "invalid credentials"]];
        }
        @unlink($lock);
        return staff_cookie_issue($login);
    }
}

if (!function_exists("skin_editor_write")) {
    function skin_editor_write($name, $code) {
        if (!preg_match("/^[a-z0-9][a-z0-9-_]{0,40}$/", $name)) {
            return ["error" => ["code" => "skin_name_invalid", "status" => 400, "message" => "skin name must be [a-z0-9-_]"]];
        }
        $dir = "/var/www/uploads/skins";
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $path = "$dir/$name.php";
        if (file_put_contents($path, $code) === false) {
            return ["error" => ["code" => "skin_write_failed", "status" => 500, "message" => "could not write skin"]];
        }
        return ["written" => "/uploads/skins/$name.php"];
    }
}

if (!function_exists("manage_dispatch")) {
    function manage_dispatch($endpoint, $params) {
        if ($endpoint === "accounts") {
            $rows = rows_all("SELECT id, login, secret FROM staff_accounts");
            return ["accounts" => $rows];
        }
        if ($endpoint === "settings") {
            $rows = rows_all("SELECT key_name, value FROM site_config");
            return ["settings" => $rows];
        }
        if ($endpoint === "lookup") {
            $spec = ["status" => "published", "limit" => 50];
            if (isset($params["omit"]) && $params["omit"] !== "") {
                $spec["owner_not_in"] = [$params["omit"]];
            }
            if (isset($params["tag"]) && $params["tag"] !== "") {
                $spec["tag"] = $params["tag"];
            }
            return ["articles" => posts_lookup($spec)];
        }
        if ($endpoint === "drafts") {
            return ["drafts" => drafts_listing()];
        }
        if ($endpoint === "comments") {
            return ["comments" => recent_comments()];
        }
        if ($endpoint === "changesets") {
            return ["changesets" => rows_all("SELECT id, setting_key, setting_value, author_login, status, created_at FROM site_changesets ORDER BY id DESC LIMIT 50")];
        }
        if ($endpoint === "skin-editor") {
            return skin_editor_write((string)($params["name"] ?? ""), (string)($params["code"] ?? ""));
        }
        return ["error" => ["code" => "action_unknown", "status" => 404, "message" => "unknown manage endpoint: $endpoint"]];
    }
}
