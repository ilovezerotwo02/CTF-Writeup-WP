#!/bin/bash
# SG-5000 容器入口: root 起, 注入 flag 后降权运行"装置(ied) + 站控(oper)"双进程
set -u

# flag 仅站控账号(oper)可读; 注入后立即从环境中抹除(防 /proc/<pid>/environ 旁路)
# platform dynamic flag (ICQ_FLAG) takes precedence over the compose FLAG
if [ -n "${ICQ_FLAG:-}" ]; then
    FLAG="$ICQ_FLAG"
fi
unset ICQ_FLAG

if [ -n "${FLAG:-}" ]; then
    printf '%s' "${FLAG}" > /flag
    chown root:oper /flag
    chmod 0440 /flag
fi
unset FLAG

# 录波区卷权限: 挂载的宿主目录所有者不一定是 ied, 统一放开读写
# (装置需要写录波/工参缓存; 目录内容均为运行数据)
chmod -R a+rwX /srv/filestore 2>/dev/null || true

# 站控数据区: 清掉上次运行的报告审计档(循环缓存档, 只保留本次开机后的)
rm -f /srv/mlc/data/rec-*.jrn 2>/dev/null || true

mkdir -p /tmp/gwlog
chmod 777 /tmp/gwlog

# ---- 装置侧(ied): MMS 服务, 异常退出 2 秒拉起 ----
setpriv --reuid=ied --regid=ied --init-groups \
    --inh-caps=+net_bind_service --ambient-caps=+net_bind_service \
    bash -c 'while true; do
        /srv/lib/server_sg5000 102 /srv/filestore >> /tmp/gwlog/gw.log 2>&1
        echo "[supervisor] device exited ($?), restart in 2s" >> /tmp/gwlog/gw.log
        sleep 2
    done' &

# ---- 站控侧(oper): 主站链路代理, 异常退出 2 秒拉起 ----
setpriv --reuid=oper --regid=oper --init-groups \
    bash -c 'while true; do
        /srv/mlc/sg_masterlink >> /tmp/gwlog/mlclient-sup.log 2>&1
        echo "[supervisor] masterlink exited ($?), restart in 2s" >> /tmp/gwlog/mlclient-sup.log
        sleep 2
    done' &

wait
