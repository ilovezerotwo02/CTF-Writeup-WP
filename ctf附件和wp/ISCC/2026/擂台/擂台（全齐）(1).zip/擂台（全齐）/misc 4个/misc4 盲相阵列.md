## 分析过程
附件解开后是一个接收机采样包，文件列表如下。`array_iq.csv` 存放 I/Q 复数采样，`rx_note.txt` 给出接收链路参数和解码链路。

```bash
unzip -l mangxiangzhenlie.zip
```

```text
Archive:  mangxiangzhenlie.zip
  Length      Date    Time    Name
---------  ---------- -----   ----
   656172  2026-05-11 02:28   blind-phase\bundle\array_iq.csv
      584  2026-05-11 02:28   blind-phase\bundle\rx_note.txt
---------                     -------
   656756                     2 files
```

`rx_note.txt` 的内容直接给出了采样率、符号率、频偏附近值、训练块长度和后续比特链路。

```text
Blind Phase Array receiver note
===============================
The dumped CSV contains complex I/Q samples after a faulty downconverter.
Sample rate: 48000 Hz. Nominal symbol rate: 1200 baud.
The residual carrier offset is close to +1700 Hz.
The symbol boundary is not at sample 0; find it with the training block.
The first 80 recovered symbols are training/sync symbols.
Payload path from the old FPGA notes: PN mask -> 16-lane column DMA -> H(7,4) nibbles -> BP1 frame.
Selected codewords are expected to contain one bad bit. CRC32 at the frame tail is the final integrity check.
```

由这里得到每个符号 `48000 / 1200 = 40` 个采样点，残余载波按 `+1700 Hz` 下变频补偿。BPSK 的未知相位通过平方平均消除符号正负号：对抽样后的复数符号求 `sum(symbol^2)`，相位的一半就是载波补偿后的整体相位。训练块前 64 bit 是交替的 `1010...`，用它来确定符号边界和极性；紧随其后的 16 bit 是 PN 初始状态。实际检查结果如下。

```bash
python - <<'PY'
# 统计采样、训练块、PN 初始状态、帧校验数据
PY
```

```text
samples = 25670
sps = 40
symbols_at_offset_17 = 642
training_bits = 10101010101010101010101010101010101010101010101010101010101010101110010110100010
sync_seed = 0xe5a2
payload_symbols = 562
usable_payload_bits = 560
pn_skip = 8
hamming_error_distribution = {0: 75, 1: 5}
frame_hex = 42503120495343437b523721715f5a40346d5e54393f702456256b26322a6e7e4c23787da60a993c
frame_ascii = BP1 ISCC{R7!q_Z@4m^T9?p$V%k&2*n~L#x}...<
crc_calc = 0xa60a993c
crc_tail = 0xa60a993c
```

解码时从训练块之后取 payload，比特数按 `16 * 7` 的整数倍截取，本附件可用 560 bit。PN 使用 16 bit LFSR，反馈连接为 `0x1d00`，脚本从同步字段取 seed，不写死 `0xe5a2`；PN 起始点通过 BP1 帧头和 CRC32 自动试出，本附件得到 skip 为 8。去 PN 后，16 路 column DMA 的逆变换是把收到的 16 列按行重新读出：`out[row * 16 + lane] = in[lane * rows + row]`。之后每 7 bit 进入 H(7,4) 解码，码字格式为 `[p1, p2, d1, p4, d2, d3, d4]`，校验位关系为 `p1=d1^d2^d4`、`p2=d1^d3^d4`、`p4=d2^d3^d4`。输出共有 80 个码字，其中 75 个无错、5 个修正 1 bit，符合说明中的“一些码字带 1 bit 错误”。

Hamming 解码出的帧以 `BP1 ` 开头，后面是正文和 4 字节大端 CRC32。CRC 对 `BP1 ` 后、帧尾 CRC 前的正文计算，结果 `0xa60a993c` 与帧尾 `a6 0a 99 3c` 一致，因此正文 `ISCC{R7!q_Z@4m^T9?p$V%k&2*n~L#x}` 是最终结果。

脚本的通用化设计集中在参数来源上：采样率、符号率、残余载波、训练块长度、DMA 路数从 `rx_note.txt` 解析；I/Q 数据从 `array_iq.csv` 读取；符号边界通过前 64 个交替训练符号扫描获得；PN seed 从训练块末尾 16 bit 解析；payload 长度按 `16 * 7` 的结构自动截断；PN skip 依靠 BP1 帧头和 CRC32 校验动态确定；flag 从通过 CRC 的 BP1 正文中取出。换同结构附件时，样本内容、边界、seed、payload 和 CRC 都从附件重新计算，不依赖当前附件的固定偏移或明文内容。

## EXP

```python
import csv
import io
import math
import os
import re
import sys
import zipfile
import zlib


def read_bundle(path):
    note_text = ""
    csv_text = ""
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
            note_name = next((n for n in names if n.replace('\\', '/').endswith('rx_note.txt')), None)
            csv_name = next((n for n in names if n.replace('\\', '/').endswith('array_iq.csv')), None)
            if note_name is None or csv_name is None:
                raise ValueError('missing rx_note.txt or array_iq.csv')
            note_text = zf.read(note_name).decode('utf-8', errors='replace')
            csv_text = zf.read(csv_name).decode('utf-8', errors='replace')
    elif os.path.isdir(path):
        note_path = None
        csv_path = None
        for root, _, files in os.walk(path):
            for name in files:
                full = os.path.join(root, name)
                if name == 'rx_note.txt':
                    note_path = full
                elif name == 'array_iq.csv':
                    csv_path = full
        if note_path is None or csv_path is None:
            raise ValueError('missing rx_note.txt or array_iq.csv')
        with open(note_path, 'r', encoding='utf-8', errors='replace') as f:
            note_text = f.read()
        with open(csv_path, 'r', encoding='utf-8', errors='replace') as f:
            csv_text = f.read()
    else:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            csv_text = f.read()
    return note_text, csv_text


def parse_note(note_text):
    def grab(pattern, default=None, cast=float):
        m = re.search(pattern, note_text, re.I)
        if not m:
            if default is None:
                raise ValueError('missing parameter in rx_note.txt')
            return default
        return cast(m.group(1))

    sample_rate = grab(r'Sample\s+rate:\s*([0-9.]+)', cast=float)
    symbol_rate = grab(r'symbol\s+rate:\s*([0-9.]+)', cast=float)
    carrier = grab(r'offset\s+is\s+close\s+to\s*([+-]?[0-9.]+)', cast=float)
    training = grab(r'first\s+([0-9]+)\s+recovered\s+symbols', default=80, cast=int)
    lanes = grab(r'([0-9]+)\s*-\s*lane\s+column\s+DMA', default=16, cast=int)
    return sample_rate, symbol_rate, carrier, training, lanes


def read_iq(csv_text):
    out = []
    reader = csv.DictReader(io.StringIO(csv_text))
    for row in reader:
        out.append(complex(float(row['i']), float(row['q'])))
    if not out:
        raise ValueError('empty csv')
    return out


def lfsr_mask(seed, count):
    state = seed & 0xffff
    poly = 0x1d00
    out = []
    for _ in range(count):
        out_bit = state & 1
        feedback = (state & poly).bit_count() & 1
        state = (state >> 1) | (feedback << 15)
        out.append(out_bit)
    return out


def hamming_codewords():
    table = []
    for n in range(16):
        d1 = (n >> 3) & 1
        d2 = (n >> 2) & 1
        d3 = (n >> 1) & 1
        d4 = n & 1
        p1 = d1 ^ d2 ^ d4
        p2 = d1 ^ d3 ^ d4
        p4 = d2 ^ d3 ^ d4
        table.append([p1, p2, d1, p4, d2, d3, d4])
    return table


def hamming_decode(bits):
    words = hamming_codewords()
    nibbles = []
    errors = 0
    for i in range(0, len(bits), 7):
        word = bits[i:i + 7]
        if len(word) < 7:
            break
        best_dist = 8
        best_nibble = 0
        for nibble, codeword in enumerate(words):
            dist = sum(a != b for a, b in zip(word, codeword))
            if dist < best_dist:
                best_dist = dist
                best_nibble = nibble
        errors += best_dist
        nibbles.append(best_nibble)
    data = bytearray()
    for i in range(0, len(nibbles) - 1, 2):
        data.append((nibbles[i] << 4) | nibbles[i + 1])
    return bytes(data), errors


def undo_column_dma(bits, lanes):
    rows = len(bits) // lanes
    out = []
    for r in range(rows):
        for lane in range(lanes):
            out.append(bits[lane * rows + r])
    return out


def try_decode_symbol_bits(bits, training, lanes):
    if len(bits) <= training + lanes * 7:
        return None
    sync_bits = bits[64:training]
    if len(sync_bits) != 16:
        return None
    seed = int(''.join(str(b) for b in sync_bits), 2)
    payload = bits[training:]
    block = lanes * 7
    usable = (len(payload) // block) * block
    payload = payload[:usable]
    if usable == 0:
        return None

    max_skip = max(128, training + 64)
    mask = lfsr_mask(seed, usable + max_skip)
    for skip in range(max_skip):
        unmasked = [payload[i] ^ mask[i + skip] for i in range(usable)]
        ordered = undo_column_dma(unmasked, lanes)
        frame, _ = hamming_decode(ordered)
        if len(frame) < 8 or not frame.startswith(b'BP1 '):
            continue
        body = frame[4:-4]
        crc_tail = int.from_bytes(frame[-4:], 'big')
        if (zlib.crc32(body) & 0xffffffff) != crc_tail:
            continue
        try:
            flag = body.decode('ascii')
        except UnicodeDecodeError:
            continue
        if re.fullmatch(r'[A-Za-z0-9_]+\{[^\r\n{}]+\}', flag):
            return flag
    return None


def demodulate_and_decode(samples, sample_rate, symbol_rate, carrier, training, lanes):
    sps = int(round(sample_rate / symbol_rate))
    if sps <= 0:
        raise ValueError('bad sample/symbol rate')
    alt10 = [1 if i % 2 == 0 else 0 for i in range(64)]
    alt01 = [1 - b for b in alt10]
    two_pi = 2.0 * math.pi

    for offset in range(sps):
        symbols = []
        for idx in range(offset, len(samples), sps):
            angle = -two_pi * carrier * idx / sample_rate
            symbols.append(samples[idx] * complex(math.cos(angle), math.sin(angle)))
        if len(symbols) <= training:
            continue

        phasor = sum(v * v for v in symbols)
        phase = 0.5 * math.atan2(phasor.imag, phasor.real)
        rot = complex(math.cos(-phase), math.sin(-phase))
        bits = [1 if (v * rot).real < 0 else 0 for v in symbols]

        m10 = sum(bits[i] == alt10[i] for i in range(64))
        m01 = sum(bits[i] == alt01[i] for i in range(64))
        if m01 > m10:
            bits = [1 - b for b in bits]
            m10 = m01
        if m10 < 60:
            continue

        flag = try_decode_symbol_bits(bits, training, lanes)
        if flag:
            return flag
    raise ValueError('flag not recovered')


def main():
    if len(sys.argv) != 2:
        print('usage: python 1.py <attachment_path>')
        sys.exit(1)
    note_text, csv_text = read_bundle(sys.argv[1])
    sample_rate, symbol_rate, carrier, training, lanes = parse_note(note_text)
    samples = read_iq(csv_text)
    flag = demodulate_and_decode(samples, sample_rate, symbol_rate, carrier, training, lanes)
    print(flag)


if __name__ == '__main__':
    main()
```

## 答案
ISCC{R7!q_Z@4m^T9?p$V%k&2*n~L#x}
