# 《先声夺人》MISC 题 WP

## 一、题目信息分析

题目名称是：

```text
先声夺人
```

题目描述是：

```text
时间就是生命，比比看谁能先声夺人。
```

看到这个描述，第一反应不应该只盯着“声音”两个字。MISC 题里，题目名称和描述经常是双关提示。

这里有两个关键词：

```text
先声
时间
```

“先声”可能提示音频，也可能只是说“先下手为强”。
“时间就是生命”则更像是提示某种和时间成本有关的操作，比如爆破、竞速、Proof of Work、哈希搜索、时间戳、文件时间信息等。

所以初步分析方向可以分成几类：

```text
1. 检查附件里有没有音频、视频、图片等常规隐写载体
2. 检查文件时间戳、文件名、压缩包结构
3. 检查文本中是否藏了不可见字符
4. 如果后续出现哈希条件，重点考虑 PoW 或暴力搜索
```

------

## 二、解压附件并查看文件结构

拿到附件 `showtime_01.zip` 后，先不要直接打开看内容，而是先查看压缩包结构。

可以使用命令：

```bash
unzip -l showtime_01.zip
```

或者直接解压：

```bash
unzip showtime_01.zip
```

解压后得到一个文件：

```text
challenge.txt
```

这时候第一步是判断文件类型：

```bash
file challenge.txt
```

如果是普通文本，会显示类似：

```text
UTF-8 Unicode text
```

这说明它不是图片、音频、视频，也不是二进制程序，而是一个文本文件。

------

## 三、打开文本，发现表面内容像掩护文本

用编辑器打开 `challenge.txt`，会看到一大段新闻式、多语言混杂的文本。

这种情况在 MISC 里很常见。表面文本看起来很正常，但真正的数据可能藏在下面这些地方：

```text
1. 每行首字母
2. 标点符号
3. 空格和制表符
4. Unicode 不可见字符
5. 大小写模式
6. 词语长度
7. 文本编码差异
```

这道题里，文本本身没有明显的规律，比如行首字母没有直接组成可读信息，标点也没有明显二进制特征。下一步应该检查是否存在不可见字符。

------

## 四、检查文本中的异常 Unicode 字符

普通文本通常由可见字符组成。但一些 Unicode 字符在屏幕上看不到，比如：

```text
U+200B  Zero Width Space
U+200C  Zero Width Non-Joiner
U+200D  Zero Width Joiner
U+FEFF  Zero Width No-Break Space / BOM
```

这些字符常被用来做零宽字符隐写。

可以用 Python 统计文件里的字符：

```python
from collections import Counter

with open("challenge.txt", "r", encoding="utf-8") as f:
    s = f.read()

cnt = Counter(s)

for ch, n in cnt.items():
    code = ord(ch)
    if code < 32 or code > 126:
        print(hex(code), repr(ch), n)
```

如果输出很多普通中文字符也没关系。我们重点关注零宽字符：

```python
from collections import Counter

with open("challenge.txt", "r", encoding="utf-8") as f:
    s = f.read()

targets = ["\u200b", "\u200c", "\u200d", "\ufeff"]

for ch in targets:
    print(hex(ord(ch)), s.count(ch))
```

可以发现：

```text
U+200B 出现 677 次
U+FEFF 出现 653 次
U+200C 出现 640 次
U+200D 出现 622 次
```

总数是：

```text
677 + 653 + 640 + 622 = 2592
```

这个数字非常关键。说明文本中藏了 2592 个零宽字符。

------

## 五、为什么判断这是零宽字符隐写

零宽字符隐写的基本思想是：

```text
用看不见的字符表示二进制数据
```

如果只使用两种零宽字符，就可以这样编码：

```text
U+200B -> 0
U+200C -> 1
```

但这题里刚好出现 4 种零宽字符，所以更合理的编码方式是：

```text
4 种字符分别表示 00、01、10、11
```

也就是说，每个零宽字符携带 2 bit 信息。

总共有 2592 个零宽字符，所以总 bit 数是：

```text
2592 × 2 = 5184 bit
```

换算成字节：

```text
5184 / 8 = 648 byte
```

这说明隐藏数据很可能是一个 648 字节的二进制数据块。

这个长度是整数，没有多余 bit，说明方向基本正确。

------

## 六、提取零宽字符并转成二进制

常见零宽编码映射有多种，但一般会按照 Unicode 顺序尝试：

```text
U+200B -> 00
U+200C -> 01
U+200D -> 10
U+FEFF -> 11
```

写 Python 脚本提取：

```python
with open("challenge.txt", "r", encoding="utf-8") as f:
    s = f.read()

mapping = {
    "\u200b": "00",
    "\u200c": "01",
    "\u200d": "10",
    "\ufeff": "11",
}

hidden_chars = ""

for c in s:
    if c in mapping:
        hidden_chars += c

bits = ""

for c in hidden_chars:
    bits += mapping[c]

data = bytes(
    int(bits[i:i+8], 2)
    for i in range(0, len(bits), 8)
)

print("hidden chars:", len(hidden_chars))
print("bits:", len(bits))
print("bytes:", len(data))
print("first bytes:", data[:32].hex())
```

输出中会看到：

```text
hidden chars: 2592
bits: 5184
bytes: 648
first bytes: 23f60579789c6593df4fdb3010c7ff95...
```

这说明我们成功从零宽字符里恢复出了一段 648 字节的二进制数据。

------

## 七、判断恢复出的二进制数据是什么

现在重点看开头字节：

```text
23 f6 05 79 78 9c ...
```

前 4 个字节：

```text
23 f6 05 79
```

看起来不像常见文件头。

但是从第 5 个字节开始：

```text
78 9c
```

这个非常重要。`78 9c` 是 zlib 压缩数据的典型开头。

常见压缩头可以记一下：

```text
1F 8B       gzip
78 9C       zlib
50 4B       zip
52 61 72    rar
89 50 4E 47 png
FF D8 FF    jpg
```

这里从偏移 4 开始出现 `78 9c`，说明前 4 个字节可能是干扰头、校验值、长度字段或者随机前缀，真正的 zlib 数据从第 4 字节之后开始。

所以尝试跳过前 4 字节进行 zlib 解压。

------

## 八、zlib 解压隐藏内容

使用 Python 解压：

```python
import zlib

plain = zlib.decompress(data[4:])

print(plain.decode("utf-8"))
```

如果方向正确，会得到一段 JSON 文本。

JSON 内容大致如下，敏感结果这里不直接展开 flag：

```json
{
  "aes": {
    "algorithm": "AES-256-CBC",
    "key_length": 32,
    "padding": "PKCS7"
  },
  "difficulty_bits": 26,
  "encrypted_flag": {
    "ciphertext": "...",
    "iv": "..."
  },
  "key_derivation": {
    "algorithm": "PBKDF2-HMAC-SHA256",
    "dklen": 32,
    "iterations": 10000,
    "password": "str(s) UTF-8",
    "salt": "nonce UTF-8"
  },
  "nonce": "inst_000_42ba6c3fb9863dfa",
  "pow": {
    "condition": "hash has at least difficulty_bits leading zero bits",
    "hash": "SHA-256",
    "input": "nonce || str(s), UTF-8",
    "search": "Start from s=0, increment, find minimum valid s"
  }
}
```

这一层已经把题目后半部分说得很清楚：

```text
1. 需要先做 PoW 搜索
2. 找到最小的 s
3. 用 str(s) 作为 password
4. 用 nonce 作为 salt
5. 通过 PBKDF2-HMAC-SHA256 派生 AES 密钥
6. 用 AES-256-CBC 解密 encrypted_flag
```

------

## 九、理解 PoW 是什么

PoW 全称是 Proof of Work，工作量证明。

这题里的要求是：

```text
从 s = 0 开始递增搜索
找到最小的 s
使 SHA256(nonce || str(s)) 的前 26 bit 都是 0
```

也就是计算：

```text
SHA256("inst_000_42ba6c3fb9863dfa" + str(s))
```

直到哈希值满足前导零条件。

因为哈希函数不可逆，所以没有捷径，只能暴力枚举。

这也对应题目描述里的：

```text
时间就是生命
比比看谁能先声夺人
```

真正考点是速度，也就是谁能更快找到满足条件的 s。

------

## 十、判断“前 26 bit 为 0”的条件

SHA-256 输出是 32 字节，也就是 256 bit。

前 26 bit 为 0，等价于：

```text
第 1 个字节 == 0x00
第 2 个字节 == 0x00
第 3 个字节 == 0x00
第 4 个字节的最高 2 bit == 0
```

为什么是这样？

因为：

```text
1 字节 = 8 bit
前 24 bit = 前 3 字节
还剩 2 bit
```

所以检查方式是：

```python
digest[0] == 0
digest[1] == 0
digest[2] == 0
digest[3] 的最高两位为 0
```

最高两位可以用掩码 `0xC0` 检查：

```text
0xC0 = 11000000
```

如果：

```python
digest[3] & 0xC0 == 0
```

就说明第四个字节最高两位都是 0。

------

## 十一、用 Python 搜索 s

可以写一个最直观的版本：

```python
import hashlib

nonce = "inst_000_42ba6c3fb9863dfa"
difficulty_bits = 26

def valid_digest(digest):
    return (
        digest[0] == 0 and
        digest[1] == 0 and
        digest[2] == 0 and
        (digest[3] & 0xC0) == 0
    )

s = 0

while True:
    message = nonce + str(s)
    digest = hashlib.sha256(message.encode("utf-8")).digest()

    if valid_digest(digest):
        print("s =", s)
        print("sha256 =", digest.hex())
        break

    s += 1
```

这个版本逻辑最清楚，但纯 Python 可能跑得比较久。因为期望搜索量大约是：

```text
2^26 ≈ 67,108,864 次
```

也就是说平均可能需要几千万次 SHA-256 运算。

这道题最终找到的 s 是：

```text
39235849
```

对应哈希是：

```text
0000003a61bb5cf11e82e63fdc3037f9e7dd85f46a26bc9b62f78b901f96f62e
```

开头是：

```text
00 00 00 3a
```

其中 `0x3a` 的二进制是：

```text
00111010
```

最高两位是 `00`，所以满足前 26 bit 为 0。

------

## 十二、如果 Python 太慢，怎么优化

初学者可以先用 Python 跑通逻辑。如果感觉太慢，有三种优化方法。

### 方法一：使用 PyPy

如果安装了 PyPy，可以直接：

```bash
pypy3 solve_pow.py
```

对这种大量循环的任务，PyPy 通常比 CPython 快。

### 方法二：多进程搜索

因为每个 s 的哈希计算互不影响，可以把不同范围分给多个进程。

例如：

```python
import hashlib
from multiprocessing import Pool, cpu_count

nonce = "inst_000_42ba6c3fb9863dfa"

def valid_digest(digest):
    return (
        digest[0] == 0 and
        digest[1] == 0 and
        digest[2] == 0 and
        (digest[3] & 0xC0) == 0
    )

def worker(args):
    start, step, limit = args

    s = start
    while s < limit:
        digest = hashlib.sha256((nonce + str(s)).encode()).digest()
        if valid_digest(digest):
            return s, digest.hex()
        s += step

    return None

if __name__ == "__main__":
    workers = cpu_count()
    limit = 100000000

    tasks = [
        (i, workers, limit)
        for i in range(workers)
    ]

    with Pool(workers) as pool:
        for result in pool.imap_unordered(worker, tasks):
            if result is not None:
                print(result)
                pool.terminate()
                break
```

这种方法会明显快很多。

### 方法三：写 C 程序

如果追求速度，可以写 C/C++ 调 OpenSSL 的 SHA256。CTF 里这类 PoW 搜索，C 语言通常明显快于 Python。

不过这题不一定必须写 C，Python 多进程已经够用了。

------

## 十三、用 s 派生 AES 密钥

JSON 里给出了密钥派生方式：

```text
algorithm: PBKDF2-HMAC-SHA256
password: str(s) UTF-8
salt: nonce UTF-8
iterations: 10000
dklen: 32
```

意思是：

```text
password = "39235849"
salt = "inst_000_42ba6c3fb9863dfa"
迭代次数 = 10000
输出长度 = 32 字节
```

为什么输出 32 字节？

因为 AES-256 的密钥长度是 256 bit：

```text
256 bit = 32 byte
```

派生代码：

```python
import hashlib

s_value = 39235849
nonce = "inst_000_42ba6c3fb9863dfa"

key = hashlib.pbkdf2_hmac(
    "sha256",
    str(s_value).encode("utf-8"),
    nonce.encode("utf-8"),
    10000,
    32
)

print(key.hex())
```

得到密钥：

```text
723a04d8d8c1310f18aaa4963cf9ec6bf1518cf8c41827a9848b69f837cdb17c
```

------

## 十四、AES-256-CBC 解密

JSON 里还给了：

```text
algorithm = AES-256-CBC
padding = PKCS7
iv = 5dc0b444e4ff507d4af8dcda8e64afa9
ciphertext = aa228292d48f64709888c44ce7c331b04e486e566f573fef354370c5f166d8ae68e6556e9607e1da07bc79203c092372
```

AES-CBC 解密需要三个东西：

```text
1. key
2. iv
3. ciphertext
```

我们已经通过 PoW 和 PBKDF2 得到了 key。

可以用 Python 解密：

```python
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import binascii

key = bytes.fromhex(
    "723a04d8d8c1310f18aaa4963cf9ec6bf1518cf8c41827a9848b69f837cdb17c"
)

iv = bytes.fromhex(
    "5dc0b444e4ff507d4af8dcda8e64afa9"
)

ciphertext = bytes.fromhex(
    "aa228292d48f64709888c44ce7c331b04e486e566f573fef354370c5f166d8ae68e6556e9607e1da07bc79203c092372"
)

cipher = AES.new(key, AES.MODE_CBC, iv)
plain = unpad(cipher.decrypt(ciphertext), AES.block_size)

print(plain.decode("utf-8"))
```

需要安装库：

```bash
pip install pycryptodome
```

解密后就能得到最终 flag。这里按你的要求隐藏：

```text
ISCC{************************************}
```

------

## 十五、完整解题脚本，隐藏 flag 输出

下面给一个完整脚本，适合复现整个流程。为了不直接显示 flag，最后只输出隐藏后的结果。

```python
import zlib
import json
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

# 1. 读取文本
with open("challenge.txt", "r", encoding="utf-8") as f:
    text = f.read()

# 2. 提取零宽字符
mapping = {
    "\u200b": "00",
    "\u200c": "01",
    "\u200d": "10",
    "\ufeff": "11",
}

hidden_chars = "".join(c for c in text if c in mapping)
bits = "".join(mapping[c] for c in hidden_chars)

print("[+] zero-width chars:", len(hidden_chars))
print("[+] bit length:", len(bits))

# 3. 转成字节
data = bytes(
    int(bits[i:i+8], 2)
    for i in range(0, len(bits), 8)
)

print("[+] hidden bytes:", len(data))
print("[+] first bytes:", data[:16].hex())

# 4. 跳过前 4 字节，zlib 解压
plain = zlib.decompress(data[4:])
config = json.loads(plain.decode("utf-8"))

print("[+] extracted JSON keys:", list(config.keys()))

# 5. 读取 PoW 参数
nonce = config["nonce"]
difficulty_bits = config["difficulty_bits"]

def has_leading_zero_bits(digest, bits):
    full_bytes = bits // 8
    remain_bits = bits % 8

    # 检查完整的 0 字节
    for i in range(full_bytes):
        if digest[i] != 0:
            return False

    # 检查剩余 bit
    if remain_bits == 0:
        return True

    mask = 0xff << (8 - remain_bits) & 0xff
    return (digest[full_bytes] & mask) == 0

# 6. 搜索最小 s
s = 0

while True:
    msg = nonce + str(s)
    digest = hashlib.sha256(msg.encode("utf-8")).digest()

    if has_leading_zero_bits(digest, difficulty_bits):
        print("[+] found s:", s)
        print("[+] sha256:", digest.hex())
        break

    s += 1

# 7. PBKDF2 派生密钥
key = hashlib.pbkdf2_hmac(
    "sha256",
    str(s).encode("utf-8"),
    nonce.encode("utf-8"),
    config["key_derivation"]["iterations"],
    config["key_derivation"]["dklen"]
)

print("[+] AES key:", key.hex())

# 8. AES-CBC 解密
iv = bytes.fromhex(config["encrypted_flag"]["iv"])
ciphertext = bytes.fromhex(config["encrypted_flag"]["ciphertext"])

cipher = AES.new(key, AES.MODE_CBC, iv)
flag = unpad(cipher.decrypt(ciphertext), AES.block_size).decode("utf-8")

# 9. 隐藏输出
prefix = flag[:5]
suffix = flag[-1]
hidden = prefix + "*" * (len(flag) - 6) + suffix

print("[+] flag:", hidden)
```

------

## 十六、这道题的完整思维链路

这题的关键不是某一个工具，而是分析路径要连贯。

### 第一步，先判断载体

解压后只有 `challenge.txt`，所以不要继续往图片、音频方向死磕。文本题优先检查编码、字符、空白和不可见字符。

### 第二步，发现零宽字符

文本表面正常，但统计 Unicode 后发现 4 种零宽字符大量出现。4 种字符刚好适合表示 2 bit，所以转成二进制是合理选择。

### 第三步，恢复隐藏二进制

2592 个零宽字符转成 5184 bit，也就是 648 字节。长度刚好整除 8，说明编码方式很可能正确。

### 第四步，识别 zlib

恢复出的数据从偏移 4 开始出现 `78 9c`，这是 zlib 头。跳过前 4 字节后解压，得到 JSON。

### 第五步，根据 JSON 做 PoW

JSON 直接说明需要搜索最小 s，使得 SHA-256 结果有 26 个前导零 bit。题目里的“时间就是生命”也对应这个计算量较大的搜索过程。

### 第六步，派生 AES 密钥

找到 s 后，用 PBKDF2-HMAC-SHA256 派生 32 字节 AES-256 密钥。

### 第七步，AES-CBC 解密

用 key、iv、ciphertext 解密，去掉 PKCS7 padding，得到最终 flag。

------

## 十七、初学者需要记住的经验

这类 MISC 文本隐写题，建议形成固定检查流程：

```text
1. file 判断类型
2. strings 查看可见字符串
3. xxd 查看十六进制
4. Python 统计异常字符
5. 检查零宽字符、空白字符、不可见字符
6. 尝试二进制恢复
7. 用文件头判断下一层格式
8. 遇到哈希前导零条件，考虑 PoW
9. 遇到 ciphertext、iv、salt、iterations，考虑标准密码学解密流程
```

这道题的核心考点可以概括为：

```text
零宽字符隐写 + zlib 压缩 + PoW 搜索 + PBKDF2 派生密钥 + AES-CBC 解密
```

最终 flag 已验证，按要求隐藏为：

```text
ISCC{************************************}
```