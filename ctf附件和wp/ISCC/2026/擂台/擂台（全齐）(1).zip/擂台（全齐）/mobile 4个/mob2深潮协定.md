# 深潮协定 WP

## 基本信息

- 题目：深潮协定
- 类型：Android / APK 逆向
- 难度分值：150
- 最终 Flag：`ISCC{abyssal_vows_bind_the_last_protocol}`

## 题目分析

拿到附件后先看 APK 结构，可以很快发现几个关键点：

- 存在自定义类：`FlagValidator`、`CryptoEngine`、`Telemetry`、`NativeBridge`
- 存在 native 库：`libdeepseal.so`
- `assets` 目录下有一个明显可疑的文件：`telemetry.bin`

这说明题目大概率是：

1. Java 层先对输入做一轮变换
2. native 层继续校验
3. `telemetry.bin` 提供协议参数或目标密文

## Java 层逻辑

### 1. FlagValidator.check

`FlagValidator.check` 的逻辑很直接：

- 先判断输入是否以 `ISCC{` 开头
- 再判断是否以 `}` 结尾
- 取出中间字符串
- 传给 `CryptoEngine.transform`
- 再把结果交给 `NativeBridge.verify`

可还原为：

```java
public static boolean check(Context ctx, String s) {
    if (s.startsWith("ISCC{") && s.endsWith("}")) {
        String body = s.substring(5, s.length() - 1);
        return NativeBridge.verify(ctx, CryptoEngine.transform(ctx, body));
    }
    return false;
}
```

### 2. Telemetry.load

`Telemetry.load` 会从 `assets/telemetry.bin` 中读取 4 行内容：

```text
0b04110916060d
1337c0de42a5197f
Qh2s7Ca9VxN4fKpB8J1mL+zoF0ewAyOu3DrRYSgPItU6McdkXl/WTnGEZ5ivbHjq
T8GHtJzYDRX7siXzWKLJCGlrpi1sVwnvMhZCPj3jwDWYU4Y=
```

其中：

- 第 1 行：`shifts`
- 第 2 行：`mask`
- 第 3 行：自定义 Base64 字母表
- 第 4 行：目标密文

### 3. CryptoEngine.transform

通过反编译可以还原出 Java 层核心变换：

```python
prev = 0
for i, c in enumerate(flag_body_ascii):
    v = c
    if 32 <= v <= 126:
        v = ((v - 32 + shifts[i % len(shifts)]) % 95) + 32
    prev = ((v ^ mask[i % len(mask)]) + prev + 3 * i) & 0xff
    out[i] = prev
```

含义是：

- 对可打印 ASCII 做循环位移
- 再与 `mask` 循环异或
- 再叠加上一轮结果 `prev`
- 最后再加上 `3 * i`

这层是一个带状态的前缀累加变换。

## Native 层逻辑

### 1. 自定义 Base64 解码

`NativeBridge.verify` 会再次读取 `telemetry.bin`，然后使用第 3 行的 64 字符表对第 4 行目标串做解码。

也就是说，这不是标准 Base64，而是“自定义字母表 Base64”。

### 2. 动态异或流

native 层不会直接比较 Java 输出，而是先对 Java 输出再做一次动态异或。

关键状态初值为 `0x5d`，每轮都会更新。根据反汇编可还原为一个 8-bit LFSR：

```python
fb = ((state >> 2) ^ (state >> 3) ^ (state >> 5) ^ state) & 1
state = ((state >> 1) | (fb << 7)) & 0xff
k = (state + 7 * i) & 0xff
```

随后执行：

```python
encoded[i] = transformed[i] ^ k
```

最后把这一结果与自定义 Base64 解码后的目标字节流比较。

## 逆向思路

既然校验链是：

```text
flag body
-> Java transform
-> native 动态异或
-> 与 telemetry.bin 目标字节比较
```

那么逆向就反着来：

1. 先对第 4 行目标串做自定义 Base64 解码
2. 逆掉 native 动态异或，得到 Java transform 的输出
3. 再逐字节逆 `CryptoEngine.transform`
4. 还原出 flag body

## 还原脚本

```python
import zipfile

apk = r"D:/00DownLoadings/app-release.apk"
lines = zipfile.ZipFile(apk).read("assets/telemetry.bin").decode().splitlines()

shifts = bytes.fromhex(lines[0])
mask = bytes.fromhex(lines[1])
alphabet = lines[2]
target = lines[3]

alpha_map = {c: i for i, c in enumerate(alphabet)}

# 1. 自定义 Base64 解码
decoded = bytearray()
for i in range(0, len(target), 4):
    chunk = target[i:i + 4]
    vals = [0 if ch == "=" else alpha_map[ch] for ch in chunk]
    pad = chunk.count("=")
    n = (vals[0] << 18) | (vals[1] << 12) | (vals[2] << 6) | vals[3]
    decoded.append((n >> 16) & 0xff)
    if pad < 2:
        decoded.append((n >> 8) & 0xff)
    if pad < 1:
        decoded.append(n & 0xff)

# 2. 逆 native 动态异或
state = 0x5d
transformed = []
for i, b in enumerate(decoded):
    fb = ((state >> 2) ^ (state >> 3) ^ (state >> 5) ^ state) & 1
    state = ((state >> 1) | (fb << 7)) & 0xff
    k = (state + 7 * i) & 0xff
    transformed.append(b ^ k)

# 3. 逆 Java transform
prev = 0
body = []
for i, t in enumerate(transformed):
    sols = []
    for c in range(128):
        v = c
        if 32 <= v <= 126:
            v = ((v - 32 + shifts[i % len(shifts)]) % 95) + 32
        out = ((v ^ mask[i % len(mask)]) + prev + 3 * i) & 0xff
        if out == t:
            sols.append(c)
    assert len(sols) == 1
    body.append(sols[0])
    prev = t

body = bytes(body).decode("ascii")
print("ISCC{" + body + "}")
```

运行输出：

```text
ISCC{abyssal_vows_bind_the_last_protocol}
```

## 关键点总结

- Java 层不是简单异或，而是“位移 + 异或 + 前缀累加”
- native 层的异或 key 不是固定值，而是一个滚动更新的 8-bit LFSR
- `telemetry.bin` 同时提供了：
  - Java 层参数
  - custom base64 字母表
  - 最终目标密文
- 题目的难点在于 Java 和 native 两层都带“状态”，如果只看单层很容易推偏

## 最终答案

```text
ISCC{abyssal_vows_bind_the_last_protocol}
```
