# EchoFold Android Reverse Writeup

## 题目信息

题面：

> 有人把一句话录进了回声里。第一声很像答案，第二声很像线索，第三声才开始说真话。

附件：`EchoFold(1).apk`

最终 flag：

```text
ISCC{f0lded_echo_is_a_state_not_a_string}
```

---

## 1. 基础信息收集

先查看 APK 文件结构：

```bash
file EchoFold\(1\).apk
unzip -l EchoFold\(1\).apk
```

关键文件：

```text
AndroidManifest.xml
resources.arsc
classes.dex
assets/sleep_loop.webp
META-INF/ECHOFOLD.SF
META-INF/ECHOFOLD.RSA
META-INF/MANIFEST.MF
```

这个 APK 没有 native so，主要逻辑在 `classes.dex` 和 `assets/sleep_loop.webp`。

---

## 2. 第一层假 flag

用 jadx 打开 APK，可以看到主界面点击 Check 后先调用：

```java
FirstEchoCodec.check(input)
```

如果通过，只会提示：

```text
first echo accepted, but not the real one.
```

也就是说第一声回声是假的。

静态字符串里可以看到类似：

```text
first echo is never the whole answer
```

并且第一层会诱导出：

```text
ISCC{this_is_only_the_first_echo}
```

这个不是最终 flag。

---

## 3. 真正校验入口 EchoGate.verify

继续看点击逻辑：

```java
if (FirstEchoCodec.check(s)) {
    status.setText("first echo accepted, but not the real one.");
    return;
}

if (EchoGate.verify(context, s)) {
    status.setText("correct");
} else {
    status.setText("nope");
}
```

真正 flag 校验在：

```java
com.iscc.echofold.EchoGate.verify(Context, String)
```

`verify` 主要流程：

```java
input = input.trim();
if (!input.startsWith("ISCC{") || !input.endsWith("}")) return false;
if (FirstEchoCodec.check(input)) return false;

body = input.substring(5, input.length() - 1);

rk    = resourceKey(context);
dexh  = sha256(classes.dex);
certh = sha256(apk signing cert der);
trace = TraceRecorder.snapshot();

blob_key = sha256("fold-echo" || rk || dexh || certh || trace);
enc_blob = readEchoChunk(context);
blob     = xorStream(enc_blob, blob_key);

检查 blob 头部是否为 EFVM；
解析 VM bytecode 和 target；
ks = runVm(code, rk, dexh, certh, trace, body_len);
return target == xorStream(body, ks);
```

---

## 4. 第二层：WebP 里的 ECH0 隐藏 chunk

题目资源里有：

```text
assets/sleep_loop.webp
```

`EchoGate.readEchoChunk()` 会解析 RIFF/WebP 结构，然后查找 chunk 名：

```text
ECH0
```

所以不能只看图片内容，要直接解析 WebP RIFF chunk。

解析逻辑：

```python
if webp[:4] != b"RIFF" or webp[8:12] != b"WEBP":
    raise ValueError("not webp")

pos = 12
while pos + 8 <= len(webp):
    tag = webp[pos:pos+4]
    size = int.from_bytes(webp[pos+4:pos+8], "little")
    data = webp[pos+8:pos+8+size]
    if tag == b"ECH0":
        return data
    pos += 8 + size + (size & 1)
```

---

## 5. key 组成

`ECH0` chunk 不是明文，需要先用 `xorStream` 解密。

### 5.1 resourceKey

`resourceKey()` 使用 `R.styleable.EchoFoldPulse` 派生 24 字节 key。

`R.styleable.EchoFoldPulse` 是：

```text
0x7f010000, 0x7f010001, ..., 0x7f01001f
```

派生逻辑：

```java
for (i = 0; i < 24; i++) {
    a = arr[i % arr.length];
    b = arr[(i + 1) % arr.length];
    out[i] = (byte)((((a & 0x7f) << 1) ^ ((b - a) & 0xff) ^ (i * 13)) & 0xff);
}
```

### 5.2 dex digest

```java
sha256(classes.dex)
```

### 5.3 cert digest

`certDigest()` 调用：

```java
context.getPackageManager()
       .getPackageInfo(packageName, 64)
       .signatures[0]
       .toByteArray()
```

所以这里不是直接 hash `META-INF/ECHOFOLD.RSA`，而是取其中的 X.509 证书 DER，再做 SHA-256。

可用 openssl 提取：

```bash
unzip -p EchoFold\(1\).apk META-INF/ECHOFOLD.RSA > ECHOFOLD.RSA
openssl pkcs7 -inform DER -in ECHOFOLD.RSA -print_certs -out cert.pem
openssl x509 -in cert.pem -outform DER -out cert.der
sha256sum cert.der
```

### 5.4 trace

`TraceRecorder` 静态数组：

```text
11 23 7a 42 51 66
```

即：

```python
trace = bytes([0x11, 0x23, 0x7a, 0x42, 0x51, 0x66])
```

---

## 6. xorStream 算法

`xorStream(data, key)` 不是简单循环 XOR，而是按 counter 派生 SHA-256 block：

```java
for counter = 0, 1, 2, ...:
    block = sha256(key || little_endian_u32(counter))
    data[i] ^= block[j]
```

Python 复现：

```python
def xor_stream(data, key):
    out = bytearray()
    ctr = 0
    pos = 0
    while pos < len(data):
        block = sha256(key + struct.pack("<I", ctr))
        for k in block:
            if pos >= len(data):
                break
            out.append(data[pos] ^ k)
            pos += 1
        ctr += 1
    return bytes(out)
```

解出 `ECH0` 后可以看到结构头：

```text
EFVM
```

头部结构：

```text
offset 0x00: magic = EFVM
offset 0x04: version = 1
offset 0x05: code_len, big endian, 2 bytes
offset 0x07: body_len, big endian, 2 bytes
offset 0x09: vm bytecode
after code: encrypted target
```

本题中：

```text
code_len = 0xc0 = 192
body_len = 0x23 = 35
```

---

## 7. 第三层：EFVM 虚拟机

`runVm()` 用：

```text
vm-seed || resourceKey || dexHash || certHash || trace
```

派生 8 个 32 位寄存器，然后解释 EFVM bytecode。

初始化：

```java
seed = sha256("vm-seed" || rk || dexh || certh || trace);
for i in range(8):
    reg[i] = little_u32(seed[i*4:i*4+4]) ^ (0x9e3779b9 * i);
```

VM 每条指令 4 字节：

```text
op, a, b, c
```

其中寄存器编号都取低 3 位。

注意点：`packed-switch` 的 case 顺序不是代码出现顺序。

switch 映射是：

```text
op & 7 == 0 -> 0x123
op & 7 == 1 -> 0x10f
op & 7 == 2 -> 0x0fe
op & 7 == 3 -> 0x0ea
op & 7 == 4 -> 0x0d7
op & 7 == 5 -> 0x0c2
op & 7 == 6 -> 0x0b1
op & 7 == 7 -> default -> 0x0a3
```

如果直接按反编译显示顺序写，会得到错误结果。

VM 跑完后输出 keystream：

```java
out[i] = reg[i & 7]
       ^ rol(reg[(i + 3) & 7], i & 31)
       ^ rk[i % rk.length]
       ^ dexh[i % 32]
       ^ certh[i % 32]
       ^ trace[i % trace.length];
```

最后：

```python
flag_body = target ^ vm_keystream
```

得到：

```text
f0lded_echo_is_a_state_not_a_string
```

最终 flag：

```text
ISCC{f0lded_echo_is_a_state_not_a_string}
```

---

## 8. EXP

保存为 `solve_echofold.py`：

```python
#!/usr/bin/env python3
import hashlib, struct, sys, tempfile, subprocess, zipfile
from pathlib import Path

MASK = 0xffffffff

def u32(x): return x & MASK

def rol(x, r):
    x &= MASK; r &= 31
    return ((x << r) | (x >> (32-r))) & MASK if r else x

def ror(x, r):
    x &= MASK; r &= 31
    return ((x >> r) | (x << (32-r))) & MASK if r else x

def reverse_bits32(x):
    x &= MASK
    return int(f'{x:032b}'[::-1], 2)

def reverse_bytes32(x):
    return struct.unpack('<I', struct.pack('>I', x & MASK))[0]

def sha256(b):
    return hashlib.sha256(b).digest()

def xor_stream(data, key):
    out = bytearray()
    ctr = 0
    pos = 0
    while pos < len(data):
        block = sha256(key + struct.pack('<I', ctr))
        for k in block:
            if pos >= len(data): break
            out.append(data[pos] ^ k)
            pos += 1
        ctr += 1
    return bytes(out)

def read_echo_chunk(webp):
    if webp[:4] != b'RIFF' or webp[8:12] != b'WEBP':
        raise ValueError('not webp/riff')
    off = 12
    while off + 8 <= len(webp):
        tag = webp[off:off+4]
        size = struct.unpack_from('<I', webp, off+4)[0]
        data = webp[off+8:off+8+size]
        if tag == b'ECH0':
            return data
        off += 8 + size + (size & 1)
    raise ValueError('missing ECH0')

def get_cert_der(rsa_bytes):
    with tempfile.TemporaryDirectory() as td:
        p7 = Path(td) / 'ECHOFOLD.RSA'
        pem = Path(td) / 'cert.pem'
        der = Path(td) / 'cert.der'
        p7.write_bytes(rsa_bytes)
        subprocess.check_call(['openssl', 'pkcs7', '-inform', 'DER', '-in', str(p7), '-print_certs', '-out', str(pem)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.check_call(['openssl', 'x509', '-in', str(pem), '-outform', 'DER', '-out', str(der)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return der.read_bytes()

def resource_key():
    arr = [0x7f010000 + i for i in range(32)]
    out = []
    for i in range(24):
        a = arr[i % len(arr)]
        b = arr[(i+1) % len(arr)]
        out.append(((((a & 0x7f) << 1) ^ ((b - a) & 0xff) ^ (i * 13)) & 0xff))
    return bytes(out)

def run_vm(code, rk, dexh, certh, trace, out_len):
    seed = sha256(b'vm-seed' + rk + dexh + certh + trace)
    regs = [u32(struct.unpack_from('<I', seed, i*4)[0] ^ u32(0x9e3779b9 * i)) for i in range(8)]
    pc = 0
    while pc + 3 < len(code):
        op = code[pc]
        a = code[pc+1] & 7
        b = code[pc+2] & 7
        c = code[pc+3] & 7
        idx = pc // 4
        mix = rk[idx % len(rk)] ^ dexh[(pc//2) % len(dexh)] ^ certh[(pc//3) % len(certh)] ^ trace[idx % len(trace)]
        mix &= 0xff
        t = op & 7
        if t == 7:
            regs[a] = u32(regs[a] + (mix ^ regs[b] ^ regs[c]) + pc)
        elif t == 6:
            regs[a] = u32((regs[a] ^ regs[b] ^ mix) + reverse_bits32(regs[c] + pc))
        elif t == 5:
            regs[a] = u32(rol(regs[b] + regs[c] + mix, (pc + a + b) & 31) ^ regs[a])
        elif t == 4:
            regs[a] = u32(regs[a] + ror(mix ^ regs[b] ^ pc, (c + a + 1) & 31))
        elif t == 3:
            old = regs[a]
            regs[a] = u32(regs[b] + mix)
            regs[b] = u32(ror(regs[c] + pc, mix & 31) ^ old)
        elif t == 2:
            regs[a] = u32(regs[a] ^ ((reverse_bytes32(regs[c]) ^ regs[b]) + mix))
        elif t == 1:
            regs[a] = u32(rol(regs[a] + regs[b] + ((mix << 1) & MASK) + c, (b + c + pc) & 31))
        elif t == 0:
            regs[a] = u32(rol(regs[b] + mix + pc, (c + mix) & 31) ^ regs[a])
        pc += 4

    out = bytearray()
    for i in range(out_len):
        v = regs[i & 7] ^ rol(regs[(i+3) & 7], i & 31) ^ rk[i % len(rk)] ^ dexh[i % 32] ^ certh[i % 32] ^ trace[i % len(trace)]
        out.append(v & 0xff)
    return bytes(out)

def solve(apk_path):
    with zipfile.ZipFile(apk_path, 'r') as z:
        dex = z.read('classes.dex')
        webp = z.read('assets/sleep_loop.webp')
        rsa = z.read('META-INF/ECHOFOLD.RSA')

    rk = resource_key()
    dexh = sha256(dex)
    certh = sha256(get_cert_der(rsa))
    trace = bytes([0x11, 0x23, 0x7a, 0x42, 0x51, 0x66])

    enc_blob = read_echo_chunk(webp)
    blob_key = sha256(b'fold-echo' + rk + dexh + certh + trace)
    blob = xor_stream(enc_blob, blob_key)

    assert blob[:4] == b'EFVM'
    code_len = (blob[5] << 8) | blob[6]
    body_len = (blob[7] << 8) | blob[8]
    code = blob[9:9+code_len]
    target = blob[9+code_len:]

    ks = run_vm(code, rk, dexh, certh, trace, body_len)
    body = bytes(c ^ k for c, k in zip(target, ks)).decode()
    return f'ISCC{{{body}}}', code_len, body_len

if __name__ == '__main__':
    apk = sys.argv[1] if len(sys.argv) > 1 else 'EchoFold(1).apk'
    flag, clen, blen = solve(apk)
    print('[+] code_len =', clen)
    print('[+] body_len =', blen)
    print('[+] flag =', flag)
```

运行：

```bash
python3 solve_echofold.py 'EchoFold(1).apk'
```

输出：

```text
[+] code_len = 192
[+] body_len = 35
[+] flag = ISCC{f0lded_echo_is_a_state_not_a_string}
```
