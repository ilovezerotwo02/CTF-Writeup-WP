# 深海金库 Mobile 题 WP

---

## 0. 题目信息与第一判断

题目描述：

> 深海金库。你在马里亚纳海沟的一艘废弃潜水器中发现了一个密封的金库。金库的显示屏上只有一行跳动的乱码和一张磨损的海螺照片。潜水器的操作指南上写着：“秘密深藏于耐心之中，而开启的旋律会随深度起伏。”

附件是一个 APK：`app-release-01.apk`。

看到 **Mobile 类型 + APK**，第一反应一般不是直接猜 flag，而是按下面的顺序排查：

1. APK 本质上是 zip，先解包看结构；
2. 找 Java/Kotlin 层逻辑，也就是 `classes.dex`；
3. 看是否有 native so，如果有，Java 层可能只是壳，真正校验在 native；
4. 看资源文件，比如图片、音频、assets，判断题目描述中的“海螺照片”是不是隐写线索；
5. 如果发现输入框、flag 校验函数、JNI 函数，就优先逆校验逻辑。

本题最后的主线是：

```text
用户输入 flag
    ↓
Java 层检查 ISCC{...} 格式
    ↓
取出花括号内部内容
    ↓
Java 层做一次字符变换
    ↓
native 层做 Fibonacci 异或流
    ↓
native 层做自定义 Base64
    ↓
和目标字符串比较
```

所以我们要做的事情就是把这条链路倒过来。

---

## 1. 基础文件检查

先确认附件类型和哈希。

```bash
file app-release-01.apk
sha256sum app-release-01.apk
```

结果：

```text
app-release-01.apk: Android package (APK), with gradle app-metadata.properties, with APK Signing Block
44c51a2100afbad3b25a0b11cf4fee58ccac781fd8bd3fc752a39607bdfb3d3a  app-release-01.apk
```

APK 是正常的 Android 安装包。

---

## 2. 解包 APK

APK 可以直接用 `unzip` 解开：

```bash
mkdir apkwork
unzip -q app-release-01.apk -d apkwork
find apkwork -maxdepth 3 -type f | head -80
```

能看到这些关键文件：

```text
classes.dex
classes2.dex
AndroidManifest.xml
lib/arm64-v8a/libsecure_verify.so
lib/armeabi-v7a/libsecure_verify.so
lib/x86/libsecure_verify.so
lib/x86_64/libsecure_verify.so
res/...
assets/...
```

这里有两个重要信号：

第一，存在 `classes.dex` 和 `classes2.dex`，说明有 Java/Kotlin 层逻辑；

第二，存在 `libsecure_verify.so`，说明这个 APK 使用了 native 层，也就是 JNI。CTF Mobile 题里，如果出现 native so，flag 校验很可能会被放在 so 中，因为 native 反编译比 Java 层麻烦。

---

## 3. 先用 strings 粗定位关键线索

做逆向不要一上来就打开 IDA/Ghidra 深挖。初学阶段建议先用 `strings` 搜索明显关键词。

```bash
strings -a apkwork/classes.dex | grep -E "ISCC|Flag|Crypto|native|secure|Deep|Vault|mobile02"
```

可以看到类似内容：

```text
CryptoEngine.java
Deep Sea Vault Opened.
FlagValidator.java
ISCC{
Lcom/example/mobile02/CryptoEngine;
Lcom/example/mobile02/FlagValidator;
Lcom/example/mobile02/MainActivity;
nativeVerify
performTransformation
secure_verify
```

这一步给了我们几个方向：

| 线索 | 意义 |
|---|---|
| `ISCC{` | flag 格式检查很可能在 Java 层 |
| `FlagValidator` | 明显是 flag 校验类 |
| `CryptoEngine` | 明显是加密/变换类 |
| `nativeVerify` | Java 会调用 native 函数 |
| `secure_verify` | native 库名，对应 `libsecure_verify.so` |
| `Deep Sea Vault Opened.` | 校验成功提示 |

到这里，不需要再盲目翻所有代码了。我们已经知道应该重点看：

```text
com.example.mobile02.MainActivity
com.example.mobile02.FlagValidator
com.example.mobile02.CryptoEngine
libsecure_verify.so
```

---

## 4. 查看 Java 层逻辑

实际做题时，推荐用 JADX：

```bash
jadx-gui app-release-01.apk
```

然后搜索：

```text
FlagValidator
CryptoEngine
nativeVerify
secure_verify
ISCC{
```

如果没有 GUI，也可以先用 `strings` 和 DEX 反汇编辅助定位。本文下面直接给出关键逻辑的还原结果。

---

## 5. MainActivity：确认 native 库加载

在 `MainActivity` 中能看到类似逻辑：

```java
static {
    System.loadLibrary("secure_verify");
}

public native boolean nativeVerify(byte[] data);
```

这里要理解 Android JNI 的命名关系：

```java
System.loadLibrary("secure_verify");
```

对应 APK 里的文件就是：

```text
lib/*/libsecure_verify.so
```

也就是说，Java 层调用 `nativeVerify` 时，实际会进入这个 so 里的 C/C++ 代码。

这个地方是本题的分界点：

- Java 层负责输入格式和初步处理；
- so 层负责最终校验。

---

## 6. FlagValidator：确定 flag 外壳和校验流程

`FlagValidator.isFormatValid()` 只检查格式：

```java
public static boolean isFormatValid(String input) {
    return input != null
        && input.startsWith("ISCC{")
        && input.endsWith("}");
}
```

这个函数告诉我们，完整 flag 必须是：

```text
ISCC{某段内容}
```

`FlagValidator.doFinalCheck()` 才是真正进入校验链的函数：

```java
public static boolean doFinalCheck(MainActivity activity, String input) {
    String core = input.substring(5, input.length() - 1);
    byte[] transformed = CryptoEngine.performTransformation(core);
    return activity.nativeVerify(transformed);
}
```

这段代码非常关键。它说明：

```text
完整输入：ISCC{xxxxxxxx}
取出的 core：xxxxxxxx
```

后续所有加密、比较都只针对花括号里面的内容，不包含 `ISCC{` 和 `}`。

所以之后我们真正要反推的是：

```text
flag 中间的 core 部分
```

最后再拼回：

```text
ISCC{core}
```

---

## 7. CryptoEngine：还原 Java 层变换

继续看 `CryptoEngine.performTransformation()`。

还原后的伪代码如下：

```java
public static byte[] performTransformation(String s) {
    byte[] arr = s.getBytes(StandardCharsets.US_ASCII);
    int prev = 0;

    for (int i = 0; i < arr.length; i++) {
        int x = arr[i] & 0xff;

        if (x >= 32 && x <= 126) {
            x = ((x - 25) % 95) + 32;
        }

        int delta;
        if (i % 2 == 0) {
            delta = 8;
        } else {
            delta = -8;
        }

        x = x + delta + (prev % 4);
        prev = x & 0xff;
        arr[i] = (byte) prev;
    }

    return arr;
}
```

这段代码可以分三层理解。

### 7.1 第一层：转成 ASCII 字节

```java
byte[] arr = s.getBytes(StandardCharsets.US_ASCII);
```

说明 flag core 应该是普通 ASCII 字符。

### 7.2 第二层：可打印字符位移

```java
if (x >= 32 && x <= 126) {
    x = ((x - 25) % 95) + 32;
}
```

ASCII 可打印字符范围是：

```text
32 到 126
```

一共有：

```text
126 - 32 + 1 = 95
```

所以这里是对可打印字符做一个循环位移。可以理解成：

```text
在 95 个可打印字符组成的环上移动
```

它不是普通 base64，不是 md5，也不是 AES，只是字符表内的循环变换。

### 7.3 第三层：根据位置和前一个结果扰动

```java
int delta = (i % 2 == 0) ? 8 : -8;
x = x + delta + (prev % 4);
prev = x & 0xff;
```

这里有两个小坑：

1. 偶数下标加 `8`，奇数下标减 `8`；
2. 当前字符还依赖上一个输出字节 `prev`。

因此不能完全逐字符独立看，但因为 `prev` 是前一个输出，而我们逆向时也能从目标数据中得到前一个输出，所以仍然可以从左到右反推。

到这里，Java 层变换链已经明确。

---

## 8. 为什么下一步要看 native so？

Java 层最后调用的是：

```java
activity.nativeVerify(transformed)
```

也就是说 Java 只把处理后的字节数组交给 native 层，自己没有直接比较最终答案。

所以这时下一步很自然：分析 `libsecure_verify.so`。

APK 里有多个架构的 so：

```text
lib/arm64-v8a/libsecure_verify.so
lib/armeabi-v7a/libsecure_verify.so
lib/x86/libsecure_verify.so
lib/x86_64/libsecure_verify.so
```

它们通常逻辑相同，只是 CPU 架构不同。为了静态分析方便，可以选 `x86_64` 版本，因为 x86_64 汇编对初学者相对更容易读。

---

## 9. 查看 so 导出符号

使用 `readelf`：

```bash
readelf -Ws apkwork/lib/x86_64/libsecure_verify.so | grep -E "verify|encode|fib|JNI"
```

可以看到：

```text
_Z13verify_bridgeP7_JNIEnvP8_jobjectP11_jbyteArray
_Z18process_fib_streamPhi
_Z10encode_b64RKNSt6__ndk16vectorIhNS_9allocatorIhEEEE
_ZN2SV1vEPKhi
JNI_OnLoad
```

这些 C++ 符号名被 mangling 过，但还是能看出函数含义：

| 符号 | 大致含义 |
|---|---|
| `verify_bridge` | JNI 桥接函数，连接 Java 和 C++ |
| `SV::v` | 真正的 verify 函数 |
| `process_fib_stream` | 处理 Fibonacci 流 |
| `encode_b64` | Base64 编码 |
| `JNI_OnLoad` | so 被加载时执行，用于注册 JNI |

题目描述里有一句：

> “秘密深藏于耐心之中，而开启的旋律会随深度起伏。”

现在看到 `process_fib_stream`，就能和“起伏”“旋律”对应起来：它暗示了一种按序列变化的流，而这里就是 Fibonacci 序列。

---

## 10. native 主校验函数 SV::v

用 IDA/Ghidra 打开 so 会更舒服。命令行可以用：

```bash
objdump -d -Mintel apkwork/lib/x86_64/libsecure_verify.so > so.asm
```

从 `readelf` 结果可知，`SV::v` 地址在 `0x215f0` 附近。反汇编关键逻辑可概括为：

```cpp
bool SV::v(unsigned char const* input, int len) {
    if (input == nullptr || len <= 0) {
        return false;
    }

    vector<unsigned char> buf(input, input + len);

    process_fib_stream(buf.data(), len);

    string encoded = encode_b64(buf);

    string target = "cUdltutGeWWI";
    target.append("Um+7OE4ce3wi");

    return encoded == target;
}
```

这里有两个重点。

第一，native 层没有直接比较 Java 传进来的原始字节，而是：

```text
Java 变换后的字节
    ↓
Fibonacci 异或流
    ↓
自定义 Base64 编码
    ↓
和目标字符串比较
```

第二，目标字符串不是完整明文放在 `.rodata` 里，而是拆成两部分：

```text
cUdltutGeWWI
Um+7OE4ce3wi
```

拼起来是：

```text
cUdltutGeWWIUm+7OE4ce3wi
```

这种拆字符串是 CTF 里常见的小混淆。直接 `strings` 搜可能搜不到完整目标，但在反编译里能看到它被拼接出来。

---

## 11. process_fib_stream：Fibonacci 异或流

`process_fib_stream` 是本题 native 层的核心之一。

反汇编里能看到它用两个字节状态：

```asm
mov cl, 0x1
mov dl, 0x1
...
xor BYTE PTR [rdi+rsi], cl
xor BYTE PTR [rdi+rsi+1], dl
add cl, dl
xor BYTE PTR [rdi+rsi+2], cl
add dl, cl
xor BYTE PTR [rdi+rsi+3], dl
```

换成更容易读的伪代码：

```cpp
void process_fib_stream(unsigned char* data, int len) {
    unsigned char a = 1;
    unsigned char b = 1;

    for (int i = 0; i < len; i++) {
        data[i] ^= a;
        unsigned char c = a + b;
        a = b;
        b = c;
    }
}
```

它产生的异或流是：

```text
01 01 02 03 05 08 0d 15 22 37 59 90 e9 79 62 db 3d 18 ...
```

注意这里是字节运算，超过 `0xff` 后自然截断，相当于 `% 256`。

这类操作的逆向非常简单，因为 XOR 自反：

```text
A xor K = B
B xor K = A
```

所以加密和解密用同一个操作。

---

## 12. encode_b64：自定义 Base64

`encode_b64` 看起来像 Base64，但是它没有使用标准 Base64 字母表。

标准 Base64 字母表是：

```text
ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/
```

而本题 native 中的字母表是：

```text
zKJUExRaVtM3Ydv5TQIsWD1frnHC78Lckl6euPh9AGoj0SgN4Zp+OwXi2F/ybmBq
```

这一步可以通过两种方式发现。

方法一：直接在 so 中搜长字符串：

```bash
strings -a apkwork/lib/x86_64/libsecure_verify.so | grep "zKJ"
```

方法二：在 IDA/Ghidra 里看 `encode_b64` 对字符表的引用。

`encode_b64` 的逻辑和普通 Base64 基本一致：

```text
3 个字节分成 4 组 6 bit
每组 6 bit 当作下标
去自定义 alphabet 里取字符
最后不足 3 字节时补 =
```

因此逆向时不需要暴力破解，只要用同一个字母表写一个自定义 Base64 解码即可。

---

## 13. 现在整理正向校验链

假设我们输入的是：

```text
ISCC{core}
```

程序的正向校验流程是：

```text
core
  ↓ Java: CryptoEngine.performTransformation
java_transformed_bytes
  ↓ native: process_fib_stream XOR Fibonacci
fib_processed_bytes
  ↓ native: custom Base64 encode
encoded_string
  ↓ compare
cUdltutGeWWIUm+7OE4ce3wi
```

所以我们反推时要倒着来：

```text
cUdltutGeWWIUm+7OE4ce3wi
  ↓ 自定义 Base64 解码
fib_processed_bytes
  ↓ Fibonacci XOR 还原
java_transformed_bytes
  ↓ 逆 Java 层变换
core
  ↓ 拼接格式
ISCC{core}
```

这是逆向题中最重要的思维方式之一：

> 不要试图“猜输入”，而是把程序的每一步变换写出来，然后从最终比较值逆回去。

---

## 14. 第一步反推：自定义 Base64 解码

目标字符串是：

```python
target = "cUdltutGeWWIUm+7OE4ce3wi"
```

自定义字母表是：

```python
alphabet = "zKJUExRaVtM3Ydv5TQIsWD1frnHC78Lckl6euPh9AGoj0SgN4Zp+OwXi2F/ybmBq"
```

解码脚本：

```python
def custom_b64_decode(s, alphabet):
    out = bytearray()

    for i in range(0, len(s), 4):
        block = s[i:i + 4]
        nums = []

        for ch in block:
            if ch == "=":
                nums.append(0)
            else:
                nums.append(alphabet.index(ch))

        triple = (nums[0] << 18) | (nums[1] << 12) | (nums[2] << 6) | nums[3]

        out.append((triple >> 16) & 0xff)
        if block[2] != "=":
            out.append((triple >> 8) & 0xff)
        if block[3] != "=":
            out.append(triple & 0xff)

    return bytes(out)
```

解出来的中间结果是：

```text
7c 33 61 26 42 69 8d 45 12 0f dc dc d0 4c 1f 8c bd 77
```

这不是最终 flag，而是经过 Fibonacci 异或流处理后的字节。

---

## 15. 第二步反推：还原 Fibonacci XOR

正向是：

```text
data[i] ^= fib[i]
```

逆向仍然是：

```text
data[i] ^= fib[i]
```

脚本：

```python
def fib_xor(data):
    data = bytearray(data)
    a = 1
    b = 1

    for i in range(len(data)):
        data[i] ^= a & 0xff
        a, b = b, (a + b) & 0xff

    return bytes(data)
```

对上一步结果再异或 Fibonacci 流，得到 Java 层变换后的字节：

```text
7d 32 63 25 47 61 80 50 30 38 85 4c 39 35 7d 57 80 6f
```

这个结果仍然不是 flag core，因为它是 `CryptoEngine.performTransformation(core)` 的输出。

---

## 16. 第三步反推：逆 Java 层变换

Java 正向变换是：

```python
x = 原字符 ASCII

如果 x 是可打印字符：
    x = ((x - 25) % 95) + 32

如果 i 是偶数：
    delta = 8
否则：
    delta = -8

x = x + delta + (prev % 4)
prev = x & 0xff
输出 prev
```

现在我们已经知道每一位的输出 `y`，也就是：

```text
7d 32 63 25 47 61 80 50 30 38 85 4c 39 35 7d 57 80 6f
```

因为 `prev` 指的是前一个输出值，而这些输出值我们都已知，所以可以从左到右反推。

最稳妥的写法不是手推公式，而是枚举每一位可能的可打印字符：

```python
for ch in range(32, 127):
    # 把 ch 走一遍 Java 正向逻辑
    # 如果结果等于当前 y，就说明 ch 是这一位原字符
```

这样可以避免 Java `%`、byte 截断、负数等细节坑。

---

## 17. 完整求解脚本，输出已打码

下面是完整脚本。为了遵守本文档的要求，脚本最后默认只输出打码后的 flag。

```python
alphabet = "zKJUExRaVtM3Ydv5TQIsWD1frnHC78Lckl6euPh9AGoj0SgN4Zp+OwXi2F/ybmBq"
target = "cUdltutGeWWIUm+7OE4ce3wi"


def custom_b64_decode(s, alphabet):
    out = bytearray()

    for i in range(0, len(s), 4):
        block = s[i:i + 4]
        nums = []

        for ch in block:
            if ch == "=":
                nums.append(0)
            else:
                nums.append(alphabet.index(ch))

        triple = (nums[0] << 18) | (nums[1] << 12) | (nums[2] << 6) | nums[3]

        out.append((triple >> 16) & 0xff)
        if block[2] != "=":
            out.append((triple >> 8) & 0xff)
        if block[3] != "=":
            out.append(triple & 0xff)

    return bytes(out)


def fib_xor(data):
    data = bytearray(data)
    a = 1
    b = 1

    for i in range(len(data)):
        data[i] ^= a & 0xff
        a, b = b, (a + b) & 0xff

    return bytes(data)


def java_forward_one(ch, i, prev):
    x = ch

    if 32 <= x <= 126:
        x = ((x - 25) % 95) + 32

    if i % 2 == 0:
        delta = 8
    else:
        delta = -8

    x = x + delta + (prev % 4)
    return x & 0xff


def reverse_java(transformed):
    result = []
    prev = 0

    for i, y in enumerate(transformed):
        candidates = []

        for ch in range(32, 127):
            if java_forward_one(ch, i, prev) == y:
                candidates.append(ch)

        if len(candidates) != 1:
            raise RuntimeError(f"第 {i} 位候选数量异常: {candidates}")

        result.append(chr(candidates[0]))
        prev = y

    return "".join(result)


def mask_flag(flag):
    # 只展示前缀和一小段，隐藏核心答案
    left = flag[:11]
    right = flag[-2:]
    return left + "*" * (len(flag) - len(left) - len(right)) + right


stage1 = custom_b64_decode(target, alphabet)
print("custom b64 decode:", stage1.hex(" "))

stage2 = fib_xor(stage1)
print("after fib xor:", stage2.hex(" "))

core = reverse_java(stage2)
flag = "ISCC{" + core + "}"

print("masked flag:", mask_flag(flag))
```

运行后可以看到：

```text
custom b64 decode: 7c 33 61 26 42 69 8d 45 12 0f dc dc d0 4c 1f 8c bd 77
after fib xor:     7d 32 63 25 47 61 80 50 30 38 85 4c 39 35 7d 57 80 6f
masked flag:       ISCC{n2R#7**********p}
```

完整 flag 在本文档中按要求隐藏。

---

## 18. 回过头看题目描述的暗示

题目描述不是完全没用，它其实在暗示流程中的一些点：

| 描述 | 可能对应 |
|---|---|
| “密封的金库” | 输入正确 flag 才能打开 |
| “跳动的乱码” | 字符变换、异或、编码后的不可读数据 |
| “磨损的海螺照片” | 资源文件里的干扰项或氛围线索，提示不要只盯 UI |
| “秘密深藏于耐心之中” | 需要逐层分析，不是 strings 一把梭 |
| “旋律会随深度起伏” | Fibonacci 序列异或流，数值随位置起伏变化 |

做 CTF 时，题目文案经常有两种作用：

1. 给真实算法提示；
2. 给场景包装和干扰。

本题中真正有价值的是“起伏”这一类描述，与 Fibonacci 流比较贴合。

---

## 19. 初学者做这类题的通用思路

这题可以总结成一套 Mobile 逆向题通用流程。

### 19.1 先看文件结构

```bash
unzip app.apk -d out
find out -maxdepth 3 -type f
```

重点看：

```text
classes.dex
classes2.dex
lib/*.so
assets/
res/
```

### 19.2 再用 strings 快速找关键字

```bash
strings -a classes.dex | grep -E "flag|Flag|check|verify|native|ISCC|CTF"
strings -a lib/xxx.so | grep -E "flag|verify|base|xor|key|target"
```

不要小看 `strings`。很多时候它可以帮你先定位类名、函数名、成功提示、native 库名。

### 19.3 Java 层看三类函数

1. 输入框监听、按钮点击事件；
2. 格式检查函数，比如 `startsWith("ISCC{")`；
3. 加密或校验函数，比如 `check`、`verify`、`validate`、`CryptoEngine`。

### 19.4 出现 nativeVerify 就去看 so

如果 Java 层出现：

```java
System.loadLibrary(...)
public native boolean nativeVerify(...)
```

就说明最终逻辑很可能不在 DEX 里，而在 so 里。

### 19.5 native 里先看导出符号

```bash
readelf -Ws libxxx.so | grep -E "verify|check|encode|decode|xor|JNI"
```

如果符号没有被完全 strip，函数名会直接给很多提示。

### 19.6 把正向流程画出来

本题的正向流程是：

```text
core
→ Java printable rotate
→ Java odd/even delta + prev state
→ Fibonacci XOR
→ custom Base64
→ compare target
```

画出流程后，就反过来写脚本。

### 19.7 尽量用脚本反推，不要手算

手算容易错，尤其是涉及：

- byte 截断；
- `% 256`；
- Java signed byte；
- 自定义 base64；
- 前后状态依赖。

所以更稳的做法是：

```text
能写正向函数，就写正向函数；
逆不出来时，就枚举候选字符，看谁走正向能对上。
```

本题 Java 层逆变换就是这个思路。

---

## 20. 本题最终结论，打码版

最终 flag 结构为：

```text
ISCC{n2R#7**********p}
```

完整内容已隐藏。

---

## 21. 易错点总结

1. **不要只搜完整 flag**  
   本题完整 flag 不会直接出现在 APK 字符串中。

2. **不要忽略 native so**  
   Java 层 `nativeVerify` 已经明确提示最终校验在 so 里。

3. **不要把标准 Base64 字母表拿来直接解**  
   本题是自定义 alphabet，标准 `base64.b64decode()` 会得到错误结果。

4. **注意 Fibonacci 流是字节级运算**  
   加法超过 `0xff` 后会截断。

5. **Java 层有前一字节状态 `prev`**  
   逆向时要从左到右处理，每一步更新 `prev`。

6. **用枚举反 Java 层更稳**  
   对初学者来说，比硬推公式更不容易踩坑。

---

## 22. 一句话复盘

这道题的核心不是复杂密码学，而是典型 Mobile 逆向链路：

```text
Java 格式检查 + Java 字符变换 + JNI native 校验 + 自定义编码 + XOR 流
```

把每一层都拆开，再按相反顺序还原，就可以得到答案。
