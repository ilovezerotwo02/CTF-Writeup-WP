# 像素迷宫 WP

## 一、题目理解

题目名是“像素迷宫”，描述是：

> 是像素不是 0 和 1。

这句话非常关键。它暗示题目里虽然出现了“像素”，但不要把像素简单理解成黑白二值图，也就是不要只想着 `0` 表示墙，`1` 表示路。

这类逆向题常见思路是：程序内部藏了一张“迷宫图”，输入的 flag 其实是一串路径，程序会根据这串路径判断是否能从起点走到终点。

本题最后的输入格式是：

```text
ISCC{路径字符串}
```

路径字符串由 `E`、`N`、`S`、`W` 组成，分别表示东、北、南、西四个方向。

真实 flag 在这里隐藏为：

```text
ISCC{<hidden_path>}
```

------

## 二、解压附件并识别文件类型

附件是一个 zip 压缩包，先解压：

```bash
unzip Flag1.zip
```

解压后得到：

```text
PixelMaze.exe
```

查看文件类型：

```bash
file PixelMaze.exe
```

结果大致是：

```text
PE32+ executable for MS Windows, x86-64
```

说明这是一个 Windows 64 位可执行程序，也就是一个典型的 RE 题二进制。

------

## 三、先用 strings 看程序表层信息

逆向题不要一上来就直接进 IDA 或 Ghidra，先用 `strings` 看看有没有明显字符串：

```bash
strings -n 4 PixelMaze.exe | grep -Ei "ISCC|PixelMaze|Correct|Incorrect|Enter"
```

可以看到类似信息：

```text
ISCC{
===PixelMaze===
Enter flag:
Incorrect!
Correct!
PixelMaze1.cpp
```

这几行信息说明：

第一，程序会要求用户输入 flag。

第二，flag 前缀是 `ISCC{`。

第三，程序有 `Correct!` 和 `Incorrect!` 两个分支。

第四，程序里还能看到源码文件名 `PixelMaze1.cpp`，说明这个程序没有做很强的符号去除，对逆向非常有利。

------

## 四、查看符号表，定位关键函数

因为程序符号没有完全去掉，可以直接用 `objdump` 查看函数名：

```bash
objdump -t PixelMaze.exe | grep -Ei "Pixel|Path|Move|main"
```

可以看到几个非常关键的函数：

```text
_Z12decryptPixeli
_Z17getDecryptedPixelii
_Z11isValidMoveiic
_Z12validatePathRKNSt7__cxx1112basic_string...
_Z11extractPathRKNSt7__cxx1112basic_string...
main
```

这些是 C++ 的符号名，经过 demangle 后大概是：

```cpp
decryptPixel(int)
getDecryptedPixel(int, int)
isValidMove(int, int, char)
validatePath(std::string const&)
extractPath(std::string const&)
main()
```

从名字就能猜出大致逻辑：

| 函数                | 作用推测                         |
| ------------------- | -------------------------------- |
| `main`              | 主函数，读取输入并输出正确或错误 |
| `extractPath`       | 从 flag 中提取路径字符串         |
| `validatePath`      | 验证路径是否合法                 |
| `isValidMove`       | 判断某个方向能不能走             |
| `getDecryptedPixel` | 取出某个位置的像素值并解密       |
| `decryptPixel`      | 解密单个像素                     |

这一步非常重要。逆向时不要从整个程序硬啃，而是先找和输入校验直接相关的函数。

------

## 五、分析 main 函数

用 IDA 或 Ghidra 打开程序，找到 `main`。

主函数逻辑很直观，大致可以还原成：

```cpp
int main() {
    std::string input;
    std::string path;

    std::cout << "===PixelMaze===" << std::endl;
    std::cout << "Enter flag:" << std::endl;

    std::getline(std::cin, input);

    path = extractPath(input);

    if (!path.empty() && validatePath(path)) {
        std::cout << "Correct!" << std::endl;
    } else {
        std::cout << "Incorrect!" << std::endl;
    }

    return 0;
}
```

所以程序的核心不在 `main`，而在：

```cpp
extractPath(input)
validatePath(path)
```

先提取路径，再验证路径。

------

## 六、分析 extractPath：确定 flag 格式

继续看 `extractPath`。

这个函数主要做三件事。

### 1. 检查输入长度

反汇编里有类似逻辑：

```asm
cmp QWORD PTR [rdx+0x8], 0x6
jbe ...
```

意思是输入长度必须大于 6。

为什么是 6？

因为最短格式类似：

```text
ISCC{}
```

长度就是 6。如果长度不够，肯定不是合法 flag。

------

### 2. 检查前缀是否为 ISCC{

在 `extractPath` 中可以看到它取输入前 5 个字符，然后和字符串比较：

```text
ISCC{
```

所以输入必须以：

```text
ISCC{
```

开头。

------

### 3. 检查结尾是否为 }

反汇编里有一处比较：

```asm
cmp BYTE PTR [rax+r9*1-0x1], 0x7d
```

`0x7d` 对应 ASCII 字符：

```text
}
```

所以输入最后一个字符必须是右花括号。

------

### 4. 检查中间路径字符

然后程序取出中间部分，也就是：

```text
ISCC{这里的内容}
```

中间的内容必须全部属于：

```text
E N S W
```

这里的 `E`、`N`、`S`、`W` 很明显就是方向：

| 字符 | 含义        |
| ---- | ----------- |
| `E`  | East，向右  |
| `W`  | West，向左  |
| `S`  | South，向下 |
| `N`  | North，向上 |

所以这一步可以确定：

```text
flag = ISCC{一串由 E/N/S/W 组成的路径}
```

------

## 七、分析 validatePath：确定起点、终点和移动规则

继续看 `validatePath`。

这个函数会遍历路径中的每个字符。它内部有两个坐标变量，可以理解为：

```cpp
int row = 0;
int col = 0;
```

也就是说，起点是：

```text
(0, 0)
```

然后对路径中的每一步进行验证。

大致逻辑如下：

```cpp
bool validatePath(const std::string& path) {
    int row = 0;
    int col = 0;

    for (int i = 0; i < path.length(); i++) {
        char dir = path[i];

        if (!isValidMove(row, col, dir)) {
            return false;
        }

        if (dir == 'N') row--;
        if (dir == 'S') row++;
        if (dir == 'E') col++;
        if (dir == 'W') col--;

        if (row < 0 || row > 9 || col < 0 || col > 9) {
            return false;
        }

        if (row == 9 && col == 9) {
            return i == path.length() - 1;
        }
    }

    return false;
}
```

这段逻辑说明了几个关键信息：

第一，迷宫大小是 `10 × 10`。

因为坐标范围是：

```text
0 <= row <= 9
0 <= col <= 9
```

第二，起点是左上角：

```text
(0, 0)
```

第三，终点是右下角：

```text
(9, 9)
```

第四，路径必须最后一步刚好到达终点。

如果中途提前到达终点，但是后面还有多余字符，程序也会判错。

------

## 八、分析 decryptPixel：像素解密方式

接下来分析 `decryptPixel`。

反汇编非常简单：

```asm
mov eax, ecx
xor eax, 0x7f
ret
```

也就是说，像素解密公式是：

```cpp
decrypted_pixel = encrypted_pixel ^ 0x7f;
```

用 Python 写就是：

```python
pixel = encrypted_pixel ^ 0x7f
```

这说明程序里的迷宫像素值不是明文存储，而是先做了一层异或加密。

异或密钥是：

```text
0x7f
```

------

## 九、分析 getDecryptedPixel：迷宫数据在哪里

`getDecryptedPixel(row, col)` 的作用是根据坐标取出对应的加密像素，然后调用异或解密。

这个函数里面可以看到三段数据：

```cpp
if (row <= 2) {
    return ENCRYPTED_PART1[row * 10 + col] ^ 0x7f;
} else if (row <= 6) {
    return ENCRYPTED_PART2[(row - 3) * 10 + col] ^ 0x7f;
} else {
    return ENCRYPTED_PART3[(row - 7) * 10 + col] ^ 0x7f;
}
```

也就是说，整个 `10 × 10` 迷宫被拆成了三段：

| 数据段            | 对应行                  |
| ----------------- | ----------------------- |
| `ENCRYPTED_PART1` | 第 0 到第 2 行，共 3 行 |
| `ENCRYPTED_PART2` | 第 3 到第 6 行，共 4 行 |
| `ENCRYPTED_PART3` | 第 7 到第 9 行，共 3 行 |

总共：

```text
3 × 10 + 4 × 10 + 3 × 10 = 100
```

刚好是 `10 × 10` 的 100 个格子。

------

## 十、从二进制中提取迷宫数组

### 1. 找 .rdata 段信息

用：

```bash
objdump -h PixelMaze.exe
```

可以看到 `.rdata` 段类似：

```text
Idx Name    Size      VMA               File off
2   .rdata  00010220  00000001400bd000  000bb800
```

这说明 `.rdata` 段的虚拟地址基址是：

```text
0x1400bd000
```

文件偏移基址是：

```text
0xbb800
```

如果程序里某个全局数组的虚拟地址是 `0x1400bd180`，那么它在文件中的偏移就是：

```text
0xbb800 + (0x1400bd180 - 0x1400bd000)
= 0xbb800 + 0x180
= 0xbb980
```

------

### 2. 提取 PART1 和 PART2

在 `getDecryptedPixel` 里可以看到：

```asm
lea rax,[rip+...]  # 1400bd180 <ENCRYPTED_PART1>
lea rax,[rip+...]  # 1400bd0e0 <ENCRYPTED_PART2>
```

所以：

```text
ENCRYPTED_PART1 地址：0x1400bd180
ENCRYPTED_PART2 地址：0x1400bd0e0
```

换算成文件偏移：

```text
PART1 文件偏移 = 0xbb800 + 0x180
PART2 文件偏移 = 0xbb800 + 0x0e0
```

每个元素是 4 字节整数，也就是 DWORD。

`PART1` 有 30 个整数。

`PART2` 有 40 个整数。

------

### 3. PART3 为什么麻烦一点

`PART3` 没有直接存在 `.rdata` 里，而是在 `getDecryptedPixel` 函数开头通过一堆 `movabs` 指令临时写到栈上。

例如：

```asm
movabs rax, 0xbe000000be
mov QWORD PTR [rsp], rax
```

这句的意思是往栈上写入 8 字节。

由于 x86 是小端序，内存里实际是：

```text
be 00 00 00 be 00 00 00
```

如果按两个 32 位整数解释，就是：

```text
0xbe, 0xbe
```

所以 `PART3` 可以从这些 `movabs` 指令里手动还原出来。

新手做题时可以用两种方式：

第一种，用 Ghidra 反编译后直接看局部数组，比较直观。

第二种，看汇编里的 `movabs` 指令，把每 8 字节拆成两个 32 位整数。

------

## 十一、分析 isValidMove：理解“像素不是 0 和 1”

这是本题最核心的地方。

`isValidMove(row, col, dir)` 会先取得当前位置的解密像素：

```cpp
pixel = getDecryptedPixel(row, col);
```

然后根据方向字符检查 pixel 的某一位。

反汇编可以看出：

```cpp
if (dir == 'E') return pixel & 1;
if (dir == 'W') return (pixel >> 1) & 1;
if (dir == 'S') return (pixel >> 2) & 1;
if (dir == 'N') return (pixel >> 3) & 1;
```

也就是说，每个像素不是简单的 `0` 或 `1`。

每个像素是一个方向位掩码。

低四位分别表示当前位置能否向某个方向走：

| bit 位 | 方向 | 含义       |
| ------ | ---- | ---------- |
| bit0   | `E`  | 能否向右走 |
| bit1   | `W`  | 能否向左走 |
| bit2   | `S`  | 能否向下走 |
| bit3   | `N`  | 能否向上走 |

举例：

如果某个格子的解密像素是：

```text
0b0101
```

也就是十进制的 `5`。

它的 bit0 是 1，bit2 是 1，所以说明：

```text
这个格子可以向 E 走，也可以向 S 走。
```

这就是题目说“是像素不是 0 和 1”的真正含义。

它不是普通黑白迷宫，而是每个像素用 bit 位存储可走方向。

------

## 十二、把迷宫变成图搜索问题

现在我们已经知道：

起点是：

```text
(0, 0)
```

终点是：

```text
(9, 9)
```

迷宫大小是：

```text
10 × 10
```

每个格子的像素值经过：

```python
pixel = encrypted_pixel ^ 0x7f
```

得到。

然后通过低四位判断四个方向能不能走。

所以这题已经从逆向问题变成了一个图搜索问题。

可以用 BFS 从 `(0,0)` 搜到 `(9,9)`。

BFS 的好处是逻辑简单，而且如果存在多条路径，它会先找到较短路径。

------

## 十三、求解脚本

下面是一个教学版求解脚本。真实输出路径在 WP 中隐藏，运行脚本即可复现。

```python
import struct
from collections import deque

filename = "PixelMaze.exe"

with open(filename, "rb") as f:
    data = f.read()

# .rdata 的文件偏移
rdata_file_offset = 0xbb800

# ENCRYPTED_PART2 位于 .rdata + 0xe0，共 40 个 DWORD
part2_offset = rdata_file_offset + 0xe0
part2 = list(struct.unpack("<40I", data[part2_offset:part2_offset + 40 * 4]))

# ENCRYPTED_PART1 位于 .rdata + 0x180，共 30 个 DWORD
part1_offset = rdata_file_offset + 0x180
part1 = list(struct.unpack("<30I", data[part1_offset:part1_offset + 30 * 4]))

# ENCRYPTED_PART3 是 getDecryptedPixel 中在栈上构造的 30 个 DWORD
part3 = [
    0xbe, 0xbe, 0x37, 0x2e, 0x7e, 0xb7, 0x8b, 0x1d, 0x66, 0x9d,
    0x6e, 0x4a, 0x3c, 0x5a, 0x7d, 0xa9, 0x3e, 0xee, 0x2e, 0xeb,
    0x76, 0xee, 0x4d, 0x0c, 0x67, 0x49, 0xad, 0x7c, 0x3d, 0x00
]

# 拼成完整的 10 × 10 加密迷宫
encrypted_maze = part1 + part2 + part3

assert len(encrypted_maze) == 100

# 解密
maze = [x ^ 0x7f for x in encrypted_maze]

# 每个方向对应的 bit 位
direction_bit = {
    "E": 0,
    "W": 1,
    "S": 2,
    "N": 3,
}

# 每个方向对应的坐标变化
direction_delta = {
    "E": (0, 1),
    "W": (0, -1),
    "S": (1, 0),
    "N": (-1, 0),
}

def can_move(row, col, direction):
    pixel = maze[row * 10 + col]
    bit = direction_bit[direction]
    return ((pixel >> bit) & 1) == 1

def bfs():
    start = (0, 0)
    target = (9, 9)

    q = deque()
    q.append((0, 0, ""))

    visited = set()
    visited.add(start)

    while q:
        row, col, path = q.popleft()

        if (row, col) == target:
            return path

        for direction in "NESW":
            if not can_move(row, col, direction):
                continue

            dr, dc = direction_delta[direction]
            nr = row + dr
            nc = col + dc

            if not (0 <= nr <= 9 and 0 <= nc <= 9):
                continue

            if (nr, nc) in visited:
                continue

            visited.add((nr, nc))
            q.append((nr, nc, path + direction))

    return None

path = bfs()

print("path =", path)
print("flag =", "ISCC{" + path + "}")
```

这里的搜索顺序写成：

```python
for direction in "NESW":
```

是因为只要能找到合法路径即可。不同搜索顺序可能在存在多条路径时得到不同路径，但本题程序只要求路径合法并最终到达终点。

------

## 十四、验证输入

拿脚本输出的路径拼成：

```text
ISCC{<hidden_path>}
```

然后运行程序输入即可得到：

```text
Correct!
```

真实路径和真实 flag 这里隐藏，不在 WP 中直接展示。

------

## 十五、完整解题思路总结

这题的关键思路可以按下面的流程理解：

第一步，识别文件是 Windows 64 位 PE 程序。

第二步，用 `strings` 发现程序有 `ISCC{`、`Correct!`、`Incorrect!`，确定是输入校验型逆向题。

第三步，查看符号表，发现程序没有完全去符号，直接定位到 `extractPath`、`validatePath`、`isValidMove`、`getDecryptedPixel`、`decryptPixel` 这些关键函数。

第四步，分析 `extractPath`，确定 flag 格式是：

```text
ISCC{E/N/S/W 路径}
```

第五步，分析 `validatePath`，确定迷宫大小是 `10 × 10`，起点是 `(0,0)`，终点是 `(9,9)`，并且必须最后一步刚好到终点。

第六步，分析 `decryptPixel`，发现像素解密方式是：

```text
encrypted_pixel ^ 0x7f
```

第七步，分析 `getDecryptedPixel`，发现 100 个迷宫格子被拆成三段存储，分别对应前 3 行、中间 4 行、最后 3 行。

第八步，分析 `isValidMove`，发现每个像素不是普通 0/1，而是方向 bitmask。低四位分别表示能否向 `E/W/S/N` 四个方向移动。

第九步，用 Python 把 100 个加密像素取出来，异或 `0x7f` 解密，然后对 `10 × 10` 网格做 BFS 搜索。

第十步，把搜索得到的路径放进 `ISCC{}` 中，输入程序验证，得到 `Correct!`。

本题真正的考点不是复杂算法，而是能否从逆向代码里看出“像素”的语义：它不是二值像素，而是用 bit 位编码方向的迷宫节点。