# QuorumGlyph

## 题目信息

- 题目：`QuorumGlyph`
- 分类：`reverse`
- 附件：`QuorumGlyph_release.zip`
- 题面提示：`One witness lies. Two are incomplete. Three agree.`

最终复现出的 flag 是：

```text
ISCC{QRM_FE6V6_3_w1tness_no_single_path!!}
```

## 本地确认

解压附件后可以看到主体就是一个 `Linux x86_64 ELF`：

- 样本路径：`D:\CTF\powershell\tmp_quorumglyph\QuorumGlyph`
- 题面说明里也明确提到输入 flag 后只会输出 `Yes??? / No???`

直接看字符串可以先拿到几条非常关键的信息：

- 成功/失败输出：`Yes???`、`No???`
- 固定前缀：`ISCC`
- 一套 32 字符表：`ABCDEFGHJKLMNPQRSTUVWXYZ23456789`

再结合 `main` 开头的格式检查，flag 框架马上能定出来：

- 长度必须是 `42`
- `flag[0:9] == "ISCC{QRM_"`
- `flag[14] == '_'`
- `flag[41] == '}'`
- 所有字符都必须在可打印 ASCII 范围内

所以整体形状就是：

```text
ISCC{QRM_?????_3_w1tness_no_single_path!!}
```

## Stage A：witness 只做一致性校验

`0x4012cc` 开始，程序会先复制输入，然后故意把 `flag[9:14]` 这 5 个字符清零，再按 8 字节一组打成 6 个 `u64`。

后面那大段循环本质上是 144 轮 parity 校验：

- witness 数据在 `.rodata:0x402040`
- 6 路 mask 表在 `.rodata:0x4020e0`
- 每轮把 6 个 `u64` 与对应 mask 按位与，再做 popcount/parity
- 最终拿结果和 `(witness[i] ^ rolling_seed) & 1` 对比

这一段的重要结论不是“能直接解出 flag”，而是：

- 它验证的是除 `flag[9:14]` 之外的主体内容
- 中间 5 位被刻意从这条路径里摘掉了

所以 witness 这条线本身是不完整的。

## Stage B：64 字节状态约束恢复主体明文

构造器 `0x401080` 会在运行时往 `.bss` 里写几组关键数据，包括：

- `0x405068 = 0x4a9b46e51d6eeeb3`
- `0x405080 = 0xe04cf5339f776142`
- `0x4050a0 = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"`
- `0x4050e0` 一段 64 字节目标状态

其中 `0x4050e0` 不是文件里直接静态存放的明文常量，而是构造器把 `.rodata:0x403bdc` 那 64 字节和一个 `splitmix64` 风格的混合器拼出来的运行时目标状态。

接着 `main` 会重新复制输入，再次把 `flag[9:14]` 清零，然后构造 64 字节工作状态：

- 前 42 字节：清零中段后的输入
- 中间 8 字节：对前 42 字节做一轮 `mix64` 累积得到的摘要
- 最后 14 字节：继续基于前面的滚动状态派生

这 64 字节会被视为 16 个小端 `u32`，然后做 37 轮变换。每轮包括：

1. 按轮常量异或后循环左移
2. 一次从左到右的链式异或
3. 一次从右到左的链式异或
4. 固定规则的 swap

我这次没有把 37 轮逆变换完全手抄出来，而是先精确复原了这 64 字节状态的构造，再用样本本身验证现成 WP 的中间结论。恢复出来的主体明文是：

```text
ISCC{QRM_....._3_w1tness_no_single_path!!}
```

也就是说：

- 中间 5 位仍未知
- 其余字符已经全部锁定

这一步已经足够说明第二条路径给出了“主体明文”，但依然不完整。

## Stage C：5 位 token 单独求解

`0x401ae3` 开始单独处理 `flag[9:14]` 这 5 个字符。

逻辑很干净：

1. 每个字符都必须来自字母表 `ABCDEFGHJKLMNPQRSTUVWXYZ23456789`
2. 把 5 个字符按 5-bit index 打包成一个整数 `acc`
3. 要求 `acc <= 0xffffff`
4. 再做一次线性变换：

```text
seed = (0x989b19bd * (acc - 0x00b3ef33)) & 0xffffff
```

5. 把 `seed` 丢进 `0x401ca0` 这个重型 64 位混合函数
6. 返回值必须等于构造器写入的目标值 `0xe04cf5339f776142`

把样本里的字母表规则代进去，可以验证：

```text
token      = FE6V6
packed_acc = 0x52727c
seed       = 0x0c0de5
hash(seed) = 0xe04cf5339f776142
```

其中最后一步我这次不是只看反汇编，而是直接用 `unicorn` 在本地模拟执行样本里的 `0x401ca0`，因此这一段是被样本本身验证过的。

## 拼接 flag

Stage B 给出：

```text
ISCC{QRM_?????_3_w1tness_no_single_path!!}
```

Stage C 给出：

```text
????? = FE6V6
```

所以最终 flag 就是：

```text
ISCC{QRM_FE6V6_3_w1tness_no_single_path!!}
```

## 本地复现脚本

我把这次实际验证用的脚本放到了：

- [solve_quorumglyph.py](D:\CTF\powershell\iscc2026wp\solve_quorumglyph.py)

直接运行：

```powershell
python D:\CTF\powershell\iscc2026wp\solve_quorumglyph.py
```

脚本会输出：

- `stage2` 主体明文
- `token = FE6V6`
- `packed_acc = 0x52727c`
- `stage3_seed = 0x0c0de5`
- `heavy_hash = 0xe04cf5339f776142`
- 最终 flag

## 题目理解

这题的提示 `One witness lies. Two are incomplete. Three agree.` 基本就是在说：

- witness/parity 这条线只做一致性约束
- 64 字节状态变换给出主体明文，但故意缺中间 5 位
- 5 位 token 又被单独拿出来做 base32-like 打包和重型哈希校验

单看任何一条都不完整，但三条线放在一起就能把 flag 完整锁死。这也正好呼应了明文里的：

```text
no_single_path
```
