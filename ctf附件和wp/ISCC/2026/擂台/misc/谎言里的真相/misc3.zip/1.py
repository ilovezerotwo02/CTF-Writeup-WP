import os
import re
import zipfile
import hashlib
import subprocess
from base64 import b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

# 第一阶段得到的四段
part1 = "qW2O0z"
part2 = "5bnImG"
part3 = "4yFuUc"
part4 = "4Y0nV9"

mid = part1 + part2 + part3 + part4
zip_pwd = hashlib.md5(mid.encode()).hexdigest()

print("[+] mid:", mid)
print("[+] 窥得天机.zip password:", zip_pwd)

# 解压 窥得天机.zip
subprocess.run([
    "7z", "x", "窥得天机.zip", f"-p{zip_pwd}", "-y", "-oout_zip"
], check=False)

# 读取 zip comment
with zipfile.ZipFile("窥得天机.zip", "r") as z:
    comment = z.comment.decode()

print("[+] zip comment:", comment)

base64_table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

# 读取 64 个 txt
# 注意：具体文件名可能需要根据题目附件调整排序方式。
txt_dir = "out_zip"
txt_files = []
for root, _, files in os.walk(txt_dir):
    for name in files:
        if name.lower().endswith(".txt"):
            txt_files.append(os.path.join(root, name))

# 尽量按文件名中的数字排序；如果没有数字，就按文件名字典序。
def sort_key(path):
    name = os.path.basename(path)
    nums = re.findall(r"\d+", name)
    return int(nums[0]) if nums else name

txt_files = sorted(txt_files, key=sort_key)

if len(txt_files) != 64:
    print(f"[!] txt 文件数量不是 64，而是 {len(txt_files)}，请检查解压目录/排序规则")

seven_pwd = ""
for i, ch in enumerate(comment):
    idx = base64_table.index(ch)
    with open(txt_files[i], "r", encoding="utf-8", errors="ignore") as f:
        data = f.read()
    seven_pwd += data[idx]

print("[+] 终局.7z password:", seven_pwd)

# 解压 终局.7z
subprocess.run([
    "7z", "x", "终局.7z", f"-p{seven_pwd}", "-y", "-oout_final"
], check=False)

# 读取 终局.txt
final_txt = None
for root, _, files in os.walk("out_final"):
    for name in files:
        if name == "终局.txt" or name.lower().endswith(".txt"):
            final_txt = os.path.join(root, name)
            break

if final_txt is None:
    raise FileNotFoundError("未找到 终局.txt")

with open(final_txt, "r", encoding="utf-8", errors="ignore") as f:
    ciphertext_b64 = f.read().strip()

# AES-CBC 解密
key = mid.encode()[:16]
iv = seven_pwd.encode()[:16]
ct = b64decode(ciphertext_b64)
pt = unpad(AES.new(key, AES.MODE_CBC, iv).decrypt(ct), 16)

print("[+] flag:", pt.decode())