---
title: "消失的喵星密使"
ctf: "ISCC"
date: 2026-05-16
category: reverse
difficulty: hard
points: 250
flag_format: "ISCC{...}"
author: "OpenAI"
---

# 消失的喵星密使

## Summary

这题表面上是一个带提示文案的 Android APK，真正的验证逻辑在 `libmobile03.so`。Java 层只负责两件事：校验一个 6 步 Emoji 网格序列的 MD5，以及把 `hint.png`、步伐串和用户输入一起丢给 native。

native 侧的核心是两部分：`hint.png` 的像素最低位里藏着一个 256-byte S-box，步伐串会经 `_f1` 转成 32-byte key，然后 `libmobile03.so` 用这套自定义 S-box 跑一遍标准 AES-256 风格的 key schedule 和分组加密。把常量密文逆回去后，就能恢复 flag 内文。

最终 flag：

```text
ISCC{m3ow_r0u73_gr1d7FX}
```

## 题目结构 / 程序入口 / 攻击面总览

先对 APK 做常规解包：

```bash
file iscc/附件/app-release.apk
unzip -l iscc/附件/app-release.apk | sed -n '1,40p'
jadx -ds temp/meowl_jadx iscc/附件/app-release.apk
apktool d -f -o temp/meowl_apktool iscc/附件/app-release.apk
```

关键文件和入口如下：

- `AndroidManifest.xml`
  - 包名：`com.example.mobile03`
  - 启动页：`com.example.mobile03.MainActivity`
- Java 层核心类：
  - `temp/meowl_jadx/com/example/mobile03/MainActivity.java`
  - `temp/meowl_jadx/com/example/mobile03/_A.java`
  - `temp/meowl_jadx/com/example/mobile03/_B.java`
  - `temp/meowl_jadx/com/example/mobile03/_C.java`
  - `temp/meowl_jadx/com/example/mobile03/_P.java`
- 关键资产：
  - `assets/hint.png`
  - `assets/sys/OBSERVER_PROTOCOL`
- Native：
  - `lib/*/libmobile03.so`

Java 层逻辑非常短，主流程在 `MainActivity`：

1. 页面加载时显示提示文案；
2. 用户点击 6x6 Emoji 网格，`_B._q()` 会把每次点击的坐标编码成 2 个字母并顺序拼接；
3. `_C._c()` 对这个步伐串做 MD5，必须等于固定值；
4. 输入框内容必须是 `ISCC{...}` 格式；
5. `_A.check()` 把：
   - flag 内文
   - 步伐串
   - `hint.png`
   
   一起送进 native 函数 `_v(...)`。

也就是说，真正要解的对象其实有两个：

- **步伐串 `q`**
- **native 的图像 + 自定义加密验证**

## 详细解题过程

### Step 1: 先把 Java 层 gate 摸清楚

先看 `MainActivity.java`：

```java
String str_q = this._b._q();
if (!_C._c(str_q)) {
    Toast.makeText(this, "步伐的韵律不对，密使已消失。", 0).show();
    this._b._r(gridLayout);
    return;
}
String str_g = this._b._g((EditText) findViewById(R.id.et_flag));
if (str_g == null) {
    Toast.makeText(this, "格式错误！", 0).show();
} else if (this._a.check(this, str_g, str_q)) {
    Toast.makeText(this, "喵！解密成功！", 1).show();
}
```

这里先说明三个结论：

1. **步伐串先过 MD5 gate**
2. **flag 外层格式只是 `ISCC{...}`**
3. **真正验证在 `_A.check()` 的 native `_v(...)`**

`_B._g()` 里有一个很短的异或：

```java
byte[] bArr = {11, 17, 1, 1, 57};
for (int i = 0; i < 5; i++) {
    sb.append((char) (bArr[i] ^ 66));
}
```

异或出来就是 `ISCC{`，所以外层 flag 格式并不是难点。

`_C._c()` 则直接把步伐串的 MD5 固定死：

```java
return sb.toString().equals("72184e58e765a1a579b201c3e15bc0ce");
```

所以第一阶段目标变成：

> 找到正确的 12 字符步伐串 `q`

### Step 2: 从协议文件和提示文案还原步伐串

协议文件 `assets/sys/OBSERVER_PROTOCOL` 不是明文，而是一整段十六进制 ASCII。解码后能看到：

```text
[GLOBAL_SEED]: 0xDEADC0DE
[RUNTIME_STR]: @LOG_TAG_DESCRIPTOR
[CONSTRAINT]: S = { x | 1 ≤ x ≤ 6, x ∈ ℤ }

[[ PHASE_ALPHA: THE_ORIGIN_BIAS ]]
...
P1.r = r_A; P1.c = c_A / λ

[[ PHASE_BETA: THE_FRACTAL_SHIFT ]]
...
r_B = τ + (φ >> 31) + 1
c_B = ((r_B << τ) ^ (T & 0x00)) & 0x07

[[ PHASE_GAMMA: THE_ASYMPTOTIC_GHOST ]]
...
r_C = lim(x→∞) [ (6x² + 5x) / (x² + 1) ]
c_C = ⌈ cos(π) ⌉ + ghost + 2

[[ GLOBAL_PARITY_CHECK ]]
∫ Row_Total dt  ≡ 21  (Mod 100)
∫ Col_Total dt  ≡ 20  (Mod 100)
隐藏条件：当且仅当 P2.c > P1.c 且 P6.c < P2.c 时，序列激活
```

这段东西看起来很唬人，但其实很机械：

#### 2.1 前两个点可以直接算

`PHASE_ALPHA`：

- `Ψ(r, c) = (r - c)^2 + (r + c - 2)^2`
- 求驻点得到 `r = 1, c = 1`

所以第一个点是 **(1,1)**。

在网格里，行列标签由 `_B._k` 给出：

```java
private final String[] _k = {"D", "F", "X", "G", "A", "V"};
```

所以 `(1,1)` 对应 `DD`。这也正好符合提示里的“印记的起点”——左上角就是 `🐾`。

`PHASE_BETA`：

- `_P` 的 log tag 是 `"0x1918"`
- `τ = (0x1918 >> 12) & 0x0F = 1`
- `r_B = 1 + 0 + 1 = 2`
- `c_B = ((2 << 1) ^ 0) & 0x07 = 4`

第二个点是 **(2,4)**，对应 `FG`。在网格上正好是 `🦋`，也就是文案里的“舞动的斑斓”。

#### 2.2 文案把剩下的语义顺序钉死了

UI 上的提示文案是：

```text
密使巡逻日志：雪球在印记的起点打转，它转而扑向那抹舞动的斑斓，在清甜的气息中小憩片刻；它凝视苍穹中央的光源，却为未竟之事而黯然，终没入无光的轮廓里。
```

如果结合网格内容看，这句话其实就是在按顺序点 Emoji。这里第三步一开始最容易误判成 `🥛` 或 `🛌`，但把它们代回 `Row_Total = 21` / `Col_Total = 20` 后都会失败；只有 `🌿` 同时满足语义和校验和。

因此顺序唯一稳定地落成：

- 印记的起点 → `🐾` → `(1,1)` → `DD`
- 舞动的斑斓 → `🦋` → `(2,4)` → `FG`
- 清甜的气息 → `🌿`（猫薄荷/香草意象最贴）→ `(3,6)` → `XV`
- 苍穹中央的光源 → `☀️` → `(4,2)` → `GF`
- 黯然 → `😿` → `(5,6)` → `AV`
- 没入无光的轮廓 → `🐈‍⬛` → `(6,1)` → `VD`

这组点还有一个非常漂亮的性质：

- 行和：`1 + 2 + 3 + 4 + 5 + 6 = 21`
- 列和：`1 + 4 + 6 + 2 + 6 + 1 = 20`

刚好满足协议文件里的 parity check。

于是步伐串可以直接拼出来：

```text
q = DDFGXVGFAVVD
```

再做一次 MD5 验证：

```bash
python3 - <<'PY'
import hashlib
q='DDFGXVGFAVVD'
print(hashlib.md5(q.encode()).hexdigest())
PY
```

输出：

```text
72184e58e765a1a579b201c3e15bc0ce
```

说明 Java 层第一道门已经完全打通。

### Step 3: native 真正做了什么

动态符号里最关键的是这些：

```text
_f_val(_JNIEnv*, _jobject*, _jstring*, _jstring*, _jobject*)
_f_ext(_JNIEnv*, _jobject*, unsigned char*)
_f1(char const*, unsigned char*)
_f_exp(unsigned char const*)
_f_enc(unsigned char*)
_f_d64(char const*, unsigned char*)
_f_monitor(void*)
```

#### 3.1 `_f_monitor` 是反调试线程

`JNI_OnLoad` 里会 `pthread_create` 起一个线程跑 `_f_monitor`，它不断读 `/proc/self/status`，查 `TracerPid:`，非 0 就直接 `_exit`。

这说明：

- 附调试器动态跑会很难受；
- 但**静态逆向完全足够**，不需要硬碰反调试。

#### 3.2 `_f_ext`：从 `hint.png` 像素最低位抽 256-byte S-box

`_f_ext` 的逻辑很关键：

1. 用 `AndroidBitmap_getInfo/lockPixels` 读位图；
2. 按行扫描像素；
3. 取每个像素第 3 个字节（偏移 `+2`）的最低位；
4. 连续取前 `0x830` 个 bit，打包成 `0x106 = 262` 字节；
5. 前 4 字节必须是 `MEOW`；
6. 后面 256 字节复制出来，作为一个查表表。

也就是说，`hint.png` 不是简单藏 flag，而是在像素 LSB 里藏了：

```text
MEOW || SBOX[256] || 2 extra bytes
```

本地还原出来的开头就是：

```text
4d454f57b5d3147d...
```

也就是：

```text
MEOW b5 d3 14 7d ...
```

#### 3.3 `_f1`：把步伐串变成 32-byte key

`_f1` 不是直接拿 `q` 做 key，而是先做一次列重排。

对 `q = DDFGXVGFAVVD`，它会按：

- 位置 `1,5,9`
- 位置 `0,4,8`
- 位置 `2,6,10`
- 位置 `3,7,11`

这样的顺序重排，得到：

```text
DVVDXAFGVGFD
```

然后把每两个字符当成一组，映射进一个 6x6 方阵：

```text
mh7q1a
u6sl5p
cv20t9
zedwxf
njrgi8
bk4y3o
```

这个方阵正好就是 `_f1` 里用到的 36 字符串：

```text
mh7q1au6sl5pcv20t9zedwxfnjrgi8bk4y3o
```

再之后，native 用这个字符的 ASCII 值去索引刚从图片里抽出来的 S-box，并叠一个递增异或：

```text
counter = 0x00, 0x13, 0x26, 0x39, ...
```

最终得到 32-byte key：

```text
44a17d9e2cb83637c30cde36a04551ba50a412db2728c2528c69b5a674c07eff
```

### Step 4: `_f_exp + _f_enc` 本质上是一套“自定义 S-box 的 AES-256”

这一段是题目的核心技巧。

#### 4.1 `_f_exp` 是 key schedule

`_f_exp` 的行为和 AES-256 key expansion 一致：

- 初始 key 32 字节；
- 使用标准 `Rcon = 01 02 04 08 10 20 40 80 1B 36`；
- `SubWord` 不再走标准 AES S-box，而是走 `hint.png` 里提出来的自定义 S-box。

#### 4.2 `_f_enc` 是分组加密

`_f_enc` 对每个 16-byte block 做：

1. 初始 AddRoundKey
2. 13 轮：
   - SubBytes（自定义 S-box）
   - ShiftRows
   - MixColumns
   - AddRoundKey
3. 最后一轮不做 MixColumns

本质就是：

> **自定义 S-box 的 AES-256 ECB**

#### 4.3 `_f_val` 的比较目标

`_f_val` 做了这几件事：

1. `_f_ext` 从图片里抽 S-box
2. `_f1` + `_f_exp` 从 `q` 生成轮密钥
3. 把 flag 内文拆成两个 16-byte block，不足补 0
4. 对两个 block 分别 `_f_enc`
5. Base64 解码常量：

```text
s1iKn8YgOi8DO4p7bWHpTldoIwNL38IWGlcBbFngHRo=
```

6. 再和 `0x66` 重复 32 次做异或
7. 用结果和两块密文逐块比较

因此正确姿势不是爆破，而是：

> **直接把目标常量当成密文，用同一套 key 和 S-box 反解回明文**

### Step 5: 直接离线还原 flag

下面这份脚本完整复现了 native 的三步：

1. 从 `hint.png` 提取 S-box
2. 从 `q` 还原 32-byte key
3. 用自定义 AES-256 解密目标密文

```python
from io import BytesIO
from base64 import b64decode
from zipfile import ZipFile
from PIL import Image
import hashlib


APK_PATH = "iscc/附件/app-release.apk"
Q = "DDFGXVGFAVVD"
TARGET_B64 = "s1iKn8YgOi8DO4p7bWHpTldoIwNL38IWGlcBbFngHRo="
SQUARE = "mh7q1au6sl5pcv20t9zedwxfnjrgi8bk4y3o"
ROW_MAP = {"A": 0, "D": 6, "F": 12, "G": 18, "V": 24, "X": 30}
COL_MAP = {"A": 0, "D": 1, "F": 2, "G": 3, "V": 4, "X": 5}
RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]


def extract_sbox_from_apk(apk_path: str) -> bytes:
    with ZipFile(apk_path, "r") as zf:
        png_data = zf.read("assets/hint.png")

    img = Image.open(BytesIO(png_data)).convert("RGBA")
    w, h = img.size
    pixels = list(img.getdata())

    bits = []
    for y in range(h):
        for x in range(w):
            bits.append(pixels[y * w + x][2] & 1)
            if len(bits) >= 0x830:
                break
        if len(bits) >= 0x830:
            break

    raw = bytearray(0x830 // 8)
    for i, b in enumerate(bits):
        if b:
            raw[i >> 3] |= 1 << (7 - (i & 7))

    assert raw[:4] == b"MEOW"
    return bytes(raw[4:4 + 256])


def derive_key(q: str, sbox: bytes) -> bytes:
    perm = q[1::4] + q[0::4] + q[2::4] + q[3::4]
    out = []
    for i in range(32):
        a = perm[(2 * i) % len(perm)]
        b = perm[(2 * i + 1) % len(perm)]
        ch = SQUARE[ROW_MAP[a] + COL_MAP[b]]
        out.append(sbox[ord(ch)] ^ ((0x13 * i) & 0xFF))
    return bytes(out)


def sub_word(word: bytes, sbox: bytes) -> bytes:
    return bytes(sbox[b] for b in word)


def rot_word(word: bytes) -> bytes:
    return word[1:] + word[:1]


def expand_key(key: bytes, sbox: bytes) -> list[bytes]:
    words = [key[i:i + 4] for i in range(0, 32, 4)]
    for i in range(8, 60):
        temp = words[i - 1]
        if i % 8 == 0:
            temp = bytes(
                a ^ b
                for a, b in zip(
                    sub_word(rot_word(temp), sbox),
                    bytes([RCON[i // 8 - 1], 0, 0, 0]),
                )
            )
        elif i % 8 == 4:
            temp = sub_word(temp, sbox)
        words.append(bytes(a ^ b for a, b in zip(words[i - 8], temp)))
    return [b"".join(words[4 * r:4 * r + 4]) for r in range(15)]


def add_round_key(state: list[int], key: bytes) -> list[int]:
    return [a ^ b for a, b in zip(state, key)]


def gmul(a: int, b: int) -> int:
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xFF
        if hi:
            a ^= 0x1B
        b >>= 1
    return p


def inv_shift_rows(state: list[int]) -> list[int]:
    rows = [state[i::4] for i in range(4)]
    out = [[0] * 4 for _ in range(4)]
    for r in range(4):
        row = list(rows[r])
        row = row[-r:] + row[:-r] if r else row
        out[r] = row
    return [out[r][c] for c in range(4) for r in range(4)]


def inv_mix_single_col(col: list[int]) -> list[int]:
    a0, a1, a2, a3 = col
    return [
        gmul(a0, 14) ^ gmul(a1, 11) ^ gmul(a2, 13) ^ gmul(a3, 9),
        gmul(a0, 9) ^ gmul(a1, 14) ^ gmul(a2, 11) ^ gmul(a3, 13),
        gmul(a0, 13) ^ gmul(a1, 9) ^ gmul(a2, 14) ^ gmul(a3, 11),
        gmul(a0, 11) ^ gmul(a1, 13) ^ gmul(a2, 9) ^ gmul(a3, 14),
    ]


def inv_mix_columns(state: list[int]) -> list[int]:
    out = []
    for c in range(4):
        out.extend(inv_mix_single_col(state[4 * c:4 * c + 4]))
    return out


def decrypt_block(block: bytes, round_keys: list[bytes], inv_sbox: list[int]) -> bytes:
    state = list(add_round_key(list(block), round_keys[14]))
    for rnd in range(13, 0, -1):
        state = inv_shift_rows(state)
        state = [inv_sbox[b] for b in state]
        state = add_round_key(state, round_keys[rnd])
        state = inv_mix_columns(state)
    state = inv_shift_rows(state)
    state = [inv_sbox[b] for b in state]
    state = add_round_key(state, round_keys[0])
    return bytes(state)


def main():
    assert hashlib.md5(Q.encode()).hexdigest() == "72184e58e765a1a579b201c3e15bc0ce"

    sbox = extract_sbox_from_apk(APK_PATH)
    inv_sbox = [0] * 256
    for i, v in enumerate(sbox):
        inv_sbox[v] = i

    key = derive_key(Q, sbox)
    round_keys = expand_key(key, sbox)

    target = bytes(b ^ 0x66 for b in b64decode(TARGET_B64))
    pt1 = decrypt_block(target[:16], round_keys, inv_sbox)
    pt2 = decrypt_block(target[16:], round_keys, inv_sbox)

    inner = (pt1 + pt2).rstrip(b"\x00").decode()
    flag = f"ISCC{{{inner}}}"

    print(f"[+] q       = {Q}")
    print(f"[+] key     = {key.hex()}")
    print(f"[+] block1  = {pt1!r}")
    print(f"[+] block2  = {pt2!r}")
    print("=" * 50)
    print(f"[!!!] FLAG: {flag}")
    print("=" * 50)


if __name__ == "__main__":
    main()
```

### Step 6: 验证

本地验证时，最关键的中间量有三个：

1. `q` 的 MD5
2. `hint.png` 解出的头 4 字节必须是 `MEOW`
3. 解密出的两块明文必须拼回可读字符串

验证输出如下：

```text
q= DDFGXVGFAVVD
perm= DVVDXAFGVGFD
sbox_head= 4d454f57b5d3147d
key= 44a17d9e2cb83637c30cde36a04551ba50a412db2728c2528c69b5a674c07eff
pt1 = b'm3ow_r0u73_gr1d7'
pt2 = b'FX\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00'
```

因此 flag 内文就是：

```text
m3ow_r0u73_gr1d7FX
```

## 关键结论 / 题目套路总结

这题真正值得记住的点有三个：

1. **APK 题不要只盯 Java 层。**  
   这里 Java 基本只是提示器和 JNI 跳板，真正的数据流在 `.so`。

2. **看起来像“图片藏 flag”，实际可能是“图片藏密码学部件”。**  
   `hint.png` 里藏的不是明文，而是自定义 S-box。这比普通 LSB 难一点，但仍然是结构化数据。

3. **协议文案和 UI 文案是两套互补提示。**  
   `OBSERVER_PROTOCOL` 给了硬约束（和校验和），主界面的猫咪文案给了语义锚点。两者拼起来，步伐串才被完全钉死。

## Flag

```text
ISCC{m3ow_r0u73_gr1d7FX}
```
