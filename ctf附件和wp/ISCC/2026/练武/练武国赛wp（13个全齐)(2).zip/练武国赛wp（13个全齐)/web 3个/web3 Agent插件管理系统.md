# Agent插件管理系统 WP

## 题目分析

题目是一个插件管理系统，支持上传插件包，并会对插件做校验和加载。

前端和下载到的 `agent-core.jar` 中能看到几个关键点：

- 插件包需要包含 `manifest.json` 和 `metadata.ser`
- `metadata.ser` 会参与 HMAC 校验
- HMAC 密钥在 `application.yml` 中，值为 `k3y_5A62_X86`
- 服务端会在上传后反序列化 `metadata.ser`

继续分析反序列化相关类，可以发现一条可利用链：

- `ResourceRefresher`
- `DataStream`
- `FileExporter`

其中 `FileExporter.export(path)` 会读取指定文件内容，并调用 `LogService.log(...)` 把内容写进对应 `team_id` 的日志里。

这意味着可以通过构造恶意序列化对象，实现任意文件读取。

## 利用过程

1. 构造一个恶意 `metadata.ser`
   - 序列化根对象为 `ResourceRefresher`
   - 令其内部调用 `DataStream`
   - 再由 `FileExporter` 把目标文件内容写入日志

2. 用题目里的 HMAC 密钥对恶意 `metadata.ser` 做签名
   - 密钥：`k3y_5A62_X86`

3. 生成符合格式的插件包：
   - `manifest.json`
   - `metadata.ser`

4. 上传插件到：
   - `/api/upload`

5. 到日志接口读取结果：
   - `/api/logs?team_id=你的team_id`

## 关键结果

一开始读取 `/etc/flag`，得到的是假 flag：

`ISCC{f4k3_fl4g_d3c0y_d0nt_subm1t}`

继续探测运行环境后，确认真实应用目录和文件路径，最终读取：

- `/opt/app/.env`

日志中返回真实 flag：

`ISCC{aunXV6waj5Hp8cT35SwVcKK}`

## 最终 flag

`ISCC{aunXV6waj5Hp8cT35SwVcKK}`
