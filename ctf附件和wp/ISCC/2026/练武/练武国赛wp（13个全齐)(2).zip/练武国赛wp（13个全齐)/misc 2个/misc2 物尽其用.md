# misc2 物尽其用 WP

## 题目信息

- 附件：`misc2 物尽其用.zip`
- 参考脚本：`物尽其用.py`
- 要求：不直接运行现成脚本拿答案

## 最终答案

`ISCC{b465ff7293c752699497335669da8606}`

## 一、题目思路

这题本质上是一个图片通道隐写题，外面套了一层“模型训练”伪装。

真正有用的内容只有：

1. `Input.png`
2. `model_state.npz`
3. 题目给的参考脚本

核心流程是：

1. 从 `Input.png` 的 R、G、B 三个通道最低位提取字符串。
2. 从 `model_state.npz` 里恢复提示信息。
3. 根据脚本里的通道映射关系，确定真正要用的两个片段。
4. 计算 `MD5(flag1R || flag2G)`，得到最终 flag。

## 二、压缩包内容

压缩包里有 4 个文件：

```text
config.json
Input.png
model_state.npz
train.exe
```

其中：

- `config.json` 只是一些训练参数，基本没用。
- `Input.png` 是真正藏数据的图片。
- `model_state.npz` 里有关键提示。
- `train.exe` 体积很大，但这题并不需要依赖它来解。

`config.json` 内容如下：

```json
{
  "training": {
    "epochs": 10,
    "batch_size": 1,
    "lr": 0.001
  },
  "callbacks": {
    "aux_log_enabled": false,
    "recovery_enabled": false
  }
}
```

很明显，这一部分只是用来伪装成“训练工程”。

## 三、先看参考脚本

题目给的 `物尽其用.py` 很短，关键逻辑主要有 3 部分。

### 1. 提取通道最低位

函数 `extract_lsb_payload` 会：

1. 把图片转成 RGB。
2. 读取指定通道的最低位。
3. 顺序取前 `16 * 8 = 128` 个 bit。
4. 每 8 位拼成 1 个字节。

所以每个颜色通道都能提取出 16 字节的数据。

### 2. 只打乱花括号中的内容

函数 `scramble_between_markers` 的作用是：

1. 找到 `ISCC{...}`。
2. 保留前缀 `ISCC{` 和后缀 `}`。
3. 只打乱花括号内部的内容。

也就是说，脚本并不是把整段字符串打乱，而是只处理里面那一截。

### 3. 主流程

`solve_zip` 的逻辑可以概括为：

1. 读取 `Input.png`。
2. 读取 `model_state.npz`。
3. 提取 R、G、B 三个通道的隐藏字符串。
4. 根据通道映射关系，确定“最终 G”其实来自原始 B 通道。
5. 对原始 B 通道的花括号内容做一次固定种子的乱序。
6. 取：

```text
flag1R = 原始 R 通道花括号里的内容
flag2G = 变换后的最终 G 通道花括号里的内容
```

7. 最后计算：

```text
MD5(flag1R + flag2G)
```

## 四、分析 `model_state.npz`

`model_state.npz` 里字段很多，但真正关键的是：

```text
base_hint_bytes
base_aux_meta
```

### 1. `base_aux_meta`

内容是：

```text
b64+gz
```

意思很直接：

- 先 Base64 解码
- 再 gzip 解压

### 2. 恢复提示

把 `base_hint_bytes` 按上面的方式处理后，得到：

```text
ISCC{MD5(flag1R||flag2G)}
```

这句话已经把最终计算方式直接告诉我们了：

```text
flag = ISCC{MD5(flag1R || flag2G)}
```

其中 `||` 表示拼接。

## 五、分析 `Input.png`

`Input.png` 是一张 `512 x 512` 的 RGB 图片。

按脚本逻辑，对三个颜色通道分别取最低位，可以得到以下结果。

### 1. R 通道

提取结果：

```text
ISCC{dsbVcLrcyz}
```

所以：

```text
flag1R = dsbVcLrcyz
```

### 2. G 通道

提取结果：

```text
ISCC{UfrMhieWDp}
```

这看起来像是有效数据，但它实际上是干扰项，不是最后要用的 `flag2G`。

### 3. B 通道

提取结果：

```text
ISCC{lgIKcrJiOu}
```

这段才是后面真正会参与变换的数据。

## 六、关键点：最终 G 不是原始 G

脚本里有一句关键注释：

```python
# In the recovered normal mode, apply_channel_transform permutes channels
# as (R, G, B) -> (G, B, R), so logical B lands in the final G channel.
```

意思是：

原始通道顺序是：

```text
(R, G, B)
```

经过恢复出来的变换后，会变成：

```text
(G, B, R)
```

所以：

- 最终 R 来自原始 G
- 最终 G 来自原始 B
- 最终 B 来自原始 R

因此提示中的 `flag2G`，不是原始 G 通道里的内容，而是原始 B 通道经过处理后的结果。

## 七、从 B 通道恢复真正的 `flag2G`

脚本里给了 3 个随机种子：

```python
CHANNEL_SEEDS = {
    "R": 863148490,
    "G": 72199925,
    "B": 2239801264,
}
```

因为最终 G 对应的是原始 B，所以要使用的种子是：

```text
2239801264
```

原始 B 通道内容为：

```text
ISCC{lgIKcrJiOu}
```

取出花括号内部内容：

```text
lgIKcrJiOu
```

然后按 `numpy.random.RandomState(2239801264).shuffle(...)` 生成的顺序进行重排。

对应的置换索引是：

```text
[5, 2, 8, 7, 3, 9, 4, 1, 6, 0]
```

原串按下标展开：

```text
l g I K c r J i O u
0 1 2 3 4 5 6 7 8 9
```

按置换顺序重排后得到：

```text
r I O i K u c g J l
```

也就是：

```text
flag2G = rIOiKucgJl
```

因此“变换后的最终 G 通道内容”为：

```text
ISCC{rIOiKucgJl}
```

## 八、计算最终 flag

根据提示：

```text
ISCC{MD5(flag1R||flag2G)}
```

我们已经得到：

```text
flag1R = dsbVcLrcyz
flag2G = rIOiKucgJl
```

先拼接：

```text
dsbVcLrcyzrIOiKucgJl
```

再计算 MD5：

```text
b465ff7293c752699497335669da8606
```

所以最终答案为：

```text
ISCC{b465ff7293c752699497335669da8606}
```

## 九、为什么原始 G 是干扰项

原始 G 通道中也有一段完整的：

```text
ISCC{UfrMhieWDp}
```

很容易误导人去计算：

```text
MD5(dsbVcLrcyz || UfrMhieWDp)
```

但这样算出来的结果是：

```text
7a0fc7d4a2b394c1bd71ecde84aa6586
```

并不是正确答案。

这说明原始 G 确实只是一个迷惑项，真正的 `flag2G` 必须来自原始 B 通道的乱序结果。

## 十、完整解题流程

完整过程如下：

1. 解压附件，定位 `Input.png` 与 `model_state.npz`。
2. 从 `model_state.npz` 中恢复提示：

```text
ISCC{MD5(flag1R||flag2G)}
```

3. 从 `Input.png` 的三个通道最低位分别提取：

```text
R = ISCC{dsbVcLrcyz}
G = ISCC{UfrMhieWDp}
B = ISCC{lgIKcrJiOu}
```

4. 根据脚本中的通道变换关系：

```text
(R, G, B) -> (G, B, R)
```

确定最终 G 来自原始 B。

5. 使用种子 `2239801264` 对原始 B 的内部内容 `lgIKcrJiOu` 进行乱序。

6. 得到：

```text
flag2G = rIOiKucgJl
```

7. 取：

```text
flag1R = dsbVcLrcyz
flag2G = rIOiKucgJl
```

8. 计算：

```text
MD5("dsbVcLrcyzrIOiKucgJl")
```

9. 最终得到：

```text
ISCC{b465ff7293c752699497335669da8606}
```

## 十一、最终答案

```text
ISCC{b465ff7293c752699497335669da8606}
```
