第一部分：手忙脚乱 Writeup

基本情况

附件是 64 位 Windows PE 程序，MinGW C++ 编译，控制台程序。程序没有明显加壳，符号表仍然保留，关键函数名可以直接看到，包括 decrypt_blob、columnarTransposeEncrypt、encryptPart2、hdb3 等。

PE 头里可以看到动态基址和 NX 相关标志，整体保护不影响静态逆向。本题真正的核心在 main 里的两段校验逻辑。

逆向分析

我先从 main 函数看输入流程。程序提示输入 24 字符明文，长度不等于 24 会直接输出 len error。长度正确后，会先解密几组常量，解出来的短 key 为：

K3 = .]2
K6 = %,DpG/

随后程序用 K6 和 K3 做一次列置换，得到第一层列置换 key：

key1 = %pD/,G

主加密流程可以整理成下面的伪代码：

```c
key1 = columnarTransposeEncrypt(K6, K3);
tmp = columnarTransposeEncrypt(input, key1);
part = encryptPart2(tmp, K6);
```

第一段校验是精确比较：

```c
x = xorStr(part, MASK1);
if (x == TARGET)
    PASS;
else
    FAIL;
```

所以第一段需要满足：

```c
part = TARGET ^ MASK1;
```

把 encryptPart2 和前面的列置换反过来，就能得到第一段通过口令：

```text
#O,?6u|sp,UY:DZx5a mKWL^
```

第一次输入这个字符串后，程序会输出 PASS，并进入第二段校验。

第二段校验的形式不再直接比较字符串，而是先异或再做 HDB3 统计：

```c
a = xorStr(part, MASK2);
b = xorStr(a, TARGET_T);
stat1 = getBVStat(hdb3(bytesToBits(b)));
stat2 = getBVStat(hdb3(bytesToBits(string(24, 0))));
if (stat1 == stat2)
    PASS;
else
    FAIL;
```

这里 stat2 来自 24 个 0 字节，也就是 192 个 0 bit。HDB3 每 4 个连续 0 会产生一个 V，偶数脉冲时还会产生一个 B，因此 24 个 0 字节的统计值为：

```text
B = 48
V = 48
parity = 0
```

192 bit 长度下，要达到 V = 48，所有 bit 都必须是 0。只要出现 1，可参与 4 连 0 替换的 0 数量就不足，V 数量会下降。因此第二段实际等价于：

```c
part ^ MASK2 ^ TARGET_T = 0
part = MASK2 ^ TARGET_T
```

继续反向 encryptPart2 和列置换，得到最终校验明文：

```text
eVDB2{wy`6BE0a1?'!Z?m9<'
```

也就是说，运行程序时需要分两次输入。第一次输入第一段口令，看到 PASS 后再输入最终明文，程序会再次输出 PASS。

附件本身没有打印出 ISCC 或 flag 格式字符串，最终可由程序校验通过的提交明文如上。

解题脚本

```python
import sys
import struct
from pathlib import Path

SPECS = {
    'K6': ('CT_K6', 6, 0x5555),
    'K3': ('CT_K3', 3, 0x6666),
    'MASK1': ('CT_MASK1', 24, 0x3333),
    'TARGET': ('CT_TARGET', 24, 0x1111),
    'MASK2': ('CT_MASK2', 24, 0x4444),
    'TARGET_T': ('CT_TARGET_T', 24, 0x2222),
}

def read_u16(data, off):
    return struct.unpack_from('<H', data, off)[0]

def read_u32(data, off):
    return struct.unpack_from('<I', data, off)[0]

def read_i16(data, off):
    return struct.unpack_from('<h', data, off)[0]

def parse_pe(data):
    pe = read_u32(data, 0x3c)
    if data[pe:pe + 4] != b'PE\0\0':
        raise ValueError('not a PE file')

    coff = pe + 4
    number_of_sections = read_u16(data, coff + 2)
    symbol_table_ptr = read_u32(data, coff + 8)
    number_of_symbols = read_u32(data, coff + 12)
    optional_header_size = read_u16(data, coff + 16)
    optional_header = coff + 20
    magic = read_u16(data, optional_header)
    if magic == 0x20b:
        image_base = struct.unpack_from('<Q', data, optional_header + 24)[0]
    elif magic == 0x10b:
        image_base = read_u32(data, optional_header + 28)
    else:
        raise ValueError('unknown PE optional header')

    sections = []
    section_table = optional_header + optional_header_size
    for i in range(number_of_sections):
        off = section_table + i * 40
        name = data[off:off + 8].split(b'\0', 1)[0].decode('ascii', 'replace')
        virtual_size = read_u32(data, off + 8)
        virtual_address = read_u32(data, off + 12)
        raw_size = read_u32(data, off + 16)
        raw_ptr = read_u32(data, off + 20)
        sections.append((name, virtual_address, virtual_size, raw_ptr, raw_size))

    return image_base, sections, symbol_table_ptr, number_of_symbols

def rva_to_offset(sections, rva):
    for _, va, vs, raw, raw_size in sections:
        size = max(vs, raw_size)
        if va <= rva < va + size:
            return raw + (rva - va)
    raise ValueError('RVA not in sections: 0x%x' % rva)

def get_symbol_name(data, symbol_table_ptr, number_of_symbols, index):
    off = symbol_table_ptr + index * 18
    name_field = data[off:off + 8]
    if name_field[:4] == b'\0\0\0\0':
        string_offset = read_u32(name_field, 4)
        string_table = symbol_table_ptr + number_of_symbols * 18
        start = string_table + string_offset
        end = data.index(b'\0', start)
        return data[start:end].decode('ascii', 'replace')
    return name_field.split(b'\0', 1)[0].decode('ascii', 'replace')

def find_symbols(data):
    image_base, sections, symbol_table_ptr, number_of_symbols = parse_pe(data)
    result = {}
    i = 0
    while i < number_of_symbols:
        off = symbol_table_ptr + i * 18
        name = get_symbol_name(data, symbol_table_ptr, number_of_symbols, i)
        value = read_u32(data, off + 8)
        section_number = read_i16(data, off + 12)
        aux_count = data[off + 17]

        if section_number > 0:
            section = sections[section_number - 1]
            rva = section[1] + value
            for key, (needle, _, _) in SPECS.items():
                if name.endswith(needle):
                    if key == 'TARGET' and name.endswith('CT_TARGET_T'):
                        continue
                    result[key] = rva_to_offset(sections, rva)
        i += 1 + aux_count

    missing = [k for k in SPECS if k not in result]
    if missing:
        raise ValueError('missing symbols: ' + ', '.join(missing))
    return result

def ror8(x, r):
    r &= 7
    return ((x >> r) | ((x << (8 - r)) & 0xff)) & 0xff

def decrypt_blob(blob, seed):
    state = (seed ^ 0xa3b1c2d3) & 0xffffffff
    add_state = 0
    mix_add = 0
    rnd = state
    out = bytearray()

    for b in blob:
        x = (rnd + add_state) & 0xffffffff
        add_state = (add_state - 0x61c88647) & 0xffffffff
        rnd = x
        rnd = (((rnd << 13) & 0xffffffff) ^ x) & 0xffffffff
        rnd = (rnd ^ (rnd >> 17)) & 0xffffffff
        rnd = (rnd ^ ((rnd << 5) & 0xffffffff)) & 0xffffffff
        mask = (mix_add + rnd * 7) & 0xffffffff
        mix_add = (mix_add + 0x0b) & 0xffffffff
        v = b ^ (mask & 0xff)
        v = ror8(v, rnd >> 27)
        out.append((v ^ rnd) & 0xff)

    return bytes(out)

def xor_bytes(a, b):
    if len(a) != len(b):
        raise ValueError('xor length mismatch')
    return bytes(x ^ y for x, y in zip(a, b))

def column_order(key):
    return sorted(range(len(key)), key=lambda i: (key[i], i))

def columnar_encrypt(text, key):
    n = len(key)
    if len(text) % n != 0:
        raise ValueError('transpose length mismatch')
    rows = len(text) // n
    order = column_order(key)
    return bytes(text[r * n + c] for c in order for r in range(rows))

def columnar_decrypt(cipher, key):
    n = len(key)
    if len(cipher) % n != 0:
        raise ValueError('transpose length mismatch')
    rows = len(cipher) // n
    order = column_order(key)
    cols = [b''] * n
    pos = 0
    for c in order:
        cols[c] = cipher[pos:pos + rows]
        pos += rows
    return bytes(cols[c][r] for r in range(rows) for c in range(n))

def make_table(key, seed):
    table = list(range(0x20, 0x7f))
    state = seed & 0xffffffff
    for ch in key:
        state = (state * 0x83 + ch) & 0xffffffff
    for i in range(94, 0, -1):
        state = (state * 0x41c64e6d + 0x3039) & 0xffffffff
        j = state % (i + 1)
        table[i], table[j] = table[j], table[i]
    return bytes(table)

def key_bits(key):
    return [(ch >> bit) & 1 for ch in key for bit in range(7, -1, -1)]

def decrypt_part2(cipher, key):
    table0 = make_table(key, 0x1234)
    table1 = make_table(key, 0x8888)
    bits = key_bits(key)
    n = len(cipher)
    ops = []
    pos = 0

    for bit in bits:
        ops.append(('sub', pos, bit))
        pos += 1
        if pos == n:
            ops.append(('trans',))
            pos = 0

    cur = bytearray(cipher)
    for op in reversed(ops):
        if op[0] == 'trans':
            cur = bytearray(columnar_decrypt(bytes(cur), key))
            continue
        _, idx, bit = op
        table = table1 if bit else table0
        cur[idx] = table.index(cur[idx]) + 0x20
    return bytes(cur)

def hdb3(bits):
    out = []
    last = -1
    zeros = 0
    pulses = 0
    for bit in bits:
        if bit:
            out.append(ord('+') if last == -1 else ord('-'))
            last = -last
            pulses += 1
            zeros = 0
            continue
        out.append(ord('0'))
        zeros += 1
        if zeros == 4:
            if pulses & 1:
                out[-1] = ord('V')
            else:
                out[-4] = ord('B')
                out[-1] = ord('V')
            zeros = 0
            pulses = 0
    return bytes(out)

def bytes_to_bits(data):
    return [(ch >> bit) & 1 for ch in data for bit in range(7, -1, -1)]

def bv_stat(encoded):
    b_count = 0
    v_count = 0
    parity = 0
    for i, ch in enumerate(encoded):
        if ch == ord('B'):
            b_count += 1
        elif ch == ord('V'):
            v_count += 1
            parity ^= i & 1
    return b_count, v_count, parity

def main():
    path = Path(sys.argv[1] if len(sys.argv) > 1 else './附件')
    data = path.read_bytes()
    offsets = find_symbols(data)

    dec = {}
    for key, (_, length, seed) in SPECS.items():
        off = offsets[key]
        dec[key] = decrypt_blob(data[off:off + length], seed)

    key1 = columnar_encrypt(dec['K6'], dec['K3'])

    part1 = xor_bytes(dec['TARGET'], dec['MASK1'])
    stage1 = columnar_decrypt(decrypt_part2(part1, dec['K6']), key1)

    zero_stat = bv_stat(hdb3(bytes_to_bits(b'\x00' * 24)))
    if zero_stat != (48, 48, 0):
        raise RuntimeError('unexpected hdb3 stat')
    part2 = xor_bytes(dec['MASK2'], dec['TARGET_T'])
    final_plaintext = columnar_decrypt(decrypt_part2(part2, dec['K6']), key1)

    print('stage1 plaintext:', stage1.decode('latin1'))
    print('final plaintext:', final_plaintext.decode('latin1'))

if __name__ == '__main__':
    main()

```

运行方式

```text
python solve.py ./附件
```

本附件运行结果

```text
stage1 plaintext: #O,?6u|sp,UY:DZx5a mKWL^
final plaintext: eVDB2{wy`6BE0a1?'!Z?m9<'
```

第二部分：WP文件下载

手忙脚乱-Writeup.md
