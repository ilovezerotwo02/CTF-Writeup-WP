
from Crypto.Util.number import getPrime
import random

class AsmuthBloomSecretSharer:
    
    @staticmethod
    def split_secret(secret, k, n):

        if isinstance(secret, str):
            secret_bytes = secret.encode('utf-8')
        else:
            secret_bytes = secret
        S = int.from_bytes(secret_bytes, 'big')
        secret_bits = S.bit_length()
        original_bits = len(secret_bytes) * 8
        
        d = []
        base_bits = max(64, (secret_bits * 2) // k)  
        
        for i in range(n):
            bits = base_bits + i * 10
            attempts = 0
            while attempts < 100:
                p = getPrime(bits)
                if not d or p > d[-1]:
                    d.append(p)
                    break
                attempts += 1
            if attempts >= 100:
                bits += 50
                p = getPrime(bits)
                d.append(p)
        
        shares = []
        for i, di in enumerate(d):
            ki = S % di
            share_str = f"{di:x}:{ki:x}:{original_bits:x}"
            shares.append(share_str)
        
        return shares

def main():
    with open('message1.txt', 'r') as f:
        PLAINTEXTS = [f.read()] * 10

    for i in range(2, 11):
        with open(f'message{i}.txt', 'r') as f:
            msg = f.read().strip()
        
        k = i 
        
        shares = AsmuthBloomSecretSharer.split_secret(msg, k, 10)
        for j in range(10):
            PLAINTEXTS[j] += shares[j] + '\n'

    for j in range(10):
        with open(f'plaintext-{j+1}.txt', 'w') as f:
            f.write(PLAINTEXTS[j])
    

if __name__ == "__main__":
    main()