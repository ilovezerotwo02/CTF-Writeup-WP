
import random
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Util.number import bytes_to_long, long_to_bytes

def get_rand_bytes(length):
    return bytes([random.randrange(256) for _ in range(length)])

def encrypt(public_key, message):
    if isinstance(message, str):
        message = message.encode('utf-8')
    
    n = public_key.n
    n_bits = n.bit_length()
    
    if n_bits >= 2048:
        key_len = (n.bit_length() + 7) // 8
        symmetric_key = get_rand_bytes(32)
        msg_header = PKCS1_OAEP.new(public_key).encrypt(symmetric_key)
        nonce = get_rand_bytes(12)
        cipher = AES.new(symmetric_key, mode=AES.MODE_GCM, nonce=nonce)
        msg_body, tag = cipher.encrypt_and_digest(message)
        return msg_header + nonce + msg_body + tag
    else:
        symmetric_key = get_rand_bytes(16)
        key_int = bytes_to_long(symmetric_key)
        
        if key_int >= n:
            while key_int >= n:
                symmetric_key = get_rand_bytes(16)
                key_int = bytes_to_long(symmetric_key)
        
        encrypted_key_int = pow(key_int, public_key.e, n)
        
        key_len = (n.bit_length() + 7) // 8
        msg_header = long_to_bytes(encrypted_key_int, key_len)
        
        nonce = get_rand_bytes(12)
        cipher = AES.new(symmetric_key, mode=AES.MODE_GCM, nonce=nonce)
        msg_body, tag = cipher.encrypt_and_digest(message)
        
        return msg_header + nonce + msg_body + tag


if __name__ == "__main__":
    message = "This is my test message. It's kind of long for testing."
    private_key = RSA.generate(4096)
    public_key = private_key.publickey()
    ciphertext = encrypt(public_key, message)
