#!/bin/sh
cd "$(dirname "$0")"

echo 'use `kctf-pow solve` to prove yourself :)'

./kctf-pow ask 23333

if [ $? -ne 0 ]; then
	echo 'PoW failed';
	exit;
fi

timeout -s KILL 200s ./run_qemu.sh
