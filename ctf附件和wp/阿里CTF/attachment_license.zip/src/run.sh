#!/bin/bash
FLAG="$(cat /flag)"
export FLAG=${FLAG}
# fix timezone
export TZ=Asia/Shanghai
chmod +x /app/license
chmod +x /app/pow
/app/pow chall -v -b 24 && /app/license --no-redirect -c 127.0.0.1:12345 2>/dev/null