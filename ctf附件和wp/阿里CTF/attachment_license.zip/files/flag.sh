#!/bin/bash


write_flag_in_fs() {
    # 将flag写入到文件系统中
    if [ -z "$1" ]; then
        flag_path="/flag"
    else
        flag_path="$1"
    fi
    echo ${FLAG} > ${flag_path}
}

write_flag_in_db() {
    local db_name="${1:-web}"
    local db_table="${2:-flag}"
    local db_column="${3:-flag}"
    echo mysql -uroot -proot -e "update ${db_name}.${db_table} set ${db_column}='${FLAG}';"
}

write_flag_in_fs /flag

export FLAG=not_flag
FLAG=not_flag